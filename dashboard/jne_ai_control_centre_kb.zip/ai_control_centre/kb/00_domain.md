# JNE Data Governance — domain primer

This is the ground truth for the AI Control Centre. Everything else in this
knowledge pack elaborates on it.

## What is being measured

JNE moves packages through a **package journey**. Every package carries a **cnote
number** (consignment note) and generates records across 31 operational
tables as it travels. The Data Governance framework runs **499 checks** — each
with a unique **index code** — over those records and returns PASS or FAIL per check
per record.

## The six elements

| Element | The question it answers | Checks |
|---|---|---|
| Accuracy | Is this value correct? | 8 |
| Completeness | Is anything missing? | 246 |
| Validity | Is the format right? | 149 |
| Uniqueness | Is anything counted twice? | 42 |
| Consistency | Does the value agree across tables? | 44 |
| Timeliness | Did events happen in the right order? | 10 |

There were once seven elements — Integrity was the seventh. **It was dropped
deliberately.** Six is correct. Never refer to seven elements.

## The four package journeys

1. **Direct Intracity** — within the same city as the reference origin.
2. **Direct Intercity** — between cities within the same main branch; requires a manifest.
3. **Direct Domestic** — between cities in different main branches; requires a manifest.
4. **Transit Domestic** — different main branches, requiring a manifest *and* a transit
   manifest through a gateway. The longest journey, and the one with the most checks.

The longer the journey, the more index checks apply. A Direct Domestic package fires
around 97 checks; a Transit Domestic one around 182, and up to 876.

## Index code scheme

Format: `ELEMENT` + `rule number` + `table letter` + `column number` + optional variant.

`ACCU2B12A` = Accuracy, rule 2, table block B (CMS_CNOTE), column 12, variant A.

**A change in a rule's logic issues a NEW code and retires the old one.** Codes are not
versioned. This is why `UNIQ1*` codes were replaced by `UNIQ2*`. When answering about a
historical result, check whether its code has since been retired.

Table blocks:

- `A` → CMS_APICUST
- `AA` → CMS_DSJ
- `AB` → CMS_MHICNOTE
- `AC` → CMS_DHICNOTE
- `AD` → CMS_RDSJ
- `AE` → CMS_DBAG_HO
- `B` → CMS_APICUST, CMS_CNOTE
- `C` → CMS_MRCNOTE
- `D` → CMS_DRCNOTE
- `E` → CMS_MHI_HOC
- `F` → CMS_DHI_HOC
- `G` → CMS_DSTATUS
- `H` → CMS_MANIFEST
- `I` → CMS_MFCNOTE
- `J` → CMS_MFBAG
- `K` → CMS_DMBAG
- `L` → CMS_MMBAG
- `M` → CMS_DSMU
- `N` → CMS_MSMU
- `O` → CMS_DRSHEET_PRA
- `P` → CMS_DRSHEET
- `Q` → CMS_MRSHEET
- `R` → CMS_CNOTE_POD
- `S` → CMS_CNOTE_POD, CMS_DHOV_RSHEET
- `T` → CMS_MHOUNDEL_POD
- `U` → CMS_DHOUNDEL_POD
- `V` → CMS_MHOCNOTE
- `W` → CMS_DHOCNOTE
- `X` → CMS_COST_MTRANSIT_AGEN
- `Y` → CMS_COST_DTRANSIT_AGEN
- `Z` → CMS_MSJ

## Result levels

Each result row is at one of two levels:

- **cnote level** — one row per check per package.
- **bag level** — one row per check per bag/manifest record the package touched. A single
  index code can fire **up to 164 times** for one package at bag level.

A median package produces about 57 cnote-level and 111 bag-level results.

## How the score is calculated

For a given cnote: **passed result rows ÷ all result rows that cnote generated**,
counting cnote-level and bag-level together. A package that touched more bags simply has
a larger denominator. This is intended — it measures record quality, not package quality.

There is **no target score and no severity tiering yet**. Do not describe any score as
"good", "bad", "passing" or "failing a threshold". Report the number and the comparison.
