# Decisions and guardrails

Confirmed with House of Analytics and JNE, 24 September 2026. These override anything
that contradicts them in older decks or spreadsheets.

## Confirmed

1. **Six elements, not seven.** Integrity was dropped deliberately.
2. **Seven reference tables are deliberately unmeasured** — T_GOTO, CMS_DROURATE,
   CMS_CNOTE_AMO, LASTMILE_COURIER, T_MDT_CITY_ORIGIN, ORA_ZONE, ORA_USER.
3. **Score = passed rows ÷ all rows for that cnote**, cnote and bag level together.
4. **Weight must be a whole number of kilograms.** `VALD2B15`, `VALD2A25`, `VALD2I4`
   are correct as written. Fractional weights are genuine billing defects, not noise.
5. **New logic issues a new index code and retires the old one.** A retired-codes
   register is required and does not yet exist.
6. **Ownership is assigned per table** — one owner per table, including the reference
   tables.
7. **No severity tiers and no target score yet.** Baseline first, thresholds later.
8. **Business impact mapping is JNE's to complete.** 444 of 499 checks are still `TBD`.
9. **The library is bilingual**, Indonesian and English side by side.

## Guardrails — what the assistant must not do

- **Never present the 100-cnote sample's Uniqueness numbers as current.** All 564
  Uniqueness failures in that run came from retired `UNIQ1*` logic. Say so whenever
  Uniqueness is discussed against that dataset.
- **Never call a score good, bad, passing or failing.** No threshold has been agreed.
  Report the number, the comparison and the direction of travel.
- **Never infer business impact for a check marked `TBD`.** 89% of the library is
  unmapped. Say "impact not yet mapped by JNE" rather than guessing at billing or
  operational consequence.
- **Never state a monetary value** for a defect. No cost model has been agreed.
- **Distinguish a failed check from a wrong rule.** `VALD13P7` is a known open case:
  it checks `DRSHEET_UID` against `ORA_ZONE` and fails on courier user IDs, but is
  labelled as a destination-code error. Flag it rather than explaining it as a defect.
- **Do not treat a FAIL as an unfixed problem.** There is no remediation loop or
  open/closed state yet — a result is a snapshot of the record as scored.
- **Cite the index code** in every explanation of a failure, so the answer can be
  traced back to the library.
- When the data cannot answer the question, say so and name what would be needed.
