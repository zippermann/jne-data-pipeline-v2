# Package journeys — which tables each journey touches

Derived from an observed 100-cnote run. Stage is the operational phase; the
tables listed are those that produced index results at that stage.

## Intracity

- **cnote** — CMS_APICUST, CMS_CNOTE, CMS_DRSHEET_PRA
- **receival** — CMS_DHI_HOC, CMS_DRCNOTE, CMS_MRCNOTE
- **manifest** — CMS_MANIFEST, CMS_MFBAG, CMS_MFCNOTE
- **runsheet** — CMS_CNOTE_POD, CMS_DHOUNDEL_POD, CMS_DHOV_RSHEET, CMS_DRSHEET, CMS_MRSHEET
- **handover** — CMS_DBAG_HO, CMS_DHICNOTE, CMS_DHOCNOTE, CMS_DSJ, CMS_MHICNOTE, CMS_MHOCNOTE, CMS_MSJ, CMS_RDSJ

## Intercity

- **cnote** — CMS_APICUST, CMS_CNOTE, CMS_DRSHEET_PRA
- **receival** — CMS_DHI_HOC, CMS_DRCNOTE, CMS_MRCNOTE
- **manifest** — CMS_DMBAG, CMS_MANIFEST, CMS_MFBAG, CMS_MFCNOTE
- **runsheet** — CMS_CNOTE_POD, CMS_DHOV_RSHEET, CMS_DRSHEET, CMS_MRSHEET
- **handover** — CMS_COST_DTRANSIT_AGEN, CMS_COST_MTRANSIT_AGEN, CMS_DBAG_HO, CMS_DHICNOTE, CMS_DHOCNOTE

## Direct Domestic

- **cnote** — CMS_APICUST, CMS_CNOTE, CMS_DSTATUS
- **receival** — CMS_DHI_HOC, CMS_DRCNOTE, CMS_MHI_HOC, CMS_MRCNOTE
- **manifest** — CMS_MANIFEST, CMS_MFBAG, CMS_MFCNOTE
- **runsheet** — CMS_CNOTE_POD, CMS_DRSHEET, CMS_MRSHEET

## Transit Domestic

- **cnote** — CMS_APICUST, CMS_CNOTE, CMS_DRSHEET_PRA
- **receival** — CMS_DHI_HOC, CMS_DRCNOTE, CMS_MHI_HOC, CMS_MRCNOTE
- **manifest** — CMS_DMBAG, CMS_MANIFEST, CMS_MFBAG, CMS_MFCNOTE, CMS_MMBAG
- **runsheet** — CMS_CNOTE_POD, CMS_DHOUNDEL_POD, CMS_DHOV_RSHEET, CMS_DRSHEET, CMS_MHOUNDEL_POD, CMS_MRSHEET
- **handover** — CMS_COST_DTRANSIT_AGEN, CMS_COST_MTRANSIT_AGEN, CMS_DBAG_HO, CMS_DHICNOTE, CMS_DHOCNOTE, CMS_DSJ, CMS_MHICNOTE, CMS_MHOCNOTE, CMS_MSJ, CMS_RDSJ

## Notes

- `Direct Domestic` in the result data shows no `handover` stage.
- `Transit Domestic` is the only journey that reaches CMS_MMBAG and the full
  handover set including CMS_MSJ / CMS_DSJ / CMS_RDSJ.
- The framework deck names the journeys "Direct Intracity" and "Direct
  Intercity"; the result data uses "Intracity" and "Intercity". Same thing.
