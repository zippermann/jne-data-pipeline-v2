# Column business metadata

462 columns across 38 tables.
`validated` records whether JNE has confirmed the definition.

## T_GOTO

- **AWB** — Unique identifier for GOTO Package _(validated: not confirmed)_ · e.g. `TKP5011287910`
- **CROSSDOCK_ROLE** — MM = Mid Mile
FM = First Mile
LM = Last Mile _(validated: not confirmed)_ · e.g. `mm,lm`
- **FIELD_CHAR1** — Additional descriptive data _(validated: not confirmed)_
- **FIELD_NUMBER1** — Additional descriptive data _(validated: not confirmed)_
- **FIELD_DATE1** — Additional descriptive data _(validated: not confirmed)_
- **CREATE_DATE** — Time and Date Data Received into JNE's server _(validated: not confirmed)_ · e.g. `45975.4354398148`

## CMS_DROURATE

- **DROURATE_CODE** — Reference for SLA based on the Route Code (Origin Code and Destination Code) _(validated: not confirmed)_ · e.g. `CGK10000UPG10004`
- **DROURATE_SERVICE** — JNE Service Type _(validated: not confirmed)_ · e.g. `CARGO23`
- **DROURATE_ACTIVE** — Active status of SLA for every Route Code _(validated: not confirmed)_ · e.g. `Y`
- **DROURATE_UID** — User that create the SLA _(validated: not confirmed)_ · e.g. `SYSTEM`
- **DROURATE_UDATE** — Changes made to the SLA _(validated: not confirmed)_ · e.g. `2024-09-14 12:27:33`
- **DROURATE_ETD_FROM** — Minimum estimated time of delivery _(validated: not confirmed)_ · e.g. `0`
- **DROURATE_ETD_THRU** — Maximum estimated time of delivery _(validated: not confirmed)_ · e.g. `0`
- **DROURATE_TIME** — Measure of time (D = Day, H = Hours) _(validated: not confirmed)_ · e.g. `D`
- **DROURATE_YES_LATE** — SLA for Yes Bintang cut off time in Hours _(validated: not confirmed)_

## CMS_APICUST

- **APICUST_ORDER_ID** — Unique Identifier for a customer order _(validated: Yes)_ · e.g. `25B8ERDZZR3JG` · **checked**
- **APICUST_CNOTE_NO** — The unique identifier for an individual shipment (Airway Bill) _(validated: Yes)_ · e.g. `0117762502235141` · **checked**
- **APICUST_ORIGIN** — Package Origin Code _(validated: Yes)_ · e.g. `CGK10000` · **checked**
- **APICUST_BRANCH** — Branch Code _(validated: Yes)_ · e.g. `CGK000` · **checked**
- **APICUST_CUST_NO** — Customer Unique Identifier _(validated: Yes)_ · e.g. `80538300` · **checked**
- **APICUST_SERVICES_CODE** — JNE Service Type _(validated: Yes)_ · e.g. `REG23` · **checked**
- **APICUST_DESTINATION** — Package Destination Code _(validated: Yes)_ · e.g. `UPG10004` · **checked**
- **APICUST_SHIPPER_NAME** — Name of shipper (Company) _(validated: Yes)_ · e.g. `BUKUWARUNG`
- **APICUST_SHIPPER_ADDR1** — Shipper address _(validated: Yes)_ · e.g. `JAKARTA 13920 KW INDUSTRI PULO`
- **APICUST_SHIPPER_ADDR2** — Shipper address additional information _(validated: Yes)_ · e.g. `G KOTA JAKARTA TIMUR DAERAH KH`
- **APICUST_SHIPPER_ADDR3** — Shipper address additional information _(validated: Yes)_ · e.g. ` `
- **APICUST_SHIPPER_CITY** — Shipper City _(validated: Yes)_ · e.g. `JAKARTA TIMUR`
- **APICUST_SHIPPER_ZIP** — Shipper Zip Code _(validated: Yes)_ · e.g. `13920` · **checked**
- **APICUST_SHIPPER_REGION** — Shipper District _(validated: Yes)_ · e.g. `CAKUNG`
- **APICUST_SHIPPER_COUNTRY** — Shipper Country _(validated: Yes)_ · e.g. `INDONESIA`
- **APICUST_SHIPPER_CONTACT** — Shipper Contact _(validated: Yes)_ · e.g. `*******UNG`
- **APICUST_SHIPPER_PHONE** — Shipper Phone Number _(validated: Yes)_ · e.g. `**********922`
- **APICUST_RECEIVER_NAME** — Receiver Name _(validated: Yes)_ · e.g. `LILIK MUNADHIROH`
- **APICUST_RECEIVER_ADDR1** — Receiver address _(validated: Yes)_ · e.g. `JL DG RAMANG WARUNG SEDERHANA `
- **APICUST_RECEIVER_ADDR2** — Receiver address additional information _(validated: Yes)_ · e.g. ` SULAWESI SELATAN 90242,SUDIAN`
- **APICUST_RECEIVER_ADDR3** — Receiver address additional information _(validated: Yes)_ · e.g. ` `
- **APICUST_RECEIVER_CITY** — Receiver City _(validated: Yes)_ · e.g. `MAKASSAR`
- **APICUST_RECEIVER_ZIP** — Receiver Zip Code _(validated: Yes)_ · e.g. `90242` · **checked**
- **APICUST_RECEIVER_REGION** — Receiver District _(validated: Yes)_ · e.g. `BIRING KANAYA`
- **APICUST_RECEIVER_COUNTRY** — Receiver Country _(validated: Yes)_ · e.g. `INDONESIA`
- **APICUST_RECEIVER_CONTACT** — Receiver Contact _(validated: Yes)_ · e.g. `************IRO`
- **APICUST_RECEIVER_PHONE** — Receiver Phone Number _(validated: Yes)_ · e.g. `***-**-***0`
- **APICUST_QTY** — Package Quantity _(validated: Yes)_ · e.g. `1` · **checked**
- **APICUST_WEIGHT** — Package Weight _(validated: Yes)_ · e.g. `1` · **checked**
- **APICUST_GOODS_DESCR** — Package Description _(validated: Yes)_ · e.g. `SB-SCI`
- **APICUST_GOODS_VALUE** — Package Value in Rp _(validated: Yes)_ · e.g. `337000` · **checked**
- **APICUST_SPECIAL_INS** — Special Instructions _(validated: Yes)_ · e.g. `ORDER BY SHIPPER.ID.`
- **APICUST_INS_FLAG** — Shipping with Insurance _(validated: Yes)_ · e.g. `Y`
- **APICUST_COD_FLAG** — Cash On Delivery flag Yes or No _(validated: Yes)_ · e.g. `NO`
- **APICUST_COD_AMOUNT** — Cash On Delivery amount in Rp _(validated: Yes)_ · e.g. `0` · **checked**
- **CREATE_DATE** — Time and Date the order is created in the table in JNE's server _(validated: Yes)_ · e.g. `45975.6919097222` · **checked**
- **APICUST_LATITUDE** — Latitude of Shipper _(validated: Yes)_
- **APICUST_LONGITUDE** — Longitude of Shipper _(validated: Yes)_
- **APICUST_SHIPMENT_TYPE** — Drop off or Pick up method _(validated: Yes)_ · e.g. `PICKUP`
- **APICUST_MERCHAN_ID** — Merchant ID _(validated: Yes)_ · e.g. `6018303928A7AE80188B4567-39BA35A5`
- **APICUST_NAME** — Customer Name _(validated: Yes)_ · e.g. `BUKUWARUNG`
- **SHIPPER_PROVIDER** — JNE, JNE Trucking, JNE Regular for example Lazada _(validated: Yes)_

## CMS_CNOTE

- **CNOTE_NO** — The unique identifier for an individual shipment (Airway Bill). _(validated: Yes)_ · e.g. `641100001930923` · **checked**
- **CNOTE_DATE** — Time and Date the Cnote is created from Branch Computer (Timestamp User Device) _(validated: Yes)_ · e.g. `45976.5583564815` · **checked**
- **CNOTE_BRANCH_ID** — Branch Code _(validated: Yes)_ · e.g. `TGL000` · **checked**
- **CNOTE_SERVICES_CODE** — JNE Service Type _(validated: Yes)_ · e.g. `YES23` · **checked**
- **CNOTE_CUST_NO** — Customer Unique Identifier _(validated: Yes)_ · e.g. `10015800` · **checked**
- **CNOTE_ROUTE_CODE** — Route Code based on Origin Code & Destination Code _(validated: Yes)_ · e.g. `TGL20000CGK10103` · **checked**
- **CNOTE_ORIGIN** — Origin Code _(validated: Yes)_ · e.g. `TGL20000` · **checked**
- **CNOTE_DESTINATION** — Destination Code _(validated: Yes)_ · e.g. `CGK10103` · **checked**
- **CNOTE_QTY** — Package Quantity _(validated: Yes)_ · e.g. `1` · **checked**
- **CNOTE_WEIGHT** — Package Weight _(validated: Yes)_ · e.g. `1` · **checked**
- **CNOTE_SHIPPER_NAME** — Name of shipper _(validated: Yes)_ · e.g. `LUTFI DIAN LUMINTANG` · **checked**
- **CNOTE_SHIPPER_ADDR1** — Shipper address _(validated: Yes)_ · e.g. `JL,SUKAHARTI RT 04 RW 03 ` · **checked**
- **CNOTE_SHIPPER_ADDR2** — Shipper address additional information _(validated: Yes)_ · e.g. `DUKUH JERUK BANJARHARJO`
- **CNOTE_SHIPPER_ADDR3** — Shipper address additional information _(validated: Yes)_
- **CNOTE_SHIPPER_CITY** — Shipper City _(validated: Yes)_ · e.g. `BREBES,KAB.BREBES`
- **CNOTE_SHIPPER_ZIP** — Shipper Zip Code _(validated: Yes)_
- **CNOTE_SHIPPER_REGION** — Shipper City _(validated: Yes)_
- **CNOTE_SHIPPER_COUNTRY** — Shipper Country _(validated: Yes)_ · e.g. `INDONESIA`
- **CNOTE_SHIPPER_CONTACT** — Shipper Contact _(validated: Yes)_
- **CNOTE_SHIPPER_PHONE** — Shipper Phone Number _(validated: Yes)_ · e.g. `***********918`
- **CNOTE_RECEIVER_NAME** — Receiver Name _(validated: Yes)_ · e.g. `BPK, BAHRUL RIZIK `
- **CNOTE_RECEIVER_ADDR1** — Receiver address _(validated: Yes)_ · e.g. `WARUNG IBU JUS JL PANJANG `
- **CNOTE_RECEIVER_ADDR2** — Receiver address additional information _(validated: Yes)_ · e.g. `ARTERI GANG HMAYA NO 10 `
- **CNOTE_RECEIVER_ADDR3** — Receiver address additional information _(validated: Yes)_ · e.g. `RT 18 RW 1 KEDOYA SELATAN  `
- **CNOTE_RECEIVER_CITY** — Receiver City _(validated: Yes)_ · e.g. `KEBON JERUK ,JAKARTA`
- **CNOTE_RECEIVER_ZIP** — Receiver Zip Code _(validated: Yes)_ · e.g. `11520`
- **CNOTE_RECEIVER_REGION** — Receiver Region _(validated: Yes)_
- **CNOTE_RECEIVER_COUNTRY** — Receiver Country _(validated: Yes)_
- **CNOTE_RECEIVER_CONTACT** — Receiver Contact _(validated: Yes)_
- **CNOTE_RECEIVER_PHONE** — Receiver Phone Number _(validated: Yes)_ · e.g. `**********918`
- **CNOTE_GOODS_TYPE** — Package Type of Good (1 or 2) _(validated: Yes)_ · e.g. `2` · **checked**
- **CNOTE_GOODS_DESCR** — Package description _(validated: Yes)_ · e.g. `BERKAS`
- **CNOTE_GOODS_VALUE** — Package Value in Rp _(validated: Yes)_ · e.g. `0`
- **CNOTE_SPECIAL_INS** — Special Instructions _(validated: Yes)_
- **CNOTE_INSURANCE_ID** — Type of Insurance for Package _(validated: Yes)_
- **CNOTE_INSURANCE_VALUE** — Value of Insurance in Rp _(validated: Yes)_ · e.g. `0`
- **CNOTE_PAYMENT_TYPE** — Payment type 1 to 6 _(validated: Yes)_ · e.g. `1`
- **CNOTE_CURRENCY** — Currency of Payment _(validated: Yes)_ · e.g. `IDR`
- **CNOTE_AMOUNT** — Final Price Biaya Paket dan Add On kepada customer _(validated: Yes)_ · e.g. `16000`
- **CNOTE_ADDITIONAL_FEE** — Package Additional Fee _(validated: Yes)_ · e.g. `0`
- **CNOTE_NOTICE** — Notice _(validated: Yes)_
- **CNOTE_PRINTED** — Package label has been printed (Yes or No) _(validated: Yes)_ · e.g. `Y`
- **CNOTE_CANCEL** — If Cnote has been cancelled (Y/Null) _(validated: Yes)_
- **CNOTE_HOLD** — If Cnote has been hold (Y/Null) _(validated: Yes)_
- **CNOTE_HOLD_REASON** — Reason why Cnote has been hold _(validated: Yes)_
- **CNOTE_USER** — User ID who entry the data for Cnote _(validated: Yes)_ · e.g. `RIDOTGL` · **checked**
- **CNOTE_REFNO** — Unique Identifier relationship from CMS_CUSTAPI _(validated: Yes)_ · **checked**
- **CNOTE_INSURANCE_NO** — Insurance No for Cnote _(validated: Yes)_
- **CNOTE_OTHER_FEE** — Additional fee amount _(validated: Yes)_
- **CNOTE_CURC_PAYMENT** — Currency of Payment _(validated: Yes)_ · e.g. `1`
- **CNOTE_CURC_RATE** — Currency Rate _(validated: Yes)_ · e.g. `1`
- **CNOTE_PAYMENT_BY** — Currency of Payment _(validated: Yes)_ · e.g. `IDR`
- **CNOTE_AMOUNT_PAYMENT** — Jumlah yang dibayar oleh customer (Bisa beda dengan CNOTE_AMOUNT) _(validated: Yes)_ · e.g. `16000`
- **CNOTE_BILNOTE** — Billing COD (Y/Null) _(validated: Yes)_
- **CNOTE_CRDATE** — Time and Date the CNote enters JNE's server (Timestamp Server) _(validated: Yes)_ · e.g. `45975.5580208333` · **checked**
- **CNOTE_PACKING** — Packing 1 to 4 _(validated: Yes)_
- **CNOTE_CARD_NO** — JLC Number (JNE Loyalty Card) _(validated: Yes)_
- **CNOTE_ECNOTE** — Entry memakai hybrid (Apex/Orion) _(validated: Yes)_ · e.g. `Y`
- **CNOTE_SES_FRM** — ID Aplikasi _(validated: Yes)_ · e.g. `ECONNOTE`

## CMS_CNOTE_AMO

- **CNOTE_NO** — The unique identifier for an individual shipment (Airway Bill). _(validated: not confirmed)_ · e.g. `JNAP-0248529320`
- **CNOTE_BRANCH_ID** — Branch Code _(validated: not confirmed)_ · e.g. `CGK000`
- **FIELDCHAR1** — Additional Description _(validated: not confirmed)_ · e.g. `PROC_AUTO_MNF_NP_OUTBOUND`
- **FIELDCHAR2** — Additional Description _(validated: not confirmed)_
- **FIELDCHAR3** — Additional Description _(validated: not confirmed)_
- **FIELDCHAR4** — Additional Description _(validated: not confirmed)_
- **FIELDCHAR5** — Additional Description _(validated: not confirmed)_
- **FIELDNUM1** — Additional Description _(validated: not confirmed)_
- **FIELDNUM2** — Additional Description _(validated: not confirmed)_
- **FIELDNUM3** — Additional Description _(validated: not confirmed)_
- **FIELDNUM4** — Additional Description _(validated: not confirmed)_
- **FIELDNUM5** — Additional Description _(validated: not confirmed)_
- **CDATE** — Time and Date Data is in JNE Server _(validated: not confirmed)_ · e.g. `45976.2391319444`

## CMS_MRCNOTE

- **MRCNOTE_NO** — Unique identifier for RCC for Warehouse Origin _(validated: Yes)_ · e.g. `CGK/RCC/33083480` · **checked**
- **MRCNOTE_DATE** — Time and Date RCC Document has been generated at Warehouse Origin _(validated: Yes)_ · e.g. `45976.1782638889` · **checked**
- **MRCNOTE_BRANCH_ID** — Branch code of Package being received _(validated: Yes)_ · e.g. `CGK000` · **checked**
- **MRCNOTE_USER_ID** — The user that generates the RCC Document at Warehouse Origin _(validated: Yes)_ · e.g. `AGUSHARI` · **checked**
- **MRCNOTE_COURIER_ID** — Courier identifier that drops the package to Origin Warehouse _(validated: Yes)_ · e.g. `CGK14886`
- **MRCNOTE_USER1** — The user admin that scans/entry the package in warehouse origin _(validated: Yes)_ · e.g. `AGUSHARI` · **checked**
- **MRCNOTE_USER2** — CourierID/UserID _(validated: Yes)_ · e.g. `SHIPPER` · **checked**
- **MRCNOTE_SIGNDATE** — Time and Date RCC has been approved at Warehouse Origin _(validated: Yes)_ · e.g. `45976.1782638889` · **checked**
- **MRCNOTE_PAYMENT** — Payment type 1 to 6 _(validated: Yes)_ · e.g. `2`

## CMS_DRCNOTE

- **DRCNOTE_NO** — Unique identifier for RCC for Warehouse Origin _(validated: Yes)_ · e.g. `BDO/RCC/03035818` · **checked**
- **DRCNOTE_CNOTE_NO** — The unique identifier for an individual shipment (Airway Bill). _(validated: Yes)_ · e.g. `JY96859632001` · **checked**
- **DRCNOTE_QTY** — Quantity of Package _(validated: Yes)_ · e.g. `1` · **checked**
- **DRCNOTE_REMARKS** — Additional description _(validated: Yes)_ · e.g. `AAM141125`
- **DRCNOTE_TDATE** — Time and Date the RCC has been scanned at Warehouse Origin _(validated: Yes)_ · e.g. `45976.0021759259` · **checked**
- **DRCNOTE_TUSER** — Additional description _(validated: Yes)_
- **DRCNOTE_PAYMENT** — Payment type 1 to 6 _(validated: Yes)_ · e.g. `2`
- **DRCNOTE_DO** — Delivery Order _(validated: Yes)_ · e.g. `N`

## CMS_MHI_HOC

- **MHI_NO** — Unique identifier for RHC in Warehouse Origin _(validated: not confirmed)_ · e.g. `PDG/RHC/00132283` · **checked**
- **MHI_REF_NO** — Unique identifier for HC in Warehouse Origin _(validated: not confirmed)_ · e.g. `PDG/HC/000770198` · **checked**
- **MHI_DATE** — Time and Date MHI Document is Generated _(validated: not confirmed)_ · e.g. `2026-01-05 12:34:34` · **checked**
- **MHI_UID** — The user that generates the MHI Document _(validated: not confirmed)_ · e.g. `SYAHZPDG` · **checked**
- **MHI_APPROVE** — MHI Document Approval Flag (Y/Null) _(validated: not confirmed)_ · e.g. `Y` · **checked**
- **MHI_BRANCH** — Branch Code of the MHI Document is Generated _(validated: not confirmed)_ · e.g. `PDG000` · **checked**
- **MHI_APPROVE_DATE** — Time and Date MHI Document is Approved _(validated: not confirmed)_ · e.g. `2026-01-05 12:34:51` · **checked**
- **MHI_REMARKS** — Additional Description _(validated: not confirmed)_
- **MHI_USER1** — The user that Approved the MHI Document _(validated: not confirmed)_ · e.g. `SYAHZPDG` · **checked**
- **MHI_USER2** — The user that Approved the MHI Document _(validated: not confirmed)_ · e.g. `PDG`
- **MHI_ZONE** — Zone Code of the MHI Document is Generated _(validated: not confirmed)_ · **checked**
- **MHI_COURIER** — MHI Courier ID _(validated: not confirmed)_ · e.g. `PDG397`

## CMS_DHI_HOC

- **DHI_NO** — Unique identifier for RHC in Warehouse Origin _(validated: not confirmed)_ · e.g. `PDG/RHC/00132283` · **checked**
- **DHI_ONO** — Unique identifier for HC in Warehouse Origin _(validated: not confirmed)_ · e.g. `PDG/HC/000770198` · **checked**
- **DHI_CNOTE_NO** — The unique identifier for an individual shipment (Airway Bill). _(validated: not confirmed)_ · e.g. `4547367207` · **checked**
- **DHI_CNOTE_QTY** — Package quantity _(validated: not confirmed)_ · e.g. `1` · **checked**
- **CDATE** — Time and Date data is created _(validated: not confirmed)_ · e.g. `2026-01-05 12:34:48` · **checked**
- **DHI_REMARKS** — Additional Description _(validated: not confirmed)_
- **DHI_DO** — Delivery Order _(validated: not confirmed)_ · e.g. `N`

## CMS_MANIFEST

- **MANIFEST_NO** — Unique identifier to capture end-to-end Manifest process from Outbound/Transit/Inbound _(validated: Yes)_ · e.g. `CGK/OM/102689245` · **checked**
- **MANIFEST_DATE** — Time and Date Manifest Document is Generated _(validated: Yes)_ · e.g. `45976.2042592593` · **checked**
- **MANIFEST_ROUTE** — Manifest Route Code based on  Origin Code & Destination Code _(validated: Yes)_ · e.g. `CGK10000UPG10000` · **checked**
- **MANIFEST_FROM** — Manifest Origin Code _(validated: Yes)_ · e.g. `CGK10000` · **checked**
- **MANIFEST_THRU** — Manifest next destination and/or pitstop _(validated: Yes)_ · e.g. `CGX10000` · **checked**
- **MANIFEST_NOTICE** — Manifest Notice from user additional description _(validated: Yes)_ · e.g. `CGK10000 TO UPG10000 (FROM MEGAHUB)`
- **MANIFEST_APPROVED** — Manifest Approval (Y/N) _(validated: Yes)_ · e.g. `Y` · **checked**
- **MANIFEST_ORIGIN** — Manifest Origin Code _(validated: Yes)_ · e.g. `CGK10000` · **checked**
- **MANIFEST_CODE** — Manifest type _(validated: Yes)_ · e.g. `1` · **checked**
- **MANIFEST_UID** — User admin yang membuat manifest number _(validated: Yes)_ · e.g. `AUTOMHUB` · **checked**
- **MANIFEST_CRDATE** — Time and Date Manifest Document is Approved _(validated: Yes)_ · e.g. `45976.2089699074` · **checked**
- **MANIFEST_CANCELED** — Manifest Cancelled (Y/N) _(validated: Yes)_ · e.g. `N` · **checked**
- **MANIFEST_CANCELED_UID** — User admin yang cancel manifest _(validated: Yes)_

## CMS_MFCNOTE

- **MFCNOTE_MAN_NO** — Unique identifier for Manifest _(validated: Yes)_ · e.g. `CGK/OM/102689245` · **checked**
- **MFCNOTE_BAG_NO** — Unique identifier for Manifest Bag _(validated: Yes)_ · e.g. `1181251115045420` · **checked**
- **MFCNOTE_NO** — The unique identifier for an individual shipment (Airway Bill). _(validated: Yes)_ · e.g. `0117762502235141` · **checked**
- **MFCNOTE_WEIGHT** — Package weight _(validated: Yes)_ · e.g. `1` · **checked**
- **MFCNOTE_CRDATE** — Time and Date Manifest has been scanned (Real) _(validated: Yes)_ · e.g. `45976.2089699074` · **checked**

## CMS_DSTATUS

- **DSTATUS_NO** — Unique identifier for Irregularities _(validated: Yes)_ · e.g. `PNK/IRG/00008618` · **checked**
- **DSTATUS_CNOTE_NO** — The unique identifier for an individual shipment (Airway Bill). _(validated: Yes)_ · e.g. `331380001273322` · **checked**
- **DSTATUS_STATUS** — Status Code _(validated: Yes)_ · e.g. `HL3`
- **DSTATUS_REMARKS** — Additional Description _(validated: Yes)_ · e.g. `JADWAL AIR UPAS 08/10/22`
- **CREATE_DATE** — Date and Time Cnote is inserted into to irregular _(validated: Yes)_ · e.g. `2022-10-06 12:38:12` · **checked**
- **DSTATUS_STATUS_DATE** — Date and Time Cnote has been scanned as irregular _(validated: Yes)_ · e.g. `2022-10-06 12:35:53` · **checked**
- **DSTATUS_MANIFEST_NO_OLD** — Previous Manifest number _(validated: Yes)_
- **DSTATUS_BAG_NO_OLD** — Previous Bag Number _(validated: Yes)_
- **DSTATUS_MANIFEST_NO_NEW** — New Manifest Number _(validated: Yes)_
- **DSTATUS_MANIFEST_DEST** — Route Code (Origin & Destination Code) _(validated: Yes)_
- **DSTATUS_MANIFEST_THRU** — Manifest next destination and/or pitstop _(validated: Yes)_
- **DSTATUS_ZONE_CODE** — Zona Code User Entry _(validated: Yes)_ · e.g. `PNK004` · **checked**

## CMS_MMBAG

- **MMBAG_BRANCH** — Bag Branch Code _(validated: not confirmed)_ · e.g. `SOC000` · **checked**
- **MMBAG_NO** — Unique Identifier for Bag _(validated: not confirmed)_ · e.g. `AY10598172` · **checked**
- **MMBAG_ORIGIN** — Bag Origin Code _(validated: not confirmed)_ · e.g. `SOC1000` · **checked**
- **MMBAG_DESTINATION** — Bag Destination Code _(validated: not confirmed)_ · e.g. `SUX1000` · **checked**
- **MMBAG_DATE** — Time & Date Bag Document is Generated _(validated: not confirmed)_ · e.g. `2019-12-27 15:14:41.000` · **checked**
- **MMBAG_QTY** — Jumlah bag dalam master bag _(validated: not confirmed)_ · e.g. `10` · **checked**
- **MMBAG_WEIGHT** — Total berat dalam master bag _(validated: not confirmed)_ · e.g. `22` · **checked**
- **MMBAG_USER** — UserID who created bag _(validated: not confirmed)_ · e.g. `ANDSOC` · **checked**
- **MMBAG_USER_APPROVE** — UserID who approve bag _(validated: not confirmed)_ · e.g. `PRAMU` · **checked**
- **MMBAG_DATE_APPROVE** — Time & Date of bag approval _(validated: not confirmed)_ · e.g. `2022-12-22 11:30:24.000` · **checked**
- **MMBAG_APPROVED** — Bag Approval (Y/Null) _(validated: not confirmed)_ · e.g. `Y` · **checked**
- **MMBAG_REMARKS** — Additional Description _(validated: not confirmed)_ · e.g. `NULL`

## CMS_MFBAG

- **MFBAG_MAN_NO** — Unique identifier for Manifest _(validated: Yes)_ · e.g. `SUB/TM/00037321` · **checked**
- **MFBAG_NO** — Unique identifier for Bag _(validated: Yes)_ · e.g. `AA54289417` · **checked**
- **MFBAG_ACT_WEIGHT** — Manifest Bag Weight Actual based on re-weighting Bag _(validated: Yes)_ · e.g. `10` · **checked**
- **MFBAG_CTC_WEIGHT** — Manifest Bag Weight on Paper _(validated: Yes)_ · e.g. `10` · **checked**
- **MFBAG_STATUS** — Remarks _(validated: Yes)_ · e.g. `ND`
- **MFBAG_MAN_REF** — Previous Manifest _(validated: Yes)_ · e.g. `MXG/OM/0037062` · **checked**
- **MFBAG_ROUTE** — Bag Route _(validated: Yes)_ · e.g. `MXG10000DPS10000` · **checked**
- **MFBAG_CRDATE** — MFBag Create Date _(validated: Yes)_ · e.g. `2012-07-03 00:13:08.000` · **checked**
- **ESB_TIME** — Time and Date Bag has been scanned (Real) _(validated: Yes)_ · e.g. `2013-06-17 02:06:23.096` · **checked**
- **ESB_ID** — ID Oracle DB _(validated: Yes)_ · e.g. `DF4B500478CB1840E0440010E010089C` · **checked**

## CMS_DMBAG

- **DMBAG_NO** — Unique identifier for Bag Master _(validated: Yes)_ · e.g. `AA66861663` · **checked**
- **DMBAG_BAG_NO** — Unique identifier for Manifest Bag _(validated: Yes)_ · e.g. `AA66861740` · **checked**
- **DMBAG_ORIGIN** — Manifest Bag Origin Code _(validated: Yes)_ · e.g. `SOC10000` · **checked**
- **DMBAG_DESTINATION** — Manifest Bag Destination Code _(validated: Yes)_ · e.g. `PLM10000` · **checked**
- **DMBAG_WEIGHT** — Manifest Bag weight _(validated: Yes)_ · e.g. `1` · **checked**
- **ESB_TIME** — Time and Date Bag has been scanned (Real) _(validated: Yes)_ · e.g. `11/16/2025 1:10:05.434178000 AM` · **checked**
- **ESB_ID** — ID Oracle DB _(validated: Yes)_ · e.g. `43A6A118BB9DC60EE0635B64110A38D8` · **checked**

## CMS_MSMU

- **MSMU_NO** — The unique identifier for SMU _(validated: Yes)_ · e.g. `CGXMGH8393736SR` · **checked**
- **MSMU_DATE** — Time & Date SMU Document is Generated _(validated: Yes)_ · e.g. `45977.3838425926` · **checked**
- **MSMU_ORIGIN** — Manifest Bag Origin Code _(validated: Yes)_ · e.g. `CGX000` · **checked**
- **MSMU_DESTINATION** — Manifest Bag Destination Code _(validated: Yes)_ · e.g. `BDO000` · **checked**
- **MSMU_FLIGHT_NO** — Manifest Bag Flight Number _(validated: Yes)_ · e.g. `CGX4400` · **checked**
- **MSMU_FLIGHT_DATE** — Time & Date for Bag Flight Departure _(validated: Yes)_ · e.g. `45977` · **checked**
- **MSMU_ETD** — Time & Date for Bag Estimated Time Departure _(validated: Yes)_ · e.g. `45977.40625` · **checked**
- **MSMU_ETA** — Time & Date for Bag Estimated Time Arrival _(validated: Yes)_ · e.g. `45977.6145833333` · **checked**
- **MSMU_QTY** — Bag quantity of Package _(validated: Yes)_ · e.g. `86` · **checked**
- **MSMU_WEIGHT** — Bag weight _(validated: Yes)_ · e.g. `515` · **checked**
- **MSMU_USER** — User who generate the SMU document _(validated: Yes)_ · e.g. `MUHUDIN` · **checked**
- **MSMU_FLAG** — Approval for SMU (Y/Null) _(validated: Yes)_ · e.g. `Y` · **checked**
- **MSMU_REMARKS** — Additional Description _(validated: Yes)_
- **MSMU_STATUS** — Vendor _(validated: Yes)_ · e.g. `T00043` · **checked**
- **MSMU_WRH_DATE** — Time & Date bag arrives in Airport Warehouse _(validated: Yes)_ · e.g. `45977.5604166667` · **checked**
- **MSMU_WRH_TIME** — Time Zone for MSMU_WRH_DATE _(validated: Yes)_ · e.g. `WIB` · **checked**
- **MSMU_OFF_DATE** — Time & Date bag arrives in Office Inbound _(validated: Yes)_ · e.g. `45977.59375` · **checked**
- **MSMU_OFF_TIME** — Time Zone for MSMU_OFF_TIME _(validated: Yes)_ · e.g. `WIB` · **checked**
- **MSMU_CONFIRM** — Quality check if there is any defects _(validated: Yes)_ · e.g. `CONFIRM` · **checked**
- **MSMU_CANCEL** — (Y/Null) _(validated: Yes)_
- **MSMU_USER_CANCEL** — User who made the cancellation _(validated: Yes)_
- **MSMU_REPLACE** — Change SMU _(validated: Yes)_
- **MSMU_MODA** — Transportation Mode (Air/Ground/Water/Kalok) _(validated: Yes)_ · e.g. `BB123` · **checked**
- **MSMU_POLICE_LICENSE_PLATE** — Vehicle License Plate _(validated: Yes)_ · e.g. `D8217FU`
- **MSMU_HOURS** — In minutes amount of time ETD to ETA _(validated: Yes)_ · e.g. `300` · **checked**

## CMS_DSMU

- **DSMU_NO** — Unique Identifier SMU Number _(validated: Yes)_ · e.g. `CGXMGH8393736SR` · **checked**
- **DSMU_FLIGHT_NO** — Manifest Bag Flight or Ground Number _(validated: Yes)_ · e.g. `CGX4400` · **checked**
- **DSMU_FLIGHT_DATE** — Date for Bag Flight Departure _(validated: Yes)_ · e.g. `45977` · **checked**
- **DSMU_BAG_NO** — Unique Identifier for DMBag and MFBAG _(validated: Yes)_ · e.g. `1127251115235020` · **checked**
- **DSMU_WEIGHT** — Manifest Bag Weight _(validated: Yes)_ · e.g. `10` · **checked**
- **DSMU_BAG_ORIGIN** — Manifest Bag Origin Code _(validated: Yes)_ · e.g. `CGK10000` · **checked**
- **DSMU_BAG_DESTINATION** — Manifest Bag Destination Code _(validated: Yes)_ · e.g. `BDO10100` · **checked**
- **ESB_TIME** — Bag or Master Bag entry to SMU _(validated: Yes)_ · e.g. `2025-11-16 09:21:31.770000` · **checked**
- **ESB_ID** — ID Oracle DB _(validated: Yes)_ · e.g. `43AD1BFBC1116CF4E0635B64110AA998` · **checked**
- **DSMU_POLICE_LICENSE_PLATE** — Vehicle License Plate _(validated: Yes)_ · e.g. `D8217FU`

## CMS_DRSHEET_PRA

- **DRSHEET_NO** — Pra-Runsheet Unique Identifier for Last Mile Delivery _(validated: not confirmed)_ · e.g. `CGK/PRA/03533128` · **checked**
- **DRSHEET_CNOTE_NO** — The unique identifier for an individual shipment (Airway Bill). _(validated: not confirmed)_ · e.g. `137812502563921` · **checked**
- **CREATION_DATE** — Time and Date Pra-Runsheet is Generated _(validated: not confirmed)_ · e.g. `45977.944375` · **checked**

## CMS_DRSHEET

- **DRSHEET_NO** — Runsheet Number _(validated: Yes)_ · e.g. `CGK/DRI/29855138` · **checked**
- **DRSHEET_CNOTE_NO** — The unique identifier for an individual shipment (Airway Bill). _(validated: Yes)_ · e.g. `137812502563921` · **checked**
- **DRSHEET_DATE** — Time and Date the Cnote has been received by Courier _(validated: Yes)_ · e.g. `45977.6761805556` · **checked**
- **DRSHEET_STATUS** — Runsheet Status _(validated: Yes)_ · e.g. `D01` · **checked**
- **DRSHEET_RECEIVER** — Receiver Name _(validated: Yes)_ · e.g. `TONNY GUNAWAN` · **checked**
- **DRSHEET_FLAG** — Runsheet Flag (Y/Null) _(validated: Yes)_ · e.g. `Y` · **checked**
- **DRSHEET_UID** — Runsheet Destination Code _(validated: Yes)_ · e.g. `CGK16204` · **checked**
- **DRSHEET_UDATE** — Time and Date the Runsheet is Updated _(validated: Yes)_ · e.g. `45977.6762037037` · **checked**
- **CREATION_DATE** — Time and Date the Runsheet is scanned airway bill (Real) by Admin _(validated: Yes)_ · e.g. `45977.5742708333` · **checked**

## CMS_MRSHEET

- **MRSHEET_BRANCH** — Runsheet Branch _(validated: not confirmed)_ · e.g. `UPG000` · **checked**
- **MRSHEET_NO** — Unique Identifier for Runsheet _(validated: not confirmed)_ · e.g. `UPG/DRI/05419548` · **checked**
- **MRSHEET_DATE** — Time and Date Runsheet document is Generated _(validated: not confirmed)_ · e.g. `45977.4364814815` · **checked**
- **MRSHEET_COURIER_ID** — Courier ID for delivering the Runsheet _(validated: not confirmed)_ · e.g. `UPG1934` · **checked**
- **MRSHEET_UID** — User ID for the Courier delivering the Runsheet _(validated: not confirmed)_ · e.g. `AGIUPG` · **checked**
- **MRSHEET_UDATE** — Time and Date Runsheet Updated if any changes _(validated: not confirmed)_ · e.g. `45977.460775463` · **checked**
- **MRSHEET_APPROVED_DR** — Runsheet approval (Y/N) _(validated: not confirmed)_ · e.g. `Y` · **checked**
- **MRSHEET_UID_DR** — User ID for Runsheet Approval _(validated: not confirmed)_ · e.g. `AGIUPG` · **checked**

## LASTMILE_COURIER

- **COURIER_ID** — Courier Identification Number _(validated: Yes)_ · e.g. `UPG1934`
- **COURIER_NAME** — Courier's Name _(validated: Yes)_ · e.g. `ALIMSYAH BAHRUM S Z`
- **COURIER_REGIONAL** — Courier's Region _(validated: Yes)_ · e.g. `SULAWESI - PAPUA`
- **COURIER_BRANCH** — Courier's Branch Code _(validated: Yes)_ · e.g. `UPG000`
- **COURIER_ZONE** — Courier's Branch Zone Code _(validated: Yes)_ · e.g. `UPG002`
- **COURIER_ORIGIN** — Courier's Origin Code _(validated: Yes)_ · e.g. `UPG10000`
- **COURIER_ACTIVE** — Active Status of Courier (1/0) _(validated: Yes)_ · e.g. `1`
- **COURIER_SP_VALUE** — Smart Point (1/0) _(validated: Yes)_ · e.g. `1`
- **COURIER_INCENTIVE_GROUP** — Incentive Group _(validated: Yes)_ · e.g. `SHIFT_1`
- **COURIER_ARMADA** — Vehicle Type _(validated: Yes)_ · e.g. `MOTOR`
- **COURIER_EMPLOYEE_STATUS** — Courier's Employee Status _(validated: Yes)_
- **COURIER_CREATED_AT** — Time and Date Courier account is created _(validated: Yes)_ · e.g. `45776.6231944444`
- **COURIER_UPDATED_AT** — Time and Date Courier account is updated _(validated: Yes)_ · e.g. `45777.3583217593`
- **COURIER_TYPE** — Courier's Type _(validated: Yes)_ · e.g. `2`

## CMS_CNOTE_POD

- **CNOTE_POD_NO** — The unique identifier for an individual shipment (Airway Bill). _(validated: Yes)_ · e.g. `117762502235141` · **checked**
- **CNOTE_POD_DATE** — Time and Date the Cnote has been received by Courier _(validated: Yes)_ · e.g. `45977.58409` · **checked**
- **CNOTE_POD_RECEIVER** — Name of Receiver _(validated: Yes)_ · e.g. `GOFUR` · **checked**
- **CNOTE_POD_STATUS** — Runsheet Status _(validated: Yes)_ · e.g. `D09` · **checked**
- **CNOTE_POD_DELIVERED** — Package delivered to Receiver (Yes/Null) _(validated: Yes)_ · e.g. `Y` · **checked**
- **CNOTE_POD_DOC_NO** — Document Number for Proof of Delivery _(validated: Yes)_ · e.g. `UPG/DRI/05419548` · **checked**
- **CNOTE_POD_CREATION_DATE** — Time and Date the Proof of Delivery has been made in JNE server _(validated: Yes)_ · e.g. `45977.43763` · **checked**

## CMS_DHOV_RSHEET

- **DHOV_RSHEET_NO** — Unique identifier for Handover Runsheet _(validated: Yes)_ · e.g. `UPG/HRS/02072389` · **checked**
- **DHOV_RSHEET_CNOTE** — The unique identifier for an individual shipment (Airway Bill). _(validated: Yes)_ · e.g. `0117762502235141` · **checked**
- **DHOV_RSHEET_DO** — Surat Jalan untuk Notifikasi Customer _(validated: Yes)_
- **DHOV_RSHEET_COD** — Cash On Delivery amount _(validated: Yes)_ · e.g. `0` · **checked**
- **DHOV_RSHEET_UNDEL** — Runsheet Undelivered (1/Null) _(validated: Yes)_ · **checked**
- **DHOV_RSHEET_QTY** — Runsheet Package Quantity _(validated: Yes)_ · e.g. `1` · **checked**
- **CREATE_DATE** — Time and Date Scan Cnote for HRS (Real) _(validated: Yes)_ · e.g. `45977.8110416667` · **checked**
- **DHOV_RSHEET_UZONE** — Zone Code for HRS _(validated: Yes)_ · e.g. `UPG002` · **checked**
- **DHOV_RSHEET_CYCLE** — Flag Cnote has been recycled for next attempt delivery _(validated: Yes)_ · e.g. `Y` · **checked**
- **DHOV_RSHEET_RSHEETNO** — Unique Identifier for Runsheet _(validated: Yes)_ · e.g. `UPG/DRI/05419548` · **checked**
- **DHOV_DRSHEET_EPAY_VEND** — Vendor payment _(validated: Yes)_
- **DHOV_DRSHEET_EPAY_TRXID** — Transaction ID _(validated: Yes)_
- **DHOV_DRSHEET_EPAY_AMOUNT** — Amount of Cash on Delivery _(validated: Yes)_ · e.g. `0` · **checked**
- **DHOV_DRSHEET_EPAY_DEVICE** — Device ID _(validated: Yes)_ · e.g. `PAKETID` · **checked**
- **DHOV_DRSHEET_STATUS** — Delivery Status _(validated: Yes)_ · e.g. `D09` · **checked**

## CMS_MHOUNDEL_POD

- **MHOUNDEL_BRANCH_ID** — Branch Code of Undelivered Package/Runsheet _(validated: not confirmed)_ · e.g. `CGK000` · **checked**
- **MHOUNDEL_NO** — Unique Identifier for Runsheet _(validated: not confirmed)_ · e.g. `CGK/HOC/00566988` · **checked**
- **MHOUNDEL_REMARKS** — Remarks or Description about Undelivered _(validated: not confirmed)_ · e.g. `AU Ex UNDEL`
- **MHOUNDEL_DATE** — Time and Date of Reported Undelivered by Tracing Team _(validated: not confirmed)_ · e.g. `45978.5240740741` · **checked**
- **MHOUNDEL_USER_ID** — User ID for the Courier delivering the Runsheet _(validated: not confirmed)_ · e.g. `PUTRATHG` · **checked**
- **MHOUNDEL_ZONE** — Zone Code of Undelivered Package/Runsheet _(validated: not confirmed)_ · e.g. `CGK843` · **checked**
- **MHOUNDEL_APPROVE** — Undelivered Approval _(validated: not confirmed)_ · e.g. `Y` · **checked**
- **MHOUNDEL_USER1** — User ID approving the Undelivered _(validated: not confirmed)_ · e.g. `PUTRATHG` · **checked**
- **MHOUNDEL_USER2** — User ID approving the Undelivered _(validated: not confirmed)_ · e.g. `SALIMCGK`
- **MHOUNDEL_SIGNDATE** — Time and Date signed as Undelivered _(validated: not confirmed)_ · e.g. `45978` · **checked**

## CMS_DHOUNDEL_POD

- **DHOUNDEL_NO** — Unique Identifier for HOC _(validated: not confirmed)_ · e.g. `CGK/HOC/00566988` · **checked**
- **DHOUNDEL_CNOTE_NO** — The unique identifier for an individual shipment (Airway Bill). _(validated: not confirmed)_ · e.g. `CGKEC68097539925` · **checked**
- **DHOUNDEL_QTY** — Undelivered Package Quantity _(validated: not confirmed)_ · e.g. `1` · **checked**
- **DHOUNDEL_REMARKS** — Remarks or Description about Undelivered _(validated: not confirmed)_ · e.g. `AU INFO WA CNEE`
- **DHOUNDEL_HRS** — Unique Identifier for CMS_DHOV_RSHEET _(validated: not confirmed)_ · e.g. `CGK/HRS/14869178` · **checked**
- **CREATE_DATE** — Time and Date Scan Cnote for HOC _(validated: not confirmed)_ · e.g. `45978.5241782407` · **checked**

## CMS_MHOCNOTE

- **MHOCNOTE_BRANCH_ID** — Handover to Cabang Branch Code _(validated: not confirmed)_ · e.g. `UPG000` · **checked**
- **MHOCNOTE_ZONE** — Handover to Cabang Zone Code _(validated: not confirmed)_ · e.g. `UPG122` · **checked**
- **MHOCNOTE_NO** — Unique Identifier for Handover to Cabang _(validated: not confirmed)_ · e.g. `UPG/HVO/01140922` · **checked**
- **MHOCNOTE_DATE** — Time and Date HVO is Generated _(validated: not confirmed)_ · e.g. `45976.9922337963` · **checked**
- **MHOCNOTE_ZONE_DEST** — Zone Code Destination _(validated: not confirmed)_ · e.g. `UPG122` · **checked**
- **MHOCNOTE_USER_ID** — User ID that generates HVO Dokumen _(validated: not confirmed)_ · e.g. `SUHARDID` · **checked**
- **MHOCNOTE_USER1** — User ID that approves HVO _(validated: not confirmed)_ · e.g. `SUHARDID`
- **MHOCNOTE_USER2** — User ID that approves HVO _(validated: not confirmed)_
- **MHOCNOTE_SIGNDATE** — Time and Date HVO is approved _(validated: not confirmed)_ · e.g. `45977.0126851852` · **checked**
- **MHOCNOTE_APPROVE** — Handover to Cabang Approval (Y/N) _(validated: not confirmed)_ · e.g. `Y` · **checked**
- **MHOCNOTE_REMARKS** — Handover to Cabang Additional Remarks _(validated: not confirmed)_ · e.g. `SELATAN`
- **MHOCNOTE_COURIER_ID** — Courier ID for HVO _(validated: not confirmed)_
- **MHOCNOTE_APP_DATE** — Time and Date HVO is approved _(validated: not confirmed)_ · **checked**

## CMS_DHOCNOTE

- **DHOCNOTE_NO** — Unique Identifier for Handover to Cabang _(validated: not confirmed)_ · e.g. `UPG/HVO/01140922` · **checked**
- **DHOCNOTE_CNOTE_NO** — The unique identifier for an individual shipment (Airway Bill). _(validated: not confirmed)_ · e.g. `117762502235141` · **checked**
- **DHOCNOTE_QTY** — Package quantity _(validated: not confirmed)_ · e.g. `1` · **checked**
- **DHOCNOTE_REMARKS** — Handover to Cabang Remarks _(validated: not confirmed)_
- **DHOCNOTE_TDATE** — Time and Date HVO is scanned by Admin _(validated: not confirmed)_ · e.g. `45977.01269` · **checked**

## CMS_COST_MTRANSIT_AGEN

- **MANIFEST_NO** — Unique identifier for Transit Agent Manifest _(validated: not confirmed)_ · e.g. `PLM/MTS/02503551` · **checked**
- **MANIFEST_DATE** — Time and Date MTS/MTI Document is Generated _(validated: not confirmed)_ · e.g. `45978.9034722222` · **checked**
- **BRANCH_ID** — Transit Agent Branch Code _(validated: not confirmed)_ · e.g. `PLM000` · **checked**
- **DESTINATION** — MTS/MTI Destination Code _(validated: not confirmed)_ · e.g. `PLM20805` · **checked**
- **CTC_WEIGHT** — Cnote Weight (On Paper) _(validated: not confirmed)_ · e.g. `4` · **checked**
- **ACT_WEIGHT** — Actual Weight (Real life) _(validated: not confirmed)_ · e.g. `1` · **checked**
- **MANIFEST_APPROVED** — Manifest Approval (Y/Null) _(validated: not confirmed)_ · e.g. `Y` · **checked**
- **REMARK** — Additional Description _(validated: not confirmed)_ · e.g. `B LINCIR`
- **MANIFEST_UID** — UserID who created MTS/MTI Document _(validated: not confirmed)_ · e.g. `DARMOSS` · **checked**
- **ESB_TIME** — Time and Date MTS/MTI is Approved _(validated: not confirmed)_ · e.g. `2025-11-17 21:43:29.688000` · **checked**
- **ESB_ID** — ID Oracle _(validated: not confirmed)_ · e.g. `43CC530C89D5CB3FE063EE64110A2F42` · **checked**
- **MANIFEST_DOC_REF** — If MANIFEST_NO is MTI then MTS will appear _(validated: not confirmed)_

## CMS_COST_DTRANSIT_AGEN

- **DMANIFEST_NO** — Unique Identifier for MTS/MTI _(validated: not confirmed)_ · e.g. `PLM/MTS/02503551` · **checked**
- **CNOTE_NO** — The unique identifier for an individual shipment (Airway Bill). _(validated: not confirmed)_ · e.g. `1219572500887900` · **checked**
- **CNOTE_ORIGIN** — Origin Code _(validated: not confirmed)_ · e.g. `SOC20400` · **checked**
- **CNOTE_DESTINATION** — Destination Code _(validated: not confirmed)_ · e.g. `PLM20805` · **checked**
- **CNOTE_QTY** — Package Quantity _(validated: not confirmed)_ · e.g. `1` · **checked**
- **CNOTE_WEIGHT** — Package Weight _(validated: not confirmed)_ · e.g. `1` · **checked**
- **CNOTE_SERVICES_CODE** — Service Type _(validated: not confirmed)_ · e.g. `REG23` · **checked**
- **ESB_TIME** — Time and Date MTS/MTI is scanned _(validated: not confirmed)_ · e.g. `2025-11-17 21:43:29.732000` · **checked**
- **ESB_ID** — Oracle ID _(validated: not confirmed)_ · e.g. `43CC5D061FAF4EB6E063EE64110A4CE8` · **checked**
- **DMANIFEST_DOC_REF** — If MANIFEST_NO is MTI then MTS will appear _(validated: not confirmed)_

## T_MDT_CITY_ORIGIN

- **CITY_BRANCH** — Branch Code _(validated: not confirmed)_ · e.g. `AMI000`
- **CITY_CODE** — City Code _(validated: not confirmed)_ · e.g. `AMI10011`
- **CITY_ORIGIN** — City Origin Code _(validated: not confirmed)_ · e.g. `AMI10000`
- **CITY_MTS** — City Transit Code _(validated: not confirmed)_ · e.g. `AMI10000`
- **CITY_ACTIVE** — Active Status (Y/N) _(validated: not confirmed)_ · e.g. `Y`
- **CREATE_DATE** — Time and Date Branch Created _(validated: not confirmed)_ · e.g. `45759.588125`

## CMS_MSJ

- **MSJ_NO** — Unique Identifier for Drop Off _(validated: not confirmed)_ · e.g. `UPG/DO/00061354` · **checked**
- **MSJ_BRANCH_ID** — Branch Code _(validated: not confirmed)_ · e.g. `UPG000` · **checked**
- **MSJ_DATE** — Time and Date DO Document is Generated _(validated: not confirmed)_ · e.g. `45977.0130208333` · **checked**
- **MSJ_USER1** — UserID creating DO _(validated: not confirmed)_ · e.g. `SUHARDID` · **checked**
- **MSJ_USER2** — UserID Approve DO _(validated: not confirmed)_ · e.g. `FERDIUPG` · **checked**
- **MSJ_APPROVE** — Drop Off Approval (Y/N) _(validated: not confirmed)_ · e.g. `Y` · **checked**
- **MSJ_CDATE** — Time and Date DO Document is Generated _(validated: not confirmed)_ · e.g. `45977.0130208333` · **checked**
- **MSJ_UID** — UserID for Drop Off _(validated: not confirmed)_ · e.g. `SUHARDID` · **checked**
- **MSJ_REMARKS** — Drop Off Remarks _(validated: not confirmed)_ · e.g. `SELATAN`
- **MSJ_SIGNDATE** — Date DO Document is approved _(validated: not confirmed)_ · e.g. `45977` · **checked**
- **MSJ_DEST** — DO Destination Code _(validated: not confirmed)_ · e.g. `UPG122` · **checked**
- **MSJ_ORIG** — DO Origin Code _(validated: not confirmed)_ · e.g. `UPG122` · **checked**
- **MSJ_COURIER_ID** — Courier Identification Number _(validated: not confirmed)_

## CMS_DSJ

- **DSJ_NO** — Unique Identifier for Drop Off Document _(validated: Yes)_ · e.g. `UPG/DO/00061354` · **checked**
- **DSJ_BAG_NO** — Unique Identifier for Bag for HVO _(validated: Yes)_ · e.g. `UPG122/24416050` · **checked**
- **DSJ_HVO_NO** — Unique Identifier for Handover to Cabang _(validated: Yes)_ · e.g. `UPG/HVO/01140922` · **checked**
- **DSJ_UID** — UserID creating DO Document _(validated: Yes)_ · e.g. `SUHARDID` · **checked**
- **DSJ_CDATE** — Time and Date DO is scanned _(validated: Yes)_ · e.g. `45977.0131134259` · **checked**

## CMS_RDSJ

- **RDSJ_NO** — Unique Identifier for RDO _(validated: not confirmed)_ · e.g. `CGK/RDO/02461238` · **checked**
- **RDSJ_BAG_NO** — Unique identifier for HVO Bag _(validated: not confirmed)_ · e.g. `2001251115110110` · **checked**
- **RDSJ_HVO_NO** — Unique identifier for HVO Document _(validated: not confirmed)_ · e.g. `CGK/HVO/10852068` · **checked**
- **RDSJ_UID** — User ID Creating RDO Document _(validated: not confirmed)_
- **RDSJ_CDATE** — Date and Time RDO is scanned _(validated: not confirmed)_ · e.g. `45976.9208217593` · **checked**
- **RDSJ_HVI_NO** — Unique identifier for Handover Inbound _(validated: not confirmed)_ · e.g. `CGK/HVI/10140020` · **checked**

## CMS_MHICNOTE

- **MHICNOTE_BRANCH_ID** — Branch Code _(validated: not confirmed)_ · e.g. `UPG000` · **checked**
- **MHICNOTE_ZONE** — User Zone Code _(validated: not confirmed)_ · e.g. `UPG122` · **checked**
- **MHICNOTE_NO** — Unique Identifier for Handover Inbound HVI _(validated: not confirmed)_ · e.g. `UPG/HVI/00951524` · **checked**
- **MHICNOTE_REF_NO** — Unique Identifier for Handover Outbound HVO _(validated: not confirmed)_ · e.g. `UPG/HVO/01140922` · **checked**
- **MHICNOTE_DATE** — Time and Date HVI is Generated _(validated: not confirmed)_ · e.g. `45977.3607986111` · **checked**
- **MHICNOTE_ZONE_ORIG** — HVI Origin Code _(validated: not confirmed)_ · e.g. `UPG122` · **checked**
- **MHICNOTE_USER_ID** — User ID Generated HVI _(validated: not confirmed)_ · e.g. `AGIUPG` · **checked**
- **MHICNOTE_USER1** — User ID that Approve HVI _(validated: not confirmed)_
- **MHICNOTE_USER2** — _no business definition_ _(validated: not confirmed)_
- **MHICNOTE_SIGNDATE** — Date for HVI Approval _(validated: not confirmed)_ · e.g. `45977` · **checked**
- **MHICNOTE_APPROVE** — Runsheet Approval (Y/Null) _(validated: not confirmed)_ · e.g. `Y` · **checked**

## CMS_DHICNOTE

- **DHICNOTE_NO** — Unique Identifier for HVI _(validated: not confirmed)_ · e.g. `UPG/HVI/00951524` · **checked**
- **DHICNOTE_CNOTE_NO** — The unique identifier for an individual shipment (Airway Bill). _(validated: not confirmed)_ · e.g. `0117762502235141` · **checked**
- **DHICNOTE_QTY** — Package quantity _(validated: not confirmed)_ · e.g. `1` · **checked**
- **DHICNOTE_REMARKS** — Remarks _(validated: not confirmed)_
- **DHICNOTE_TDATE** — Time and Date Cnote is Scanned for HVI _(validated: not confirmed)_ · e.g. `45977.3607986111` · **checked**

## CMS_DBAG_HO

- **DBAG_HO_NO** — Unique identifier for Handover _(validated: Yes)_ · e.g. `UPG/HVO/01140922` · **checked**
- **DBAG_NO** — Unique identifier for Bag _(validated: Yes)_ · e.g. `UPG122/24416050` · **checked**
- **DBAG_CNOTE_NO** — The unique identifier for an individual shipment (Airway Bill). _(validated: Yes)_ · e.g. `117762502235141` · **checked**
- **DBAG_CNOTE_QTY** — Package quantity _(validated: Yes)_ · e.g. `1` · **checked**
- **DBAG_CNOTE_WEIGHT** — Package weight _(validated: Yes)_ · e.g. `1` · **checked**
- **DBAG_CNOTE_DESTINATION** — Destination Code _(validated: Yes)_ · e.g. `UPG10004` · **checked**
- **CDATE** — Time and Date Bag No is Generated _(validated: Yes)_ · e.g. `45977.0081597222` · **checked**
- **DBAG_CNOTE_SERVICE** — Service Type _(validated: Yes)_ · e.g. `REG23` · **checked**
- **DBAG_CNOTE_DATE** — Time and Date Bag No is Approved _(validated: Yes)_ · e.g. `45976.0494791667` · **checked**
- **DBAG_ZONE_DEST** — Destination Zode Code _(validated: Yes)_ · e.g. `UPG122` · **checked**

## ORA_ZONE

- **ZONE_BRANCH** — Zone Branch Code _(validated: Yes)_ · e.g. `CLG000`
- **ZONE_CODE** — Primary Identifier Branch Code _(validated: Yes)_ · e.g. `CLG491`
- **ZONE_DESC** — Branch Description _(validated: Yes)_ · e.g. `CLG, DROP POINT LEBAK GEDONG`
- **ZONE_UID** — User ID for Branch _(validated: Yes)_ · e.g. `DIFA`
- **ZONE_ACTIVE** — Active Status (Y/N) _(validated: Yes)_ · e.g. `Y`
- **ZONE_SEQ** — Location Details _(validated: Yes)_ · e.g. `CLG`
- **ZONE_DATE** — Time and Date Branch is Active _(validated: Yes)_ · e.g. `45058.6517939815`
- **ZONE_TYPE** — Branch Type _(validated: Yes)_ · e.g. `2`
- **ZONE_ECNOTE_PARM** — _no business definition_ _(validated: Yes)_
- **ZONE_ORIGIN** — Origin Code _(validated: Yes)_ · e.g. `CLG20200`
- **ZONE_NAME** — _no business definition_ _(validated: Yes)_
- **ZONE_ADDR1** — _no business definition_ _(validated: Yes)_
- **ZONE_ADDR2** — _no business definition_ _(validated: Yes)_
- **ZONE_ADDR3** — _no business definition_ _(validated: Yes)_
- **ZONE_DP_FLAG** — _no business definition_ _(validated: Yes)_
- **ZONE_LATITUDE** — Latitude _(validated: Yes)_
- **ZONE_LONGTITIDE** — Longitude _(validated: Yes)_
- **ZONE_KOTA** — _no business definition_ _(validated: Yes)_
- **ZONE_KECAMATAN** — _no business definition_ _(validated: Yes)_
- **ZONE_PROVINSI** — _no business definition_ _(validated: Yes)_
- **ZONE_CATEGORY** — _no business definition_ _(validated: Yes)_
- **LASTUPDDTM** — _no business definition_ _(validated: Yes)_
- **LASTUPDBY** — _no business definition_ _(validated: Yes)_
- **LASTUPDPROCESS** — _no business definition_ _(validated: Yes)_
- **ZONE_KELURAHAN** — _no business definition_ _(validated: Yes)_

## ORA_USER

- **USER_ID** — User ID _(validated: not confirmed)_ · e.g. `MADRUDIN`
- **USER_NAME** — Name of User _(validated: not confirmed)_ · e.g. `UDIN`
- **USER_CUST_ID** — Customer ID _(validated: not confirmed)_
- **USER_CUST_NAME** — User Customer Name _(validated: not confirmed)_
- **USER_ZONE_CODE** — Zone Code User _(validated: not confirmed)_
- **USER_ACTIVE** — User Active Status (Y/N) _(validated: not confirmed)_ · e.g. `N`
- **USER_DATE** — Time and Date UserID is Created _(validated: not confirmed)_ · e.g. `2024-11-07 13:27:40`
- **USER_ORIGIN** — User Origin Code _(validated: not confirmed)_ · e.g. `CGK10000`
- **USER_NIK** — User Employee Code NIK _(validated: not confirmed)_ · e.g. `CGK01F01M048`
- **USER_VACANT10** — _no business definition_ _(validated: not confirmed)_
