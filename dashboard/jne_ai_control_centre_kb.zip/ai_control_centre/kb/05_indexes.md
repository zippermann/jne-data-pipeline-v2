# Index rule catalogue

All 499 checks. One block per rule — this is the retrieval unit.

## ACCU1A25

- **Element:** Accuracy
- **Table.column:** `CMS_APICUST.APICUST_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Berat paket dalam API customer lebih dari 0
- **Logic (EN):** Package weight in the customer API is greater than 0
- **Operational meaning (ID):** Berat paket yang diterima dari pelanggan via marketplace/platform harus lebih dari 0 kg. Data berat tidak boleh kosong atau bernilai nol.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## ACCU2B12A

- **Element:** Accuracy
- **Table.column:** `CMS_CNOTE.CNOTE_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Check 3 prefix depan apakah sama dengan DCORRECT_ORIGIN atau tidak?
- **Logic (EN):** Do the first 3 characters match DCORRECT_ORIGIN?
- **Operational meaning (ID):** Tiga karakter pertama kode asal pada connote dicek kesesuaiannya dengan data koreksi asal (DCORRECT_ORIGIN). Ini memastikan kode asal tidak mengalami perubahan yang tidak seharusnya.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## ACCU2B13A

- **Element:** Accuracy
- **Table.column:** `CMS_CNOTE.CNOTE_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Check 3 prefix depan apakah sama dengan DCORRECT_DEST atau tidak?
- **Logic (EN):** Do the first 3 characters match DCORRECT_DEST?
- **Operational meaning (ID):** Tiga karakter pertama kode tujuan pada connote dicek kesesuaiannya dengan data koreksi tujuan (DCORRECT_DEST). Ini memastikan kode tujuan tidak mengalami perubahan yang tidak seharusnya.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## ACCU3B12B

- **Element:** Accuracy
- **Table.column:** `CMS_CNOTE.CNOTE_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Check angka setelah 3 prefix depan apakah sama dengan DCORRECT_ORIGIN atau tidak?
- **Logic (EN):** Do the digits after the first 3 characters match DCORRECT_ORIGIN?
- **Operational meaning (ID):** Angka setelah tiga karakter pertama kode asal dicek kesesuaiannya dengan data koreksi asal. Jika berbeda, menandakan telah terjadi koreksi pada data asal pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## ACCU3B13B

- **Element:** Accuracy
- **Table.column:** `CMS_CNOTE.CNOTE_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Check angka setelah 3 prefix depan apakah sama dengan DCORRECT_DEST atau tidak?
- **Logic (EN):** Do the digits after the first 3 characters match DCORRECT_DEST?
- **Operational meaning (ID):** Kode destinasi tercatat dalam DCORRECT_DEST, yang mengindikasikan bahwa telah terjadi koreksi terhadap data destinasi.
- **Business impact:** Billing — Over-billing/Under-billing
- **Issue label:** (ACCU) Prefix Destination Code Difference (CMS Cnote vs DCorrect Destination)

## ACCU4B15

- **Element:** Accuracy
- **Table.column:** `CMS_CNOTE.CNOTE_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Berat paket mengalami koreksi dan ada di dalam table DWR
- **Logic (EN):** The package weight was corrected and the correction is present in table DWR
- **Operational meaning (ID):** Berat paket telah mengalami koreksi karena adanya masalah berat volumetrik, dan data koreksi tersebut tercatat dalam sistem. Ini berpotensi mempengaruhi tarif pengiriman yang ditagihkan.
- **Business impact:** Billing — Potential Revenue Loss
- **Issue label:** (ACCU) Package is weighted again due to volumetric weight issues

## ACCU5A6

- **Element:** Accuracy
- **Table.column:** `CMS_APICUST.APICUST_SERVICES_CODE`
- **Business indicator:** Service Code
- **Logic (ID):** Service code paket dalam API customer memang ada di CMS_DROURATE
- **Logic (EN):** The package service code in the customer API exists in CMS_DROURATE
- **Operational meaning (ID):** Kode layanan yang dikirimkan pelanggan melalui marketplace/platform harus terdaftar dalam referensi layanan JNE (DROURATE). Kode yang tidak dikenal dapat menyebabkan kesalahan tarif.
- **Business impact:** TBD
- **Issue label:** (ACCU) Service Code Does Not Exist (APICUST Service Code vs CMS DROURATE Service)

## ACCU6B6

- **Element:** Accuracy
- **Table.column:** `CMS_CNOTE.CNOTE_SERVICES_CODE`
- **Business indicator:** Service Code
- **Logic (ID):** Service code paket dalam CMS_CNOTE memang ada di CMS_DROURATE
- **Logic (EN):** The package service code in CMS_CNOTE exists in CMS_DROURATE
- **Operational meaning (ID):** Kode layanan yang tercatat dalam connote harus terdaftar dalam referensi layanan JNE (DROURATE). Kode layanan yang tidak valid dapat menyebabkan kesalahan penghitungan tarif.
- **Business impact:** TBD
- **Issue label:** (ACCU) Service Code Does Not Exist (CMS Cnote Service Code vs CMS DROURATE Service)

## COMP1A1

- **Element:** Completeness
- **Table.column:** `CMS_APICUST.APICUST_ORDER_ID`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada kiriman dari pelanggan (marketplace/platform) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1A2

- **Element:** Completeness
- **Table.column:** `CMS_APICUST.APICUST_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada kiriman dari pelanggan (marketplace/platform) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1A24

- **Element:** Completeness
- **Table.column:** `CMS_APICUST.APICUST_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Jumlah paket pada kiriman dari pelanggan (marketplace/platform) wajib terisi. Data kuantitas digunakan untuk memastikan seluruh paket tercatat dan tidak ada yang terlewat.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1A25

- **Element:** Completeness
- **Table.column:** `CMS_APICUST.APICUST_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Berat paket pada kiriman dari pelanggan (marketplace/platform) wajib terisi. Data berat adalah dasar penghitungan tarif pengiriman.
- **Business impact:** Billing — Under-billing
- **Issue label:** (----) Unmapped Governance Issue

## COMP1A3

- **Element:** Completeness
- **Table.column:** `CMS_APICUST.APICUST_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode asal pengiriman pada kiriman dari pelanggan (marketplace/platform) wajib terisi. Data asal digunakan untuk menentukan dari mana paket dikirimkan.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1A4

- **Element:** Completeness
- **Table.column:** `CMS_APICUST.APICUST_BRANCH`
- **Business indicator:** Branch ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode cabang pada kiriman dari pelanggan (marketplace/platform) wajib terisi. Data cabang diperlukan untuk menentukan lokasi asal atau tujuan proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1A5

- **Element:** Completeness
- **Table.column:** `CMS_APICUST.APICUST_CUST_NO`
- **Business indicator:** Customer Number
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor pelanggan pada kiriman dari pelanggan (marketplace/platform) wajib terisi. Data ini digunakan untuk mengidentifikasi pelanggan yang menggunakan layanan JNE.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1A6

- **Element:** Completeness
- **Table.column:** `CMS_APICUST.APICUST_SERVICES_CODE`
- **Business indicator:** Service Code
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode layanan pengiriman pada kiriman dari pelanggan (marketplace/platform) wajib terisi. Data ini menentukan jenis layanan (misalnya reguler, express) yang digunakan untuk pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1A7

- **Element:** Completeness
- **Table.column:** `CMS_APICUST.APICUST_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode tujuan pengiriman pada kiriman dari pelanggan (marketplace/platform) wajib terisi. Data tujuan menentukan ke mana paket akan dikirimkan dan berpengaruh pada tarif.
- **Business impact:** Billing — Over-billing/Under-billing
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AA1

- **Element:** Completeness
- **Table.column:** `CMS_DSJ.DSJ_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Surat Jalan wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AA2

- **Element:** Completeness
- **Table.column:** `CMS_DSJ.DSJ_BAG_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Surat Jalan wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AA3

- **Element:** Completeness
- **Table.column:** `CMS_DSJ.DSJ_HVO_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Surat Jalan wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AA4

- **Element:** Completeness
- **Table.column:** `CMS_DSJ.DSJ_UID`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Detail Surat Jalan wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AA5

- **Element:** Completeness
- **Table.column:** `CMS_DSJ.DSJ_CDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Detail Surat Jalan wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AB1

- **Element:** Completeness
- **Table.column:** `CMS_MHICNOTE.MHICNOTE_BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode cabang pada manifest Handover Inbound Connote wajib terisi. Data cabang diperlukan untuk menentukan lokasi asal atau tujuan proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AB10

- **Element:** Completeness
- **Table.column:** `CMS_MHICNOTE.MHICNOTE_SIGNDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada manifest Handover Inbound Connote wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AB2

- **Element:** Completeness
- **Table.column:** `CMS_MHICNOTE.MHICNOTE_ZONE`
- **Business indicator:** Zone Code
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode zona pada manifest Handover Inbound Connote wajib terisi. Data zona digunakan untuk menentukan area pengiriman dan mempengaruhi penentuan rute.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AB3

- **Element:** Completeness
- **Table.column:** `CMS_MHICNOTE.MHICNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada manifest Handover Inbound Connote wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AB4

- **Element:** Completeness
- **Table.column:** `CMS_MHICNOTE.MHICNOTE_REF_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada manifest Handover Inbound Connote wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AB5

- **Element:** Completeness
- **Table.column:** `CMS_MHICNOTE.MHICNOTE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada manifest Handover Inbound Connote wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AB6

- **Element:** Completeness
- **Table.column:** `CMS_MHICNOTE.MHICNOTE_ZONE_ORIG`
- **Business indicator:** Zone Code
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode zona pada manifest Handover Inbound Connote wajib terisi. Data zona digunakan untuk menentukan area pengiriman dan mempengaruhi penentuan rute.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AB7

- **Element:** Completeness
- **Table.column:** `CMS_MHICNOTE.MHICNOTE_USER_ID`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses manifest Handover Inbound Connote wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AC1

- **Element:** Completeness
- **Table.column:** `CMS_DHICNOTE.DHICNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada detail Handover Inbound Connote wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AC3

- **Element:** Completeness
- **Table.column:** `CMS_DHICNOTE.DHICNOTE_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada detail Handover Inbound Connote wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AC4

- **Element:** Completeness
- **Table.column:** `CMS_DHICNOTE.DHICNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Jumlah paket pada detail Handover Inbound Connote wajib terisi. Data kuantitas digunakan untuk memastikan seluruh paket tercatat dan tidak ada yang terlewat.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AC6

- **Element:** Completeness
- **Table.column:** `CMS_DHICNOTE.DHICNOTE_TDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada detail Handover Inbound Connote wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AD1

- **Element:** Completeness
- **Table.column:** `CMS_RDSJ.RDSJ_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Retur Detail Surat Jalan wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AD2

- **Element:** Completeness
- **Table.column:** `CMS_RDSJ.RDSJ_BAG_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Retur Detail Surat Jalan wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AD3

- **Element:** Completeness
- **Table.column:** `CMS_RDSJ.RDSJ_HVO_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Retur Detail Surat Jalan wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AD5

- **Element:** Completeness
- **Table.column:** `CMS_RDSJ.RDSJ_CDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Retur Detail Surat Jalan wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AD6

- **Element:** Completeness
- **Table.column:** `CMS_RDSJ.RDSJ_HVI_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Retur Detail Surat Jalan wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AE1

- **Element:** Completeness
- **Table.column:** `CMS_DBAG_HO.DBAG_HO_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Bag Handover Cabang wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AE10

- **Element:** Completeness
- **Table.column:** `CMS_DBAG_HO.DBAG_ZONE_DEST`
- **Business indicator:** Zone Code
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode zona pada Detail Bag Handover Cabang wajib terisi. Data zona digunakan untuk menentukan area pengiriman dan mempengaruhi penentuan rute.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AE2

- **Element:** Completeness
- **Table.column:** `CMS_DBAG_HO.DBAG_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Bag Handover Cabang wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AE3

- **Element:** Completeness
- **Table.column:** `CMS_DBAG_HO.DBAG_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Bag Handover Cabang wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AE4

- **Element:** Completeness
- **Table.column:** `CMS_DBAG_HO.DBAG_CNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Jumlah paket pada Detail Bag Handover Cabang wajib terisi. Data kuantitas digunakan untuk memastikan seluruh paket tercatat dan tidak ada yang terlewat.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AE5

- **Element:** Completeness
- **Table.column:** `CMS_DBAG_HO.DBAG_CNOTE_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Berat paket pada Detail Bag Handover Cabang wajib terisi. Data berat adalah dasar penghitungan tarif pengiriman.
- **Business impact:** Reporting — Understated weight
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AE6

- **Element:** Completeness
- **Table.column:** `CMS_DBAG_HO.DBAG_CNOTE_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode tujuan pengiriman pada Detail Bag Handover Cabang wajib terisi. Data tujuan menentukan ke mana paket akan dikirimkan dan berpengaruh pada tarif.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AE7

- **Element:** Completeness
- **Table.column:** `CMS_DBAG_HO.CDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Detail Bag Handover Cabang wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AE8

- **Element:** Completeness
- **Table.column:** `CMS_DBAG_HO.DBAG_CNOTE_SERVICE`
- **Business indicator:** Service Code
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode layanan pengiriman pada Detail Bag Handover Cabang wajib terisi. Data ini menentukan jenis layanan (misalnya reguler, express) yang digunakan untuk pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1AE9

- **Element:** Completeness
- **Table.column:** `CMS_DBAG_HO.DBAG_CNOTE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tidak terdapat timestamp pada proses bagging di tahap handover cabang.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1B1

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE.CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Connote (resi pengiriman) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1B10

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE.CNOTE_CUST_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Connote (resi pengiriman) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1B11

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE.CNOTE_ROUTE_CODE`
- **Business indicator:** Route Code
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode rute pengiriman pada Connote (resi pengiriman) wajib terisi. Data rute menentukan jalur yang digunakan untuk pengiriman paket.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1B12

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE.CNOTE_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode asal pengiriman pada Connote (resi pengiriman) wajib terisi. Data asal digunakan untuk menentukan dari mana paket dikirimkan.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1B13

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE.CNOTE_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode tujuan pengiriman pada Connote (resi pengiriman) wajib terisi. Data tujuan menentukan ke mana paket akan dikirimkan dan berpengaruh pada tarif.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1B14

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE.CNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Jumlah paket pada Connote (resi pengiriman) wajib terisi. Data kuantitas digunakan untuk memastikan seluruh paket tercatat dan tidak ada yang terlewat.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1B15

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE.CNOTE_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Berat paket pada Connote (resi pengiriman) wajib terisi. Data berat adalah dasar penghitungan tarif pengiriman.
- **Business impact:** Billing — Under-billing
- **Issue label:** (----) Unmapped Governance Issue

## COMP1B17

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE.CNOTE_SHIPPER_NAME`
- **Business indicator:** Package Detail
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Informasi detail pengirim pada Connote (resi pengiriman) wajib terisi. Data ini diperlukan sebagai identitas pengirim dalam dokumen connote.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1B18

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE.CNOTE_SHIPPER_ADDR1`
- **Business indicator:** Package Detail
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Informasi detail pengirim pada Connote (resi pengiriman) wajib terisi. Data ini diperlukan sebagai identitas pengirim dalam dokumen connote.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1B2

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE.CNOTE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Connote (resi pengiriman) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1B3

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE.CNOTE_BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode cabang pada Connote (resi pengiriman) wajib terisi. Data cabang diperlukan untuk menentukan lokasi asal atau tujuan proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1B6

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE.CNOTE_SERVICES_CODE`
- **Business indicator:** Service Code
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode layanan pengiriman pada Connote (resi pengiriman) wajib terisi. Data ini menentukan jenis layanan (misalnya reguler, express) yang digunakan untuk pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1B66

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE.CNOTE_USER`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Connote (resi pengiriman) wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1B99

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE.CNOTE_CRDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Connote (resi pengiriman) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1C1

- **Element:** Completeness
- **Table.column:** `CMS_MRCNOTE.MRCNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Master Receival Connote (dokumen penerimaan barang di gudang) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1C2

- **Element:** Completeness
- **Table.column:** `CMS_MRCNOTE.MRCNOTE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master Receival Connote (dokumen penerimaan barang di gudang) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1C3

- **Element:** Completeness
- **Table.column:** `CMS_MRCNOTE.MRCNOTE_BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode cabang pada Master Receival Connote (dokumen penerimaan barang di gudang) wajib terisi. Data cabang diperlukan untuk menentukan lokasi asal atau tujuan proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1C4

- **Element:** Completeness
- **Table.column:** `CMS_MRCNOTE.MRCNOTE_USER_ID`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Receival Connote (dokumen penerimaan barang di gudang) wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1C7

- **Element:** Completeness
- **Table.column:** `CMS_MRCNOTE.MRCNOTE_USER1`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Receival Connote (dokumen penerimaan barang di gudang) wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1C8

- **Element:** Completeness
- **Table.column:** `CMS_MRCNOTE.MRCNOTE_USER2`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Receival Connote (dokumen penerimaan barang di gudang) wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1C9

- **Element:** Completeness
- **Table.column:** `CMS_MRCNOTE.MRCNOTE_SIGNDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master Receival Connote (dokumen penerimaan barang di gudang) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1D1

- **Element:** Completeness
- **Table.column:** `CMS_DRCNOTE.DRCNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Receival Connote (dokumen penerimaan barang di gudang) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1D2

- **Element:** Completeness
- **Table.column:** `CMS_DRCNOTE.DRCNOTE_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Receival Connote (dokumen penerimaan barang di gudang) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1D3

- **Element:** Completeness
- **Table.column:** `CMS_DRCNOTE.DRCNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Jumlah paket pada Detail Receival Connote (dokumen penerimaan barang di gudang) wajib terisi. Data kuantitas digunakan untuk memastikan seluruh paket tercatat dan tidak ada yang terlewat.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1D5

- **Element:** Completeness
- **Table.column:** `CMS_DRCNOTE.DRCNOTE_TDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Detail Receival Connote (dokumen penerimaan barang di gudang) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1E1

- **Element:** Completeness
- **Table.column:** `CMS_MHI_HOC.MHI_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Master Handover Inbound Cabang wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1E11

- **Element:** Completeness
- **Table.column:** `CMS_MHI_HOC.MHI_ZONE`
- **Business indicator:** Zone Code
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode zona pada Master Handover Inbound Cabang wajib terisi. Data zona digunakan untuk menentukan area pengiriman dan mempengaruhi penentuan rute.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1E2

- **Element:** Completeness
- **Table.column:** `CMS_MHI_HOC.MHI_REF_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Master Handover Inbound Cabang wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1E3

- **Element:** Completeness
- **Table.column:** `CMS_MHI_HOC.MHI_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master Handover Inbound Cabang wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1E4

- **Element:** Completeness
- **Table.column:** `CMS_MHI_HOC.MHI_UID`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Handover Inbound Cabang wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1E5

- **Element:** Completeness
- **Table.column:** `CMS_MHI_HOC.MHI_APPROVE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master Handover Inbound Cabang wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1E6

- **Element:** Completeness
- **Table.column:** `CMS_MHI_HOC.MHI_BRANCH`
- **Business indicator:** Branch ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode cabang pada Master Handover Inbound Cabang wajib terisi. Data cabang diperlukan untuk menentukan lokasi asal atau tujuan proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1E7

- **Element:** Completeness
- **Table.column:** `CMS_MHI_HOC.MHI_APPROVE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master Handover Inbound Cabang wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1E9

- **Element:** Completeness
- **Table.column:** `CMS_MHI_HOC.MHI_USER1`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Handover Inbound Cabang wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1F1

- **Element:** Completeness
- **Table.column:** `CMS_DHI_HOC.DHI_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Handover Inbound Cabang wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1F3

- **Element:** Completeness
- **Table.column:** `CMS_DHI_HOC.DHI_ONO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Handover Inbound Cabang wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1F5

- **Element:** Completeness
- **Table.column:** `CMS_DHI_HOC.DHI_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Handover Inbound Cabang wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1F6

- **Element:** Completeness
- **Table.column:** `CMS_DHI_HOC.DHI_CNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Jumlah paket pada Detail Handover Inbound Cabang wajib terisi. Data kuantitas digunakan untuk memastikan seluruh paket tercatat dan tidak ada yang terlewat.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1F7

- **Element:** Completeness
- **Table.column:** `CMS_DHI_HOC.CDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Detail Handover Inbound Cabang wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1H1

- **Element:** Completeness
- **Table.column:** `CMS_MANIFEST.MANIFEST_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Manifest pengiriman wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1H10

- **Element:** Completeness
- **Table.column:** `CMS_MANIFEST.MANIFEST_CODE`
- **Business indicator:** Manifest Type
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Jenis manifest pada Manifest pengiriman wajib terisi. Data ini menentukan kategori manifest yang digunakan dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1H11

- **Element:** Completeness
- **Table.column:** `CMS_MANIFEST.MANIFEST_UID`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Manifest pengiriman wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1H15

- **Element:** Completeness
- **Table.column:** `CMS_MANIFEST.MANIFEST_CRDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Manifest pengiriman wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1H16

- **Element:** Completeness
- **Table.column:** `CMS_MANIFEST.MANIFEST_CANCELED`
- **Business indicator:** Status
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Status pengiriman pada Manifest pengiriman wajib terisi. Data status digunakan untuk memantau perkembangan proses pengiriman paket.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1H3

- **Element:** Completeness
- **Table.column:** `CMS_MANIFEST.MANIFEST_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Manifest pengiriman wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1H5

- **Element:** Completeness
- **Table.column:** `CMS_MANIFEST.MANIFEST_FROM`
- **Business indicator:** Origin
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode asal pengiriman pada Manifest pengiriman wajib terisi. Data asal digunakan untuk menentukan dari mana paket dikirimkan.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1H8

- **Element:** Completeness
- **Table.column:** `CMS_MANIFEST.MANIFEST_APPROVED`
- **Business indicator:** Flag
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nilai penanda (flag) pada Manifest pengiriman wajib terisi. Data ini digunakan sebagai indikator kondisi atau status tertentu dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1I1

- **Element:** Completeness
- **Table.column:** `CMS_MFCNOTE.MFCNOTE_MAN_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada daftar connote dalam Manifest (MFCnote) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1I19

- **Element:** Completeness
- **Table.column:** `CMS_MFCNOTE.MFCNOTE_CRDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada daftar connote dalam Manifest (MFCnote) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1I2

- **Element:** Completeness
- **Table.column:** `CMS_MFCNOTE.MFCNOTE_BAG_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada daftar connote dalam Manifest (MFCnote) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1I3

- **Element:** Completeness
- **Table.column:** `CMS_MFCNOTE.MFCNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada daftar connote dalam Manifest (MFCnote) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1I4

- **Element:** Completeness
- **Table.column:** `CMS_MFCNOTE.MFCNOTE_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Berat paket pada daftar connote dalam Manifest (MFCnote) wajib terisi. Data berat adalah dasar penghitungan tarif pengiriman.
- **Business impact:** Reporting — Understated weight
- **Issue label:** (----) Unmapped Governance Issue

## COMP1J1

- **Element:** Completeness
- **Table.column:** `CMS_MFBAG.MFBAG_MAN_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada daftar bag dalam Manifest (MFBag) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1J10

- **Element:** Completeness
- **Table.column:** `CMS_MFBAG.MFBAG_ROUTE`
- **Business indicator:** Route Code
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode rute pengiriman pada daftar bag dalam Manifest (MFBag) wajib terisi. Data rute menentukan jalur yang digunakan untuk pengiriman paket.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1J18

- **Element:** Completeness
- **Table.column:** `CMS_MFBAG.MFBAG_CRDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada daftar bag dalam Manifest (MFBag) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1J2

- **Element:** Completeness
- **Table.column:** `CMS_MFBAG.MFBAG_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada daftar bag dalam Manifest (MFBag) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1J20

- **Element:** Completeness
- **Table.column:** `CMS_MFBAG.ESB_TIME`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada daftar bag dalam Manifest (MFBag) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1J21

- **Element:** Completeness
- **Table.column:** `CMS_MFBAG.ESB_ID`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada daftar bag dalam Manifest (MFBag) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1J3

- **Element:** Completeness
- **Table.column:** `CMS_MFBAG.MFBAG_ACT_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Berat paket pada daftar bag dalam Manifest (MFBag) wajib terisi. Data berat adalah dasar penghitungan tarif pengiriman.
- **Business impact:** Reporting — Understated weight
- **Issue label:** (----) Unmapped Governance Issue

## COMP1J4

- **Element:** Completeness
- **Table.column:** `CMS_MFBAG.MFBAG_CTC_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Berat paket pada daftar bag dalam Manifest (MFBag) wajib terisi. Data berat adalah dasar penghitungan tarif pengiriman.
- **Business impact:** Reporting — Understated weight
- **Issue label:** (----) Unmapped Governance Issue

## COMP1K1

- **Element:** Completeness
- **Table.column:** `CMS_DMBAG.DMBAG_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Manifest Bag wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1K10

- **Element:** Completeness
- **Table.column:** `CMS_DMBAG.ESB_TIME`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Detail Manifest Bag wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1K11

- **Element:** Completeness
- **Table.column:** `CMS_DMBAG.ESB_ID`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Manifest Bag wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1K2

- **Element:** Completeness
- **Table.column:** `CMS_DMBAG.DMBAG_BAG_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Manifest Bag wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1K3

- **Element:** Completeness
- **Table.column:** `CMS_DMBAG.DMBAG_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode asal pengiriman pada Detail Manifest Bag wajib terisi. Data asal digunakan untuk menentukan dari mana paket dikirimkan.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1K4

- **Element:** Completeness
- **Table.column:** `CMS_DMBAG.DMBAG_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode tujuan pengiriman pada Detail Manifest Bag wajib terisi. Data tujuan menentukan ke mana paket akan dikirimkan dan berpengaruh pada tarif.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1K5

- **Element:** Completeness
- **Table.column:** `CMS_DMBAG.DMBAG_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Berat paket pada Detail Manifest Bag wajib terisi. Data berat adalah dasar penghitungan tarif pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1L1

- **Element:** Completeness
- **Table.column:** `CMS_MMBAG.MMBAG_BRANCH`
- **Business indicator:** Branch ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode cabang pada Master Manifest Bag wajib terisi. Data cabang diperlukan untuk menentukan lokasi asal atau tujuan proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1L10

- **Element:** Completeness
- **Table.column:** `CMS_MMBAG.MMBAG_USER_APPROVE`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Manifest Bag wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1L2

- **Element:** Completeness
- **Table.column:** `CMS_MMBAG.MMBAG_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Master Manifest Bag wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1L3

- **Element:** Completeness
- **Table.column:** `CMS_MMBAG.MMBAG_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode asal pengiriman pada Master Manifest Bag wajib terisi. Data asal digunakan untuk menentukan dari mana paket dikirimkan.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1L4

- **Element:** Completeness
- **Table.column:** `CMS_MMBAG.MMBAG_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode tujuan pengiriman pada Master Manifest Bag wajib terisi. Data tujuan menentukan ke mana paket akan dikirimkan dan berpengaruh pada tarif.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1L5

- **Element:** Completeness
- **Table.column:** `CMS_MMBAG.MMBAG_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master Manifest Bag wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1L6

- **Element:** Completeness
- **Table.column:** `CMS_MMBAG.MMBAG_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Jumlah paket pada Master Manifest Bag wajib terisi. Data kuantitas digunakan untuk memastikan seluruh paket tercatat dan tidak ada yang terlewat.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1L7

- **Element:** Completeness
- **Table.column:** `CMS_MMBAG.MMBAG_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Berat paket pada Master Manifest Bag wajib terisi. Data berat adalah dasar penghitungan tarif pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1L9

- **Element:** Completeness
- **Table.column:** `CMS_MMBAG.MMBAG_USER`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Manifest Bag wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1M1

- **Element:** Completeness
- **Table.column:** `CMS_DSMU.DSMU_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail SMU (Surat Muatan Udara) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1M11

- **Element:** Completeness
- **Table.column:** `CMS_DSMU.ESB_TIME`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Detail SMU (Surat Muatan Udara) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1M12

- **Element:** Completeness
- **Table.column:** `CMS_DSMU.ESB_ID`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail SMU (Surat Muatan Udara) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1M2

- **Element:** Completeness
- **Table.column:** `CMS_DSMU.DSMU_FLIGHT_NO`
- **Business indicator:** Flight No
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor penerbangan pada Detail SMU (Surat Muatan Udara) wajib terisi. Data ini diperlukan untuk melacak pengiriman via jalur udara.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1M3

- **Element:** Completeness
- **Table.column:** `CMS_DSMU.DSMU_FLIGHT_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Detail SMU (Surat Muatan Udara) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1M4

- **Element:** Completeness
- **Table.column:** `CMS_DSMU.DSMU_BAG_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail SMU (Surat Muatan Udara) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1M5

- **Element:** Completeness
- **Table.column:** `CMS_DSMU.DSMU_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Berat paket pada Detail SMU (Surat Muatan Udara) wajib terisi. Data berat adalah dasar penghitungan tarif pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1M6

- **Element:** Completeness
- **Table.column:** `CMS_DSMU.DSMU_BAG_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode asal pengiriman pada Detail SMU (Surat Muatan Udara) wajib terisi. Data asal digunakan untuk menentukan dari mana paket dikirimkan.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1M7

- **Element:** Completeness
- **Table.column:** `CMS_DSMU.DSMU_BAG_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode tujuan pengiriman pada Detail SMU (Surat Muatan Udara) wajib terisi. Data tujuan menentukan ke mana paket akan dikirimkan dan berpengaruh pada tarif.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N1

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Master SMU (Surat Muatan Udara) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N10

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Berat paket pada Master SMU (Surat Muatan Udara) wajib terisi. Data berat adalah dasar penghitungan tarif pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N11

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_USER`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master SMU (Surat Muatan Udara) wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N12

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_FLAG`
- **Business indicator:** Flag
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nilai penanda (flag) pada Master SMU (Surat Muatan Udara) wajib terisi. Data ini digunakan sebagai indikator kondisi atau status tertentu dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N14

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_STATUS`
- **Business indicator:** Status
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Status pengiriman pada Master SMU (Surat Muatan Udara) wajib terisi. Data status digunakan untuk memantau perkembangan proses pengiriman paket.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N15

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_WRH_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master SMU (Surat Muatan Udara) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N16

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_WRH_TIME`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master SMU (Surat Muatan Udara) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N17

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_OFF_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master SMU (Surat Muatan Udara) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N18

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_OFF_TIME`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master SMU (Surat Muatan Udara) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N19

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_CONFIRM`
- **Business indicator:** Flag
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nilai penanda (flag) pada Master SMU (Surat Muatan Udara) wajib terisi. Data ini digunakan sebagai indikator kondisi atau status tertentu dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N2

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master SMU (Surat Muatan Udara) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N24

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_MODA`
- **Business indicator:** Mode Transport
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Data Mode Transport pada Master SMU (Surat Muatan Udara) wajib terisi dan tidak boleh kosong.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N26

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_HOURS`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master SMU (Surat Muatan Udara) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N3

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode asal pengiriman pada Master SMU (Surat Muatan Udara) wajib terisi. Data asal digunakan untuk menentukan dari mana paket dikirimkan.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N4

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode tujuan pengiriman pada Master SMU (Surat Muatan Udara) wajib terisi. Data tujuan menentukan ke mana paket akan dikirimkan dan berpengaruh pada tarif.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N5

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_FLIGHT_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Master SMU (Surat Muatan Udara) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N6

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_FLIGHT_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master SMU (Surat Muatan Udara) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N7

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_ETD`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master SMU (Surat Muatan Udara) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N8

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_ETA`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master SMU (Surat Muatan Udara) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1N9

- **Element:** Completeness
- **Table.column:** `CMS_MSMU.MSMU_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Jumlah paket pada Master SMU (Surat Muatan Udara) wajib terisi. Data kuantitas digunakan untuk memastikan seluruh paket tercatat dan tidak ada yang terlewat.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1O1

- **Element:** Completeness
- **Table.column:** `CMS_DRSHEET_PRA.DRSHEET_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Runsheet Pra-Pengiriman wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1O2

- **Element:** Completeness
- **Table.column:** `CMS_DRSHEET_PRA.DRSHEET_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Runsheet Pra-Pengiriman wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1O9

- **Element:** Completeness
- **Table.column:** `CMS_DRSHEET_PRA.CREATION_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Runsheet Pra-Pengiriman wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1P1

- **Element:** Completeness
- **Table.column:** `CMS_DRSHEET.DRSHEET_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Runsheet wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1P2

- **Element:** Completeness
- **Table.column:** `CMS_DRSHEET.DRSHEET_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Runsheet wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1P3

- **Element:** Completeness
- **Table.column:** `CMS_DRSHEET.DRSHEET_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Detail Runsheet wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1P4

- **Element:** Completeness
- **Table.column:** `CMS_DRSHEET.DRSHEET_STATUS`
- **Business indicator:** Status
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Status pengiriman pada Detail Runsheet wajib terisi. Data status digunakan untuk memantau perkembangan proses pengiriman paket.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1P5

- **Element:** Completeness
- **Table.column:** `CMS_DRSHEET.DRSHEET_RECEIVER`
- **Business indicator:** Receiver Name
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Data Receiver Name pada Detail Runsheet wajib terisi dan tidak boleh kosong.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1P7

- **Element:** Completeness
- **Table.column:** `CMS_DRSHEET.DRSHEET_UID`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Detail Runsheet wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1P8

- **Element:** Completeness
- **Table.column:** `CMS_DRSHEET.DRSHEET_UDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Detail Runsheet wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1P9

- **Element:** Completeness
- **Table.column:** `CMS_DRSHEET.CREATION_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Detail Runsheet wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Q1

- **Element:** Completeness
- **Table.column:** `CMS_MRSHEET.MRSHEET_BRANCH`
- **Business indicator:** Branch ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode cabang pada Master Runsheet wajib terisi. Data cabang diperlukan untuk menentukan lokasi asal atau tujuan proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Q2

- **Element:** Completeness
- **Table.column:** `CMS_MRSHEET.MRSHEET_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Master Runsheet wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Q3

- **Element:** Completeness
- **Table.column:** `CMS_MRSHEET.MRSHEET_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master Runsheet wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Q4

- **Element:** Completeness
- **Table.column:** `CMS_MRSHEET.MRSHEET_COURIER_ID`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Runsheet wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Q5

- **Element:** Completeness
- **Table.column:** `CMS_MRSHEET.MRSHEET_UID`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Runsheet wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Q6

- **Element:** Completeness
- **Table.column:** `CMS_MRSHEET.MRSHEET_UDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master Runsheet wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Q7

- **Element:** Completeness
- **Table.column:** `CMS_MRSHEET.MRSHEET_APPROVED_DR`
- **Business indicator:** Flag
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nilai penanda (flag) pada Master Runsheet wajib terisi. Data ini digunakan sebagai indikator kondisi atau status tertentu dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Q8

- **Element:** Completeness
- **Table.column:** `CMS_MRSHEET.MRSHEET_UID_DR`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Runsheet wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1R1

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Proof of Delivery / bukti terima paket wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1R2

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Proof of Delivery / bukti terima paket wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1R4

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_STATUS`
- **Business indicator:** Status
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Status pengiriman pada Proof of Delivery / bukti terima paket wajib terisi. Data status digunakan untuk memantau perkembangan proses pengiriman paket.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1R5

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_DELIVERED`
- **Business indicator:** Status
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Status pengiriman pada Proof of Delivery / bukti terima paket wajib terisi. Data status digunakan untuk memantau perkembangan proses pengiriman paket.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1R6

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_DOC_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Proof of Delivery / bukti terima paket wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1R7

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_CREATION_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Proof of Delivery / bukti terima paket wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1S1

- **Element:** Completeness
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_RSHEET_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Handover Runsheet wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1S10

- **Element:** Completeness
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_RSHEET_UZONE`
- **Business indicator:** Zone Code
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode zona pada Detail Handover Runsheet wajib terisi. Data zona digunakan untuk menentukan area pengiriman dan mempengaruhi penentuan rute.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1S11

- **Element:** Completeness
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_RSHEET_CYCLE`
- **Business indicator:** Flag
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nilai penanda (flag) pada Detail Handover Runsheet wajib terisi. Data ini digunakan sebagai indikator kondisi atau status tertentu dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1S13

- **Element:** Completeness
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_RSHEET_RSHEETNO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Handover Runsheet wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1S17

- **Element:** Completeness
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_DRSHEET_EPAY_DEVICE`
- **Business indicator:** Payment Type
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Data Payment Type pada Detail Handover Runsheet wajib terisi dan tidak boleh kosong.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1S19

- **Element:** Completeness
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_DRSHEET_STATUS`
- **Business indicator:** Status
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Status pengiriman pada Detail Handover Runsheet wajib terisi. Data status digunakan untuk memantau perkembangan proses pengiriman paket.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1S2

- **Element:** Completeness
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_RSHEET_CNOTE`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Handover Runsheet wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1S4

- **Element:** Completeness
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_RSHEET_COD`
- **Business indicator:** Status
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Status pengiriman pada Detail Handover Runsheet wajib terisi. Data status digunakan untuk memantau perkembangan proses pengiriman paket.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1S8

- **Element:** Completeness
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_RSHEET_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Jumlah paket pada Detail Handover Runsheet wajib terisi. Data kuantitas digunakan untuk memastikan seluruh paket tercatat dan tidak ada yang terlewat.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1S9

- **Element:** Completeness
- **Table.column:** `CMS_DHOV_RSHEET.CREATE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Detail Handover Runsheet wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1T1

- **Element:** Completeness
- **Table.column:** `CMS_MHOUNDEL_POD.MHOUNDEL_BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode cabang pada Master Handover Undelivered POD wajib terisi. Data cabang diperlukan untuk menentukan lokasi asal atau tujuan proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1T10

- **Element:** Completeness
- **Table.column:** `CMS_MHOUNDEL_POD.MHOUNDEL_SIGNDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master Handover Undelivered POD wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1T2

- **Element:** Completeness
- **Table.column:** `CMS_MHOUNDEL_POD.MHOUNDEL_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Master Handover Undelivered POD wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1T4

- **Element:** Completeness
- **Table.column:** `CMS_MHOUNDEL_POD.MHOUNDEL_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master Handover Undelivered POD wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1T5

- **Element:** Completeness
- **Table.column:** `CMS_MHOUNDEL_POD.MHOUNDEL_USER_ID`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Handover Undelivered POD wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1T6

- **Element:** Completeness
- **Table.column:** `CMS_MHOUNDEL_POD.MHOUNDEL_ZONE`
- **Business indicator:** Zone Code
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode zona pada Master Handover Undelivered POD wajib terisi. Data zona digunakan untuk menentukan area pengiriman dan mempengaruhi penentuan rute.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1T7

- **Element:** Completeness
- **Table.column:** `CMS_MHOUNDEL_POD.MHOUNDEL_APPROVE`
- **Business indicator:** Flag
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nilai penanda (flag) pada Master Handover Undelivered POD wajib terisi. Data ini digunakan sebagai indikator kondisi atau status tertentu dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1T8

- **Element:** Completeness
- **Table.column:** `CMS_MHOUNDEL_POD.MHOUNDEL_USER1`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Handover Undelivered POD wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1U1

- **Element:** Completeness
- **Table.column:** `CMS_DHOUNDEL_POD.DHOUNDEL_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Handover Undelivered POD wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1U10

- **Element:** Completeness
- **Table.column:** `CMS_DHOUNDEL_POD.DHOUNDEL_HRS`
- **Business indicator:** Flag
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nilai penanda (flag) pada Detail Handover Undelivered POD wajib terisi. Data ini digunakan sebagai indikator kondisi atau status tertentu dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1U11

- **Element:** Completeness
- **Table.column:** `CMS_DHOUNDEL_POD.CREATE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Detail Handover Undelivered POD wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1U3

- **Element:** Completeness
- **Table.column:** `CMS_DHOUNDEL_POD.DHOUNDEL_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Handover Undelivered POD wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1U4

- **Element:** Completeness
- **Table.column:** `CMS_DHOUNDEL_POD.DHOUNDEL_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Jumlah paket pada Detail Handover Undelivered POD wajib terisi. Data kuantitas digunakan untuk memastikan seluruh paket tercatat dan tidak ada yang terlewat.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1V1

- **Element:** Completeness
- **Table.column:** `CMS_MHOCNOTE.MHOCNOTE_BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode cabang pada Master Handover Outbound Connote wajib terisi. Data cabang diperlukan untuk menentukan lokasi asal atau tujuan proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1V10

- **Element:** Completeness
- **Table.column:** `CMS_MHOCNOTE.MHOCNOTE_APPROVE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master Handover Outbound Connote wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1V2

- **Element:** Completeness
- **Table.column:** `CMS_MHOCNOTE.MHOCNOTE_ZONE`
- **Business indicator:** Zone Code
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode zona pada Master Handover Outbound Connote wajib terisi. Data zona digunakan untuk menentukan area pengiriman dan mempengaruhi penentuan rute.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1V3

- **Element:** Completeness
- **Table.column:** `CMS_MHOCNOTE.MHOCNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Master Handover Outbound Connote wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1V4

- **Element:** Completeness
- **Table.column:** `CMS_MHOCNOTE.MHOCNOTE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master Handover Outbound Connote wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1V5

- **Element:** Completeness
- **Table.column:** `CMS_MHOCNOTE.MHOCNOTE_ZONE_DEST`
- **Business indicator:** Zone Code
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode zona pada Master Handover Outbound Connote wajib terisi. Data zona digunakan untuk menentukan area pengiriman dan mempengaruhi penentuan rute.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1V6

- **Element:** Completeness
- **Table.column:** `CMS_MHOCNOTE.MHOCNOTE_USER_ID`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Handover Outbound Connote wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1W1

- **Element:** Completeness
- **Table.column:** `CMS_DHOCNOTE.DHOCNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Handover Outbound Connote wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1W3

- **Element:** Completeness
- **Table.column:** `CMS_DHOCNOTE.DHOCNOTE_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Detail Handover Outbound Connote wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1W4

- **Element:** Completeness
- **Table.column:** `CMS_DHOCNOTE.DHOCNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Jumlah paket pada Detail Handover Outbound Connote wajib terisi. Data kuantitas digunakan untuk memastikan seluruh paket tercatat dan tidak ada yang terlewat.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1W6

- **Element:** Completeness
- **Table.column:** `CMS_DHOCNOTE.DHOCNOTE_TDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Detail Handover Outbound Connote wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1X1

- **Element:** Completeness
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.MANIFEST_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada biaya transit agen (master) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1X11

- **Element:** Completeness
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.MANIFEST_UID`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses biaya transit agen (master) wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1X12

- **Element:** Completeness
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.ESB_TIME`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada biaya transit agen (master) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1X13

- **Element:** Completeness
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.ESB_ID`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada biaya transit agen (master) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1X2

- **Element:** Completeness
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.MANIFEST_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada biaya transit agen (master) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1X3

- **Element:** Completeness
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode cabang pada biaya transit agen (master) wajib terisi. Data cabang diperlukan untuk menentukan lokasi asal atau tujuan proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1X4

- **Element:** Completeness
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode tujuan pengiriman pada biaya transit agen (master) wajib terisi. Data tujuan menentukan ke mana paket akan dikirimkan dan berpengaruh pada tarif.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1X5

- **Element:** Completeness
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.CTC_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Berat paket pada biaya transit agen (master) wajib terisi. Data berat adalah dasar penghitungan tarif pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1X6

- **Element:** Completeness
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.ACT_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Berat paket pada biaya transit agen (master) wajib terisi. Data berat adalah dasar penghitungan tarif pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Y1

- **Element:** Completeness
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.DMANIFEST_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada biaya transit agen (detail) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Y10

- **Element:** Completeness
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.ESB_ID`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada biaya transit agen (detail) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Y2

- **Element:** Completeness
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada biaya transit agen (detail) wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Y3

- **Element:** Completeness
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.CNOTE_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode asal pengiriman pada biaya transit agen (detail) wajib terisi. Data asal digunakan untuk menentukan dari mana paket dikirimkan.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Y4

- **Element:** Completeness
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.CNOTE_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode tujuan pengiriman pada biaya transit agen (detail) wajib terisi. Data tujuan menentukan ke mana paket akan dikirimkan dan berpengaruh pada tarif.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Y5

- **Element:** Completeness
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.CNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Jumlah paket pada biaya transit agen (detail) wajib terisi. Data kuantitas digunakan untuk memastikan seluruh paket tercatat dan tidak ada yang terlewat.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Y6

- **Element:** Completeness
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.CNOTE_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Berat paket pada biaya transit agen (detail) wajib terisi. Data berat adalah dasar penghitungan tarif pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Y8

- **Element:** Completeness
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.CNOTE_SERVICES_CODE`
- **Business indicator:** Service Code
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode layanan pengiriman pada biaya transit agen (detail) wajib terisi. Data ini menentukan jenis layanan (misalnya reguler, express) yang digunakan untuk pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Y9

- **Element:** Completeness
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.ESB_TIME`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada biaya transit agen (detail) wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Z1

- **Element:** Completeness
- **Table.column:** `CMS_MSJ.MSJ_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nomor identifikasi (ID/nomor dokumen) pada Master Surat Jalan wajib terisi. Data ini digunakan sebagai kunci utama untuk melacak dan menghubungkan dokumen dalam sistem.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Z11

- **Element:** Completeness
- **Table.column:** `CMS_MSJ.MSJ_DEST`
- **Business indicator:** Destination
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode tujuan pengiriman pada Master Surat Jalan wajib terisi. Data tujuan menentukan ke mana paket akan dikirimkan dan berpengaruh pada tarif.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Z12

- **Element:** Completeness
- **Table.column:** `CMS_MSJ.MSJ_ORIG`
- **Business indicator:** Origin
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode asal pengiriman pada Master Surat Jalan wajib terisi. Data asal digunakan untuk menentukan dari mana paket dikirimkan.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Z2

- **Element:** Completeness
- **Table.column:** `CMS_MSJ.MSJ_BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Kode cabang pada Master Surat Jalan wajib terisi. Data cabang diperlukan untuk menentukan lokasi asal atau tujuan proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Z3

- **Element:** Completeness
- **Table.column:** `CMS_MSJ.MSJ_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master Surat Jalan wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Z4

- **Element:** Completeness
- **Table.column:** `CMS_MSJ.MSJ_USER1`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Surat Jalan wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Z5

- **Element:** Completeness
- **Table.column:** `CMS_MSJ.MSJ_USER2`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Surat Jalan wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Z6

- **Element:** Completeness
- **Table.column:** `CMS_MSJ.MSJ_APPROVE`
- **Business indicator:** Flag
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nilai penanda (flag) pada Master Surat Jalan wajib terisi. Data ini digunakan sebagai indikator kondisi atau status tertentu dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Z7

- **Element:** Completeness
- **Table.column:** `CMS_MSJ.MSJ_CDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master Surat Jalan wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP1Z8

- **Element:** Completeness
- **Table.column:** `CMS_MSJ.MSJ_UID`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Master Surat Jalan wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP2AB11

- **Element:** Completeness
- **Table.column:** `CMS_MHICNOTE.MHICNOTE_APPROVE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada manifest Handover Inbound Connote wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP2H4

- **Element:** Completeness
- **Table.column:** `CMS_MANIFEST.MANIFEST_ROUTE`
- **Business indicator:** Route Code
- **Logic (ID):** If MANIFEST_APPROVED is 'Y' then Data is Mandatory and Not Null
- **Logic (EN):** If MANIFEST_APPROVED is 'Y' then the value is mandatory and not null
- **Operational meaning (ID):** Jika Manifest sudah disetujui (approved), maka kode rute pengiriman pada Manifest pengiriman wajib terisi. Data ini diperlukan setelah proses persetujuan manifest dilakukan.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP2H6

- **Element:** Completeness
- **Table.column:** `CMS_MANIFEST.MANIFEST_THRU`
- **Business indicator:** Destination
- **Logic (ID):** If MANIFEST_APPROVED is 'Y' then Data is Mandatory and Not Null
- **Logic (EN):** If MANIFEST_APPROVED is 'Y' then the value is mandatory and not null
- **Operational meaning (ID):** Jika Manifest sudah disetujui (approved), maka kode tujuan pengiriman pada Manifest pengiriman wajib terisi. Data ini diperlukan setelah proses persetujuan manifest dilakukan.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (----) Unmapped Governance Issue

## COMP2H9

- **Element:** Completeness
- **Table.column:** `CMS_MANIFEST.MANIFEST_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** If MANIFEST_APPROVED is 'Y' then Data is Mandatory and Not Null
- **Logic (EN):** If MANIFEST_APPROVED is 'Y' then the value is mandatory and not null
- **Operational meaning (ID):** Jika Manifest sudah disetujui (approved), maka kode asal pengiriman pada Manifest pengiriman wajib terisi. Data ini diperlukan setelah proses persetujuan manifest dilakukan.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (----) Unmapped Governance Issue

## COMP2L11

- **Element:** Completeness
- **Table.column:** `CMS_MMBAG.MMBAG_DATE_APPROVE`
- **Business indicator:** Timestamp
- **Logic (ID):** If MMBAG_APPROVE is 'Y' then Data is Mandatory and Not Null
- **Logic (EN):** If MMBAG_APPROVE is 'Y' then the value is mandatory and not null
- **Operational meaning (ID):** Data pada Master Manifest Bag harus memenuhi ketentuan yang berlaku: If MMBAG_APPROVE is 'Y' then Data is Mandatory and Not Null
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP2L12

- **Element:** Completeness
- **Table.column:** `CMS_MMBAG.MMBAG_APPROVED`
- **Business indicator:** Timestamp
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Tanggal dan waktu pada Master Manifest Bag wajib terisi. Data waktu diperlukan untuk memastikan urutan proses pengiriman dapat diverifikasi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP2P6

- **Element:** Completeness
- **Table.column:** `CMS_DRSHEET.DRSHEET_FLAG`
- **Business indicator:** Flag
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** Nilai penanda (flag) pada Detail Runsheet wajib terisi. Data ini digunakan sebagai indikator kondisi atau status tertentu dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP2R3

- **Element:** Completeness
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_RECEIVER`
- **Business indicator:** User ID
- **Logic (ID):** Data is mandatory and not null
- **Logic (EN):** Data is mandatory and not null
- **Operational meaning (ID):** ID pengguna/petugas yang memproses Proof of Delivery / bukti terima paket wajib terisi. Data ini diperlukan untuk keperluan audit dan pertanggungjawaban atas setiap transaksi.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP2V19

- **Element:** Completeness
- **Table.column:** `CMS_MHOCNOTE.MHOCNOTE_APP_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** If MHOCNOTE_APPROVE is 'Y' then Data is Mandatory and Not Null
- **Logic (EN):** If MHOCNOTE_APPROVE is 'Y' then the value is mandatory and not null
- **Operational meaning (ID):** Jika Handover Outbound sudah disetujui, maka tanggal/waktu pada Master Handover Outbound Connote wajib terisi. Data ini diperlukan setelah proses approval handover outbound dilakukan.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP2V9

- **Element:** Completeness
- **Table.column:** `CMS_MHOCNOTE.MHOCNOTE_SIGNDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** If MHOCNOTE_APPROVE is 'Y' then Data is Mandatory and Not Null
- **Logic (EN):** If MHOCNOTE_APPROVE is 'Y' then the value is mandatory and not null
- **Operational meaning (ID):** Jika Handover Outbound sudah disetujui, maka tanggal/waktu pada Master Handover Outbound Connote wajib terisi. Data ini diperlukan setelah proses approval handover outbound dilakukan.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP2Z10

- **Element:** Completeness
- **Table.column:** `CMS_MSJ.MSJ_SIGNDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** If MSJ_APPROVE is 'Y' then Data is Mandatory and Not Null
- **Logic (EN):** If MSJ_APPROVE is 'Y' then the value is mandatory and not null
- **Operational meaning (ID):** Data pada Master Surat Jalan harus memenuhi ketentuan yang berlaku: If MSJ_APPROVE is 'Y' then Data is Mandatory and Not Null
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP3J9

- **Element:** Completeness
- **Table.column:** `CMS_MFBAG.MFBAG_MAN_REF`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Only applies to TM & IM Data is mandatory and not null
- **Logic (EN):** Applies only to TM and IM: the value is mandatory and not null
- **Operational meaning (ID):** Khusus untuk jenis pengiriman Transit Manifest (TM) dan Inbound Manifest (IM), nomor identifikasi (ID/nomor dokumen) pada daftar bag dalam Manifest (MFBag) wajib terisi dan tidak boleh kosong.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## COMP4J1

- **Element:** Completeness
- **Table.column:** `CMS_MFBAG.MFBAG_MAN_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Ada transit manifest dalam MFBAG_MAN_NO jika prefix DSMU_BAG_ORIGIN tidak sama dengan prefix MSMU_ORIGIN
- **Logic (EN):** A transit manifest exists in MFBAG_MAN_NO when the DSMU_BAG_ORIGIN prefix differs from the MSMU_ORIGIN prefix
- **Operational meaning (ID):** Manifest transit wajib ada ketika kode asal pengiriman berbeda dengan cabang asal. Ini memastikan alur perpindahan paket antar cabang terdokumentasi dengan benar.
- **Business impact:** TBD
- **Issue label:** (COMP) Transit Manifest Required When Origin Differs

## CONS1B12

- **Element:** Consistency
- **Table.column:** `CMS_CNOTE.CNOTE_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Data origin code CMS_CNOTE konsisten dengan origin code APICUST
- **Logic (EN):** CMS_CNOTE origin code is consistent with the APICUST origin code
- **Operational meaning (ID):** Kode asal yang tercatat di sistem JNE (connote) harus sesuai dengan kode asal yang dikirimkan oleh pelanggan melalui marketplace/platform. Perbedaan dapat mengindikasikan adanya kesalahan input data.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (CONS) Origin Difference (Marketplace Seller vs JNE)

## CONS1B13

- **Element:** Consistency
- **Table.column:** `CMS_APICUST.CNOTE_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data destination code CMS_CNOTE konsisten dengan APICUST
- **Logic (EN):** CMS_CNOTE destination code is consistent with APICUST
- **Operational meaning (ID):** Kode destinasi yang tercatat di sistem Marketplace tidak sesuai dengan kode destinasi yang tercatat di sistem JNE.
- **Business impact:** Billing — Over-billing/Under-billing
- **Issue label:** (CONS) Destination Difference (Marketplace vs CMS Cnote)

## CONS1B14

- **Element:** Consistency
- **Table.column:** `CMS_APICUST.CNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data quantity paket CMS_CNOTE konsisten dengan APICUST
- **Logic (EN):** CMS_CNOTE package quantity is consistent with APICUST
- **Operational meaning (ID):** Jumlah paket yang dikirimkan oleh marketplace harus sesuai dengan jumlah yang tercatat dalam connote JNE. Perbedaan menandakan ada selisih data antara sistem marketplace dan sistem JNE.
- **Business impact:** TBD
- **Issue label:** (CONS) Quantity Difference (Marketplace Quantity vs CMS Cnote Quantity)

## CONS1B15

- **Element:** Consistency
- **Table.column:** `CMS_CNOTE.CNOTE_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data berat paket CMS_CNOTE konsisten dengan APICUST
- **Logic (EN):** CMS_CNOTE package weight is consistent with APICUST
- **Operational meaning (ID):** Berat paket yang tercatat dalam connote JNE harus sesuai dengan berat yang dikirimkan melalui API pelanggan (marketplace). Perbedaan dapat menyebabkan sengketa tarif antara penjual dan JNE.
- **Business impact:** Billing — Seller & JNE Dispute
- **Issue label:** (CONS) Weight Difference (CMS Cnote Weight vs Apicust Weight)

## CONS1B3

- **Element:** Consistency
- **Table.column:** `CMS_APICUST.CNOTE_BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Data branch ID CMS_CNOTE konsisten dengan APICUST
- **Logic (EN):** CMS_CNOTE branch ID is consistent with APICUST
- **Operational meaning (ID):** Kode cabang yang dikirimkan oleh penjual marketplace harus sesuai dengan kode cabang yang tercatat di sistem JNE. Perbedaan dapat mengindikasikan kesalahan data dari pihak marketplace.
- **Business impact:** TBD
- **Issue label:** (CONS) Branch Difference (Marketplace Seller vs JNE)

## CONS2AC4

- **Element:** Consistency
- **Table.column:** `CMS_DHICNOTE.DHICNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data quantity paket handover inbound konsisten dengan CMS_CNOTE
- **Logic (EN):** Inbound handover package quantity is consistent with CMS_CNOTE
- **Operational meaning (ID):** Jumlah connote yang tercatat dalam Handover Inbound harus sesuai dengan jumlah yang ada di data connote. Perbedaan menandakan ada connote yang tidak sesuai saat proses handover masuk.
- **Business impact:** TBD
- **Issue label:** (CONS) Quantity Difference (Inbound Handover Cnote Quantity vs CMS Cnote Quantity)

## CONS2AE4

- **Element:** Consistency
- **Table.column:** `CMS_DBAG_HO.DBAG_CNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data Quantity Bag handover konsisten dengan CMS_CNOTE
- **Logic (EN):** Handover bag quantity is consistent with CMS_CNOTE
- **Operational meaning (ID):** Jumlah paket yang tercatat dalam Handover Bag harus sesuai dengan jumlah yang ada di data connote. Perbedaan menandakan ada paket yang tidak sesuai saat proses pengemasan dalam bag.
- **Business impact:** TBD
- **Issue label:** (CONS) Quantity Difference (Handover Bag Quantity vs CMS Cnote Quantity)

## CONS2AE5

- **Element:** Consistency
- **Table.column:** `CMS_DBAG_HO.DBAG_CNOTE_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data Berat Bag handover konsisten dengan CMS_CNOTE
- **Logic (EN):** Handover bag weight is consistent with CMS_CNOTE
- **Operational meaning (ID):** Berat yang tercatat dalam Handover Bag di cabang harus sesuai dengan berat yang ada di connote. Perbedaan berat menandakan adanya ketidaksesuaian data antara bag handover dan connote.
- **Business impact:** Reporting — Internal Dispute
- **Issue label:** (CONS) Weight Difference (Handover Bag in Cabang Weight vs Cnote Weight)

## CONS2AE6

- **Element:** Consistency
- **Table.column:** `CMS_DBAG_HO.DBAG_CNOTE_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data destination code DBAG konsisten dengan destination code CMS_CNOTE
- **Logic (EN):** DBAG destination code is consistent with the CMS_CNOTE destination code
- **Operational meaning (ID):** Kode tujuan yang tercatat dalam Handover Bag harus sesuai dengan kode tujuan yang ada di connote. Perbedaan dapat menyebabkan paket masuk ke bag yang salah dan berpotensi salah kirim.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (CONS) Destination Difference (Handover Bag vs CMS Cnote)

## CONS2C3

- **Element:** Consistency
- **Table.column:** `CMS_MRCNOTE.MRCNOTE_BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Data Branch ID Receival konsisten dengan CMS_CNOTE
- **Logic (EN):** Receival branch ID is consistent with CMS_CNOTE
- **Operational meaning (ID):** Kode cabang yang tercatat dalam Master Receival harus sesuai dengan kode cabang yang ada di connote. Perbedaan menandakan paket mungkin diterima di cabang yang berbeda dari yang seharusnya.
- **Business impact:** TBD
- **Issue label:** (CONS) Branch Difference (MRCNOTE Branch vs CMS Cnote Branch)

## CONS2D3

- **Element:** Consistency
- **Table.column:** `CMS_DRCNOTE.DRCNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data Quantity Receival konsisten dengan CMS_NOTE
- **Logic (EN):** Receival quantity is consistent with CMS_CNOTE
- **Operational meaning (ID):** Jumlah paket yang tercatat dalam Detail Receival Connote harus sesuai dengan jumlah yang ada di data connote. Perbedaan dapat menandakan ada paket yang belum atau salah tercatat saat penerimaan.
- **Business impact:** TBD
- **Issue label:** (CONS) Quantity Difference (DRCNOTE Quantity vs CMS Cnote Quantity)

## CONS2F6

- **Element:** Consistency
- **Table.column:** `CMS_DHI_HOC.DHI_CNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data quantity handover receival konsisten dengan quantity CMS_CNOTE
- **Logic (EN):** Handover receival quantity is consistent with the CMS_CNOTE quantity
- **Operational meaning (ID):** Jumlah kuantitas paket yang tercatat dalam dokumen handover tidak sesuai dengan data yang terdapat pada CMS_CNOTE.
- **Business impact:** TBD
- **Issue label:** (CONS) Quantity Difference (Inbound Handover Quantity vs CMS Cnote Quantity)

## CONS2I4

- **Element:** Consistency
- **Table.column:** `CMS_MFCNOTE.MFCNOTE_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data berat paket dalam Manifest konsisten dengan berat paket CMS_CNOTE (MFCNOTE_WEIGHT akan di rounded up/down)
- **Logic (EN):** Package weight in the manifest is consistent with CMS_CNOTE package weight (MFCNOTE_WEIGHT is rounded up or down)
- **Operational meaning (ID):** Berat yang tercatat dalam MFCnote harus sesuai dengan berat yang ada di connote. Perbedaan berat dapat menyebabkan ketidakakuratan data pengiriman dan berpotensi menimbulkan sengketa tarif.
- **Business impact:** Reporting — Internal Dispute
- **Issue label:** (CONS) Weight Difference (MFCnote Weight vs CMS Cnote Weight)

## CONS2J10

- **Element:** Consistency
- **Table.column:** `CMS_MFBAG.MFBAG_ROUTE`
- **Business indicator:** Route Code
- **Logic (ID):** Data Route Code MFBAG konsisten dengan Manifest
- **Logic (EN):** MFBAG route code is consistent with the manifest
- **Operational meaning (ID):** Data pada daftar bag dalam Manifest (MFBag) harus memenuhi ketentuan yang berlaku: Data Route Code MFBAG konsisten dengan Manifest
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## CONS2K3

- **Element:** Consistency
- **Table.column:** `CMS_DMBAG.DMBAG_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Data origin code DMBAG konsisten dengan origin code Manifest
- **Logic (EN):** DMBAG origin code is consistent with the manifest origin code
- **Operational meaning (ID):** Kode asal yang tercatat dalam Detail Bag harus sesuai dengan kode asal yang tercatat dalam Manifest. Perbedaan menandakan ada ketidaksesuaian antara dokumen bag dan manifest pengiriman.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (CONS) Origin Difference (Detail Bag Origin vs Manifest From)

## CONS2K4

- **Element:** Consistency
- **Table.column:** `CMS_DMBAG.DMBAG_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data destination code DMBAG konsisten dengan Manifest Thru
- **Logic (EN):** DMBAG destination code is consistent with Manifest Thru
- **Operational meaning (ID):** Kode tujuan yang tercatat dalam Detail Bag harus sesuai dengan kode tujuan yang tercatat dalam Manifest. Perbedaan menandakan ketidaksesuaian antara dokumen bag dan manifest pengiriman.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (CONS) Destination Difference (Detail Bag Destination vs Manifest Thru)

## CONS2L3

- **Element:** Consistency
- **Table.column:** `CMS_MMBAG.MMBAG_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Data origin code MMBAG konsisten dengan origin code DMBAG
- **Logic (EN):** MMBAG origin code is consistent with the DMBAG origin code
- **Operational meaning (ID):** Kode asal pada Master Bag harus sesuai dengan kode asal pada Detail Bag. Perbedaan menandakan adanya ketidaksesuaian antara data bag induk dan bag detailnya.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (CONS) Origin Difference (Master Bag Origin vs Detail Bag Origin)

## CONS2L4

- **Element:** Consistency
- **Table.column:** `CMS_MMBAG.MMBAG_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data destination code MMBAG konsisten dengan destination code DMBAG
- **Logic (EN):** MMBAG destination code is consistent with the DMBAG destination code
- **Operational meaning (ID):** Kode tujuan pada Master Bag harus sesuai dengan kode tujuan pada Detail Bag. Perbedaan menandakan adanya ketidaksesuaian antara data bag induk dan bag detailnya.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (CONS) Destination Difference (Master Bag Destination vs Detail Bag Destination)

## CONS2L7

- **Element:** Consistency
- **Table.column:** `CMS_MMBAG.MMBAG_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data berat MMBAG konsisten dengan DMBAG
- **Logic (EN):** MMBAG weight is consistent with DMBAG
- **Operational meaning (ID):** Total berat yang tercatat di Master Bag harus sesuai dengan jumlah berat seluruh Detail Bag di dalamnya. Perbedaan menandakan ada ketidaksesuaian antara data bag induk dan bag detailnya.
- **Business impact:** Reporting — Internal Dispute
- **Issue label:** (CONS) Weight Difference (Master Bag Weight vs Detail Bag Weight Sum)

## CONS2M2

- **Element:** Consistency
- **Table.column:** `CMS_DSMU.DSMU_FLIGHT_NO`
- **Business indicator:** Flight No
- **Logic (ID):** Data Flight No DSMU konsisten dengan MSMU
- **Logic (EN):** DSMU flight number is consistent with MSMU
- **Operational meaning (ID):** Nomor penerbangan yang tercatat dalam Detail SMU harus sesuai dengan nomor penerbangan di Master SMU. Perbedaan dapat menyebabkan ketidaksesuaian dalam pelacakan pengiriman jalur udara.
- **Business impact:** TBD
- **Issue label:** (CONS) Flight Number Difference (SMU Detail Flight No vs SMU Master Flight No)

## CONS2M3

- **Element:** Consistency
- **Table.column:** `CMS_DSMU.DSMU_FLIGHT_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data Flight Date DSMU konsisten dengan MSMU
- **Logic (EN):** DSMU flight date is consistent with MSMU
- **Operational meaning (ID):** Tanggal penerbangan yang tercatat dalam Detail SMU harus sesuai dengan tanggal penerbangan di Master SMU. Perbedaan menandakan adanya ketidaksesuaian data penerbangan.
- **Business impact:** TBD
- **Issue label:** (CONS) Flight Date Difference (SMU Detail Flight Date vs SMU Master Flight Date)

## CONS2M5

- **Element:** Consistency
- **Table.column:** `CMS_DSMU.DSMU_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data berat bag DSMU konsisten dengan DMBAG
- **Logic (EN):** DSMU bag weight is consistent with DMBAG
- **Operational meaning (ID):** Berat yang tercatat dalam Detail SMU harus sesuai dengan total berat Detail Bag. Perbedaan menandakan ada ketidaksesuaian antara data SMU dan data bag.
- **Business impact:** Reporting — Internal Dispute
- **Issue label:** (CONS) Weight Difference (SMU Detail Weight vs Detail Bag Weight)

## CONS2M6

- **Element:** Consistency
- **Table.column:** `CMS_DSMU.DSMU_BAG_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Data origin code DSMU konsisten dengan origin code DMBAG
- **Logic (EN):** DSMU origin code is consistent with the DMBAG origin code
- **Operational meaning (ID):** Kode asal pada SMU Bag harus sesuai dengan kode asal pada Detail Bag. Perbedaan menandakan ketidaksesuaian data asal antara SMU dan detail bag pengiriman.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (CONS) Origin Difference (SMU Bag Origin vs Detail Bag Origin)

## CONS2M7

- **Element:** Consistency
- **Table.column:** `CMS_DSMU.DSMU_BAG_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data destination code DSMU konsisten dengan destination code DMBAG
- **Logic (EN):** DSMU destination code is consistent with the DMBAG destination code
- **Operational meaning (ID):** Kode tujuan pada SMU Bag harus sesuai dengan kode tujuan pada Detail Bag. Perbedaan menandakan ketidaksesuaian data tujuan antara SMU dan detail bag pengiriman.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (CONS) Destination Difference (SMU Bag Destination vs Detail Bag Destination)

## CONS2N3

- **Element:** Consistency
- **Table.column:** `CMS_MSMU.MSMU_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Data origin code MSMU konsisten dengan origin code DSMU
- **Logic (EN):** MSMU origin code is consistent with the DSMU origin code
- **Operational meaning (ID):** Kode asal pada Master SMU harus sesuai dengan kode asal pada Detail Bag SMU. Perbedaan menandakan adanya ketidaksesuaian antara data SMU induk dan detail bag-nya.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (CONS) Origin Difference (SMU Master Origin vs SMU Detail Bag Origin)

## CONS2N4

- **Element:** Consistency
- **Table.column:** `CMS_MSMU.MSMU_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data destination code MSMU konsisten dengan destination code DSMU
- **Logic (EN):** MSMU destination code is consistent with the DSMU destination code
- **Operational meaning (ID):** Kode tujuan pada Master SMU harus sesuai dengan kode tujuan pada Detail Bag SMU. Perbedaan menandakan adanya ketidaksesuaian antara data SMU induk dan detail bag-nya.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (CONS) Destination Difference (SMU Master Destination vs SMU Detail Bag Destination)

## CONS2R2

- **Element:** Consistency
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data timestamp POD konsisten dengan timestamp Runsheet
- **Logic (EN):** POD timestamp is consistent with the runsheet timestamp
- **Operational meaning (ID):** Tanggal pada Proof of Delivery (POD) harus sesuai dengan tanggal pada Runsheet. Perbedaan waktu menandakan adanya ketidaksesuaian antara catatan pengiriman dan bukti serah terima paket.
- **Business impact:** TBD
- **Issue label:** (CONS) Timestamp Difference (POD Date vs Runsheet Date)

## CONS2R4

- **Element:** Consistency
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_STATUS`
- **Business indicator:** Status
- **Logic (ID):** Data status POD konsisten dengan status Runsheet
- **Logic (EN):** POD status is consistent with the runsheet status
- **Operational meaning (ID):** Status pengiriman pada Proof of Delivery (POD) harus sesuai dengan status yang tercatat pada Runsheet. Perbedaan status dapat menimbulkan dispute antara data pengiriman dan bukti serah terima.
- **Business impact:** TBD
- **Issue label:** (CONS) Status Difference (POD Status vs Runsheet Status)

## CONS2S8

- **Element:** Consistency
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_RSHEET_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data quantity Handover Runsheet konsisten dengan berat paket CMS_CNOTE
- **Logic (EN):** Handover runsheet quantity is consistent with CMS_CNOTE [NOTE: source text says weight; column is a quantity]
- **Operational meaning (ID):** Jumlah paket yang tercatat dalam Handover Runsheet harus sesuai dengan jumlah yang ada di data connote. Perbedaan dapat menandakan ada paket yang tidak terdistribusi dengan benar.
- **Business impact:** TBD
- **Issue label:** (CONS) Quantity Difference (Handover Runsheet Quantity vs CMS Cnote Quantity)

## CONS2U4

- **Element:** Consistency
- **Table.column:** `CMS_DHOUNDEL_POD.DHOUNDEL_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data quantity POD undelivered quantity konsisten dengan CMS_CNOTE
- **Logic (EN):** POD undelivered quantity is consistent with CMS_CNOTE
- **Operational meaning (ID):** Data pada Detail Handover Undelivered POD harus memenuhi ketentuan yang berlaku: Data quantity POD undelivered quantity konsisten dengan CMS_CNOTE
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## CONS2W4

- **Element:** Consistency
- **Table.column:** `CMS_DHOCNOTE.DHOCNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data quantity Handover quantity konsisten dengan CMS_CNOTE
- **Logic (EN):** Handover quantity is consistent with CMS_CNOTE
- **Operational meaning (ID):** Jumlah paket yang tercatat dalam Handover Outbound harus sesuai dengan jumlah yang ada di data connote. Perbedaan dapat menandakan ada paket yang terlewat saat proses handover keluar.
- **Business impact:** TBD
- **Issue label:** (CONS) Quantity Difference (Outbound Handover Quantity vs CMS Cnote Quantity)

## CONS2X4

- **Element:** Consistency
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Data destination code MTS/MTI konsisten dengan destination code CMS_NOTE
- **Logic (EN):** MTS/MTI destination code is consistent with the CMS_CNOTE destination code
- **Operational meaning (ID):** Kode tujuan yang tercatat oleh agen transit (MTS) harus sesuai dengan kode tujuan yang ada di connote. Perbedaan dapat menyebabkan paket dikirim ke tujuan yang salah.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (CONS) Destination Difference (MTS Agent Destination vs CMS Cnote Destination)

## CONS2X5

- **Element:** Consistency
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.CTC_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data berat paket CTC cabang konsisten dengan berat paket di CMS_CNOTE (Change to compare to MFCNOTE_WEIGHT in table CMS_MFCNOTE)
- **Logic (EN):** Branch CTC package weight is consistent with CMS_CNOTE package weight (pending change: compare against MFCNOTE_WEIGHT in CMS_MFCNOTE)
- **Operational meaning (ID):** Berat CTC yang tercatat oleh agen transit harus sesuai dengan berat yang ada dalam MFCnote. Perbedaan dapat mempengaruhi tarif dan akurasi data berat pengiriman.
- **Business impact:** Reporting — Internal Dispute
- **Issue label:** (CONS) Weight Difference (MTS Agent CTC Weight vs MFCnote Weight)

## CONS2X6

- **Element:** Consistency
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.ACT_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data berat paket ACT cabang konsisten dengan berat paket di CMS_CNOTE (Change to compare to MFCNOTE_WEIGHT in table CMS_MFCNOTE)
- **Logic (EN):** Branch ACT package weight is consistent with CMS_CNOTE package weight (pending change: compare against MFCNOTE_WEIGHT in CMS_MFCNOTE)
- **Operational meaning (ID):** Berat paket yang tercatat pada tahap Handover tidak sesuai dengan berat referensi yang terdapat pada master data CMS_CNOTE.
- **Business impact:** Reporting — Internal Dispute
- **Issue label:** (CONS) Weight Difference (MTS Agent Actual Weight vs CMS Cnote Weight)

## CONS2Y5

- **Element:** Consistency
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.CNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data quantity MTS/MTI Cabang konsisten dengan berat paket CMS_CNOTE
- **Logic (EN):** Branch MTS/MTI quantity is consistent with CMS_CNOTE [NOTE: source text says weight; column is a quantity]
- **Operational meaning (ID):** Jumlah paket yang dicatat oleh agen pengiriman (DTS) harus sesuai dengan jumlah yang ada di data connote. Perbedaan menandakan ada selisih pencatatan antara JNE dan agen pengiriman.
- **Business impact:** TBD
- **Issue label:** (CONS) Quantity Difference (DTS Agent Quantity vs CMS Cnote Quantity)

## CONS2Y6

- **Element:** Consistency
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.CNOTE_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data berat paket MTS/MTI Cabang konsisten dengan berat paket CMS_CNOTE
- **Logic (EN):** Branch MTS/MTI package weight is consistent with CMS_CNOTE package weight
- **Operational meaning (ID):** Berat yang tercatat oleh agen pengiriman (DTS) harus sesuai dengan berat yang ada di data connote. Perbedaan berat dapat menyebabkan sengketa tarif dengan agen.
- **Business impact:** Reporting — Internal Dispute
- **Issue label:** (CONS) Weight Difference (DTS Agent Weight vs CMS Cnote Weight)

## CONS2Y8

- **Element:** Consistency
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.CNOTE_SERVICES_CODE`
- **Business indicator:** Service Code
- **Logic (ID):** Data service code MTS/MTI Cabang konsisten dengan service code CMS_CNOTE
- **Logic (EN):** Branch MTS/MTI service code is consistent with the CMS_CNOTE service code
- **Operational meaning (ID):** Kode layanan yang dicatat oleh agen pengiriman (DTS) harus sesuai dengan kode layanan yang ada di connote. Perbedaan dapat menyebabkan kesalahan penetapan tarif.
- **Business impact:** TBD
- **Issue label:** (CONS) Service Code Difference (DTS Agent Service Code vs CMS Cnote Service Code)

## CONS3H4

- **Element:** Consistency
- **Table.column:** `CMS_MANIFEST.MANIFEST_ROUTE`
- **Business indicator:** Route Code
- **Logic (ID):** Data manifest route code konsisten dengan CMS_CNOTE
- **Logic (EN):** Manifest route code is consistent with CMS_CNOTE
- **Operational meaning (ID):** Karakter ke-9 hingga ke-11 pada kode rute manifest harus sesuai dengan kode tujuan di connote. Perbedaan menandakan ketidaksesuaian antara rute manifest dan tujuan paket.
- **Business impact:** TBD
- **Issue label:** (CONS) Route Code Difference (Manifest Route Letters 9-11 vs Cnote Destination)

## CONS3J3

- **Element:** Consistency
- **Table.column:** `CMS_MFBAG.MFBAG_ACT_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data berat manifest bag konsisten dengan jumlah berat paket dalam manifest
- **Logic (EN):** Manifest bag weight is consistent with the sum of package weights in the manifest
- **Operational meaning (ID):** Berat aktual bag yang tercatat dalam Manifest Bag harus sesuai dengan jumlah total berat seluruh connote di dalamnya. Perbedaan dapat menandakan ada paket yang tercatat tidak lengkap.
- **Business impact:** Reporting — Internal Dispute
- **Issue label:** (CONS) Weight Difference (Manifest Bag Actual Weight vs MFCnote Weight Sum)

## CONS3J4

- **Element:** Consistency
- **Table.column:** `CMS_MFBAG.MFBAG_CTC_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data berat bag manifest CTC konsisten dengan jumlah berat paket dalam Manifest
- **Logic (EN):** Manifest bag CTC weight is consistent with the sum of package weights in the manifest
- **Operational meaning (ID):** Berat bag yang tercatat dalam Manifest Bag tidak sesuai dengan total berat paket yang terdapat dalam manifest tersebut.
- **Business impact:** Reporting — Internal Dispute
- **Issue label:** (CONS) Weight Difference (Manifest Bag CTC Weight vs MFCnote Weight Sum)

## CONS3K5

- **Element:** Consistency
- **Table.column:** `CMS_DMBAG.DMBAG_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data berat bag DMBAG konsisten dengan berat bag MFBAC_CTC_WEIGHT (Tambahkan logic multicolly karena DMBAG memang boleh duplicate)
- **Logic (EN):** DMBAG bag weight is consistent with MFBAG_CTC_WEIGHT (multi-colly logic added because DMBAG may legitimately duplicate)
- **Operational meaning (ID):** Berat yang tercatat dalam Detail Bag harus sesuai dengan berat yang tercatat dalam Manifest Bag. Perbedaan menandakan ketidaksesuaian antara data bag dan manifest pengiriman.
- **Business impact:** Reporting — Internal Dispute
- **Issue label:** (CONS) Weight Difference (Detail Bag Weight vs Manifest Bag Weight)

## CONS3N10

- **Element:** Consistency
- **Table.column:** `CMS_MSMU.MSMU_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data berat bag MSMU konsisten dengan jumlah berat bag dalam DSMU
- **Logic (EN):** MSMU bag weight is consistent with the sum of bag weights in DSMU
- **Operational meaning (ID):** Berat yang tercatat dalam Master SMU harus sesuai dengan total berat seluruh connote dalam manifest. Perbedaan menandakan ketidaksesuaian antara data SMU dan data connote.
- **Business impact:** Reporting — Internal Dispute
- **Issue label:** (CONS) Weight Difference (SMU Master Weight vs MFCnote Weight Sum)

## CONS4L6

- **Element:** Consistency
- **Table.column:** `CMS_MMBAG.MMBAG_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data jumlah paket MMBAG konsisten dengan jumlah paket dalam bag Manifest
- **Logic (EN):** MMBAG package count is consistent with the package count in the manifest bag
- **Operational meaning (ID):** Jumlah paket yang tercatat dalam Master Bag harus sesuai dengan jumlah connote yang terdaftar dalam manifest. Perbedaan menandakan ada connote yang belum tercatat atau terdapat selisih.
- **Business impact:** TBD
- **Issue label:** (CONS) Quantity Difference (Master Bag Quantity vs MFCnote Count)

## CONS4N9

- **Element:** Consistency
- **Table.column:** `CMS_MSMU.MSMU_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data jumlah paket bag MSMU konsisten dengan jumlah paket bag dalam DSMU
- **Logic (EN):** MSMU bag package count is consistent with the bag package count in DSMU
- **Operational meaning (ID):** Jumlah yang tercatat dalam SMU harus sesuai dengan jumlah bag yang terdaftar dalam Detail SMU. Perbedaan menandakan ada bag yang belum tercatat atau terdapat selisih dalam pendataan.
- **Business impact:** TBD
- **Issue label:** (CONS) Quantity Difference (SMU Quantity vs DSMU Bag Count)

## TIME1AB5

- **Element:** Timeliness
- **Table.column:** `CMS_MHICNOTE.MHICNOTE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Dokumen Handover Inbound dibuat sebelum Run Sheet?
- **Logic (EN):** Was the inbound handover document created before the runsheet?
- **Operational meaning (ID):** Dokumen Handover Inbound seharusnya dibuat sebelum Runsheet diterbitkan. Jika urutan ini terbalik, menandakan adanya ketidaksesuaian dalam alur proses pengiriman di cabang.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## TIME1B2

- **Element:** Timeliness
- **Table.column:** `CMS_CNOTE.CNOTE_CRDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** pembuatan Cnote dibuat sebelum Receival Drop Off? (Diganti jadi CNOTE_DATE)
- **Logic (EN):** Is the cnote created before the drop-off receival? (pending change: use CNOTE_DATE)
- **Operational meaning (ID):** Dokumen ini seharusnya dibuat setelah connote diterbitkan. Jika urutan waktunya terbalik, menandakan ada ketidaksesuaian dalam alur proses pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## TIME1C9

- **Element:** Timeliness
- **Table.column:** `CMS_MRCNOTE.MRCNOTE_SIGNDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Receival Dokumen dibuat sebelum Manifest Bag?
- **Logic (EN):** Was the receival document created before the manifest bag?
- **Operational meaning (ID):** Dokumen Receival dibuat setelah tanggal pembuatan Manifest Bag, sehingga urutan waktu pemrosesan tidak sesuai dengan alur yang seharusnya.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## TIME1E7

- **Element:** Timeliness
- **Table.column:** `CMS_MHI_HOC.MHI_APPROVE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Receival Drop off dokumen dilakukan sebelum receival dokumen
- **Logic (EN):** The drop-off receival document is created before the receival document
- **Operational meaning (ID):** Dokumen Receival seharusnya dibuat setelah proses penerimaan paket. Jika urutan waktunya terbalik, menandakan ada ketidaksesuaian dalam alur penerimaan barang di gudang/cabang.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## TIME1H15 (OM)

- **Element:** Timeliness
- **Table.column:** `CMS_MANIFEST.MFBAG_CRDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Pembuatan Outbound Manifest dilakukan sebelum pembuatan Manifest Bag
- **Logic (EN):** The outbound manifest is created before the manifest bag
- **Operational meaning (ID):** Dokumen ini seharusnya dibuat sebelum atau bersamaan dengan Manifest Bag. Jika urutan waktunya terbalik, menandakan ada ketidaksesuaian dalam alur proses pembuatan manifest.
- **Business impact:** TBD
- **Issue label:** (TIME) Manifest Timestamp Sequence Issue

## TIME1I9 (IM)

- **Element:** Timeliness
- **Table.column:** `CMS_MFCNOTE.MANIFEST_CRDATE (TM)`
- **Business indicator:** Timestamp
- **Logic (ID):** Pembuatan Transit Manifest dilakukan sebelum Inbound Manifest? (Ganti pake Table MFCNOTE)
- **Logic (EN):** Is the transit manifest created before the inbound manifest? (pending change: use table MFCNOTE)
- **Operational meaning (ID):** Urutan waktu pemrosesan pada daftar connote dalam Manifest (MFCnote) tidak sesuai dengan alur yang seharusnya. Hal ini dapat mengindikasikan adanya kesalahan pencatatan atau proses yang tidak sesuai prosedur.
- **Business impact:** TBD
- **Issue label:** (TIME) Manifest Timestamp Sequence Issue

## TIME1I9 (OM)

- **Element:** Timeliness
- **Table.column:** `CMS_MFCNOTE.MANIFEST_CRDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Dokumen Manifest Inbound dibuat sebelum Manifest Transit? (Ganti pake Table MFCNOTE)
- **Logic (EN):** Was the inbound manifest created before the transit manifest? (pending change: use table MFCNOTE)
- **Operational meaning (ID):** Urutan waktu pemrosesan pada daftar connote dalam Manifest (MFCnote) tidak sesuai dengan alur yang seharusnya. Hal ini dapat mengindikasikan adanya kesalahan pencatatan atau proses yang tidak sesuai prosedur.
- **Business impact:** TBD
- **Issue label:** (TIME) Manifest Timestamp Sequence Issue

## TIME1I9 (TM)

- **Element:** Timeliness
- **Table.column:** `CMS_MFCNOTE.MANIFEST_CRDATE (TM)`
- **Business indicator:** Timestamp
- **Logic (ID):** Pembuatan Transit Manifest dilakukan sebelum Transit Manifest berikutnya? (Ganti pake Table MFCNOTE)
- **Logic (EN):** Is each transit manifest created before the next transit manifest? (pending change: use table MFCNOTE)
- **Operational meaning (ID):** Urutan waktu pemrosesan pada daftar connote dalam Manifest (MFCnote) tidak sesuai dengan alur yang seharusnya. Hal ini dapat mengindikasikan adanya kesalahan pencatatan atau proses yang tidak sesuai prosedur.
- **Business impact:** TBD
- **Issue label:** (TIME) Manifest Timestamp Sequence Issue

## TIME1Q3

- **Element:** Timeliness
- **Table.column:** `CMS_MRSHEET.MRSHEET_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Pembuatan Dokumen Runsheet itu dilakukan sebelum Proof of Delivery
- **Logic (EN):** The runsheet document is created before proof of delivery
- **Operational meaning (ID):** Dokumen ini seharusnya dibuat sebelum Runsheet diterbitkan. Jika urutan waktunya terbalik, menandakan ada ketidaksesuaian dalam alur proses distribusi paket.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## TIME1Z10

- **Element:** Timeliness
- **Table.column:** `CMS_MSJ.MSJ_SIGNDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Dokumen Handover Drop Off dibuat sebelum Handover Inbound?
- **Logic (EN):** Was the drop-off handover document created before the inbound handover?
- **Operational meaning (ID):** Urutan waktu pemrosesan pada Master Surat Jalan tidak sesuai dengan alur yang seharusnya. Hal ini dapat mengindikasikan adanya kesalahan pencatatan atau proses yang tidak sesuai prosedur.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1A2

- **Element:** Uniqueness
- **Table.column:** `CMS_APICUST.APICUST_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada kiriman dari pelanggan (marketplace/platform) tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1AD1

- **Element:** Uniqueness
- **Table.column:** `CMS_RDSJ.RDSJ_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Retur Detail Surat Jalan tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1AD2

- **Element:** Uniqueness
- **Table.column:** `CMS_RDSJ.RDSJ_BAG_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Retur Detail Surat Jalan tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1AD3

- **Element:** Uniqueness
- **Table.column:** `CMS_RDSJ.RDSJ_HVO_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Retur Detail Surat Jalan tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1AD6

- **Element:** Uniqueness
- **Table.column:** `CMS_RDSJ.RDSJ_HVI_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Retur Detail Surat Jalan tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1B1

- **Element:** Uniqueness
- **Table.column:** `CMS_CNOTE.CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Connote (resi pengiriman) tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1B74

- **Element:** Uniqueness
- **Table.column:** `CMS_CNOTE.CNOTE_REFNO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Connote (resi pengiriman) tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1C1

- **Element:** Uniqueness
- **Table.column:** `CMS_MRCNOTE.MRCNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Master Receival Connote (dokumen penerimaan barang di gudang) tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1F5

- **Element:** Uniqueness
- **Table.column:** `CMS_DHI_HOC.DHI_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Detail Handover Inbound Cabang tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1G1

- **Element:** Uniqueness
- **Table.column:** `CMS_DSTATUS.DSTATUS_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada data Status pengiriman tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1G2

- **Element:** Uniqueness
- **Table.column:** `CMS_DSTATUS.DSTATUS_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada data Status pengiriman tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1H1

- **Element:** Uniqueness
- **Table.column:** `CMS_MANIFEST.MANIFEST_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Manifest pengiriman tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1K1

- **Element:** Uniqueness
- **Table.column:** `CMS_DMBAG.DMBAG_BAG_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Detail Manifest Bag tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1L2

- **Element:** Uniqueness
- **Table.column:** `CMS_MMBAG.MMBAG_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Master Manifest Bag tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1M4

- **Element:** Uniqueness
- **Table.column:** `CMS_DSMU.DSMU_BAG_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Detail SMU (Surat Muatan Udara) tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1N1

- **Element:** Uniqueness
- **Table.column:** `CMS_MSMU.MSMU_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Master SMU (Surat Muatan Udara) tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1O1

- **Element:** Uniqueness
- **Table.column:** `CMS_DRSHEET_PRA.DRSHEET_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Runsheet Pra-Pengiriman tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1O2

- **Element:** Uniqueness
- **Table.column:** `CMS_DRSHEET_PRA.DRSHEET_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Runsheet Pra-Pengiriman tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1R1

- **Element:** Uniqueness
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Proof of Delivery (bukti terima paket) tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan serah terima paket.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1S2

- **Element:** Uniqueness
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_RSHEET_CNOTE`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Detail Handover Runsheet tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1T2

- **Element:** Uniqueness
- **Table.column:** `CMS_MHOUNDEL_POD.MHOUNDEL_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Master Handover Undelivered POD tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1X1

- **Element:** Uniqueness
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.MANIFEST_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada biaya transit agen (master) tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1Y2

- **Element:** Uniqueness
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada biaya transit agen (detail) tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ1Z1

- **Element:** Uniqueness
- **Table.column:** `CMS_MSJ.MSJ_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Master Surat Jalan tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2AA2-3

- **Element:** Uniqueness
- **Table.column:** `CMS_DSJ.DSJ_BAG_NO, DSJ_HVO_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kombinasi unique identifier tidak lebih dari 1
- **Logic (EN):** The combination of unique identifiers occurs no more than once
- **Operational meaning (ID):** Kombinasi nomor identifikasi pada Detail Surat Jalan harus unik dan tidak boleh terduplikasi. Data ganda dapat menyebabkan kerancuan dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2AC1

- **Element:** Uniqueness
- **Table.column:** `CMS_DHICNOTE.DHICNOTE_NO, DHICNOTE_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kombinasi unique identifier tidak lebih dari 1
- **Logic (EN):** The combination of unique identifiers occurs no more than once
- **Operational meaning (ID):** Kombinasi nomor identifikasi pada Detail Handover Inbound Connote harus unik dan tidak boleh terduplikasi. Data ganda dapat menyebabkan kerancuan dalam proses penerimaan paket di cabang.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2AC3

- **Element:** Uniqueness
- **Table.column:** `CMS_DHICNOTE.DHICNOTE_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada detail Handover Inbound Connote tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2AE1

- **Element:** Uniqueness
- **Table.column:** `CMS_DBAG_HO.DBAG_HO_NO, DBAG_NO, DBAG_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Detail Bag Handover Cabang tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan paket pada proses handover di cabang.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2AE1-2-3

- **Element:** Uniqueness
- **Table.column:** `CMS_DBAG_HO.DBAG_HO_NO, DBAG_NO, DBAG_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kombinasi unique identifier tidak lebih dari 1
- **Logic (EN):** The combination of unique identifiers occurs no more than once
- **Operational meaning (ID):** Kombinasi nomor identifikasi pada Detail Bag Handover Cabang harus unik dan tidak boleh terduplikasi. Data ganda dapat menyebabkan kerancuan dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2D1

- **Element:** Uniqueness
- **Table.column:** `CMS_DRCNOTE.DRCNOTE_NO, DRCNOTE_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Detail Receival Connote (dokumen penerimaan barang di gudang) tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pencatatan penerimaan barang.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2D1-2

- **Element:** Uniqueness
- **Table.column:** `CMS_DRCNOTE.DRCNOTE_NO, DRCNOTE_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kombinasi unique identifier tidak lebih dari 1
- **Logic (EN):** The combination of unique identifiers occurs no more than once
- **Operational meaning (ID):** Kombinasi nomor identifikasi pada Detail Receival Connote (dokumen penerimaan barang di gudang) harus unik dan tidak boleh terduplikasi. Data ganda dapat menyebabkan kerancuan dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2F1-3-5

- **Element:** Uniqueness
- **Table.column:** `CMS_DHI_HOC.DHI_NO, DHI_ONO, DHI_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kombinasi unique identifier tidak lebih dari 1
- **Logic (EN):** The combination of unique identifiers occurs no more than once
- **Operational meaning (ID):** Kombinasi nomor identifikasi pada Detail Handover Inbound Cabang harus unik dan tidak boleh terduplikasi. Data ganda dapat menyebabkan kerancuan dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2I1

- **Element:** Uniqueness
- **Table.column:** `CMS_MFCNOTE.MFCNOTE_MAN_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Terdapat duplikasi pada kode Manifest, di mana kode yang sama muncul lebih dari satu kali.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2J1

- **Element:** Uniqueness
- **Table.column:** `CMS_MFBAG.MFBAG_MAN_NO, MFBAG_NO, ESB_ID`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada daftar bag dalam Manifest (MFBag) tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kerancuan dalam pencatatan bag di dalam manifest pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2J1-2-21

- **Element:** Uniqueness
- **Table.column:** `CMS_MFBAG.MFBAG_MAN_NO, MFBAG_NO, ESB_ID`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kombinasi unique identifier tidak lebih dari 1
- **Logic (EN):** The combination of unique identifiers occurs no more than once
- **Operational meaning (ID):** Kombinasi nomor identifikasi pada daftar bag dalam Manifest (MFBag) harus unik dan tidak boleh terduplikasi. Data ganda dapat menyebabkan kerancuan dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2P1

- **Element:** Uniqueness
- **Table.column:** `CMS_DRSHEET.DRSHEET_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Detail Runsheet tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2R1

- **Element:** Uniqueness
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_NO, CNOTE_POD_DOC_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kombinasi unique identifier tidak lebih dari 1
- **Logic (EN):** The combination of unique identifiers occurs no more than once
- **Operational meaning (ID):** Kombinasi nomor identifikasi pada Proof of Delivery (bukti terima paket) harus unik dan tidak boleh terduplikasi. Data ganda dapat menyebabkan kerancuan dalam proses verifikasi serah terima paket.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2S1

- **Element:** Uniqueness
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_DOC_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Proof of Delivery / bukti terima paket tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2U1

- **Element:** Uniqueness
- **Table.column:** `CMS_DHOUNDEL_POD.DHOUNDEL_NO, DHOUNDEL_CNOTE_NO, DHOUNDEL_HRS`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Detail Handover Undelivered POD tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pencatatan paket yang tidak berhasil terkirim.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2U1-3-10

- **Element:** Uniqueness
- **Table.column:** `CMS_DHOUNDEL_POD.DHOUNDEL_NO, DHOUNDEL_CNOTE_NO, DHOUNDEL_HRS`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kombinasi unique identifier tidak lebih dari 1
- **Logic (EN):** The combination of unique identifiers occurs no more than once
- **Operational meaning (ID):** Kombinasi nomor identifikasi pada Detail Handover Undelivered POD harus unik dan tidak boleh terduplikasi. Data ganda dapat menyebabkan kerancuan dalam proses pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2W1

- **Element:** Uniqueness
- **Table.column:** `CMS_DHOCNOTE.DHOCNOTE_NO, DHOCNOTE_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kombinasi unique identifier tidak lebih dari 1
- **Logic (EN):** The combination of unique identifiers occurs no more than once
- **Operational meaning (ID):** Kombinasi nomor identifikasi pada Detail Handover Outbound Connote harus unik dan tidak boleh terduplikasi. Data ganda dapat menyebabkan kerancuan dalam proses pengiriman paket keluar dari cabang.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## UNIQ2W3

- **Element:** Uniqueness
- **Table.column:** `CMS_DHOCNOTE.DHOCNOTE_CNOTE_NO`
- **Business indicator:** Unique Identifier
- **Logic (ID):** Kode Unique Identifier tidak lebih dari 1
- **Logic (EN):** The unique identifier code occurs no more than once
- **Operational meaning (ID):** Nomor identifikasi pada Detail Handover Outbound Connote tidak boleh muncul lebih dari satu kali dalam sistem. Duplikasi data dapat menyebabkan kesalahan dalam pelacakan dan pencatatan pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD10S5

- **Element:** Validity
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_RSHEET_UNDEL`
- **Business indicator:** Flag
- **Logic (ID):** Data adalah angka 1 atau 0
- **Logic (EN):** Value is 1 or 0
- **Operational meaning (ID):** Nilai penanda pada Detail Handover Runsheet hanya boleh berisi angka 1 (ya/aktif) atau 0 (tidak/nonaktif). Nilai selain itu dianggap tidak valid.
- **Business impact:** TBD
- **Issue label:** (VALD) Invalid Flag Value

## VALD11P4

- **Element:** Validity
- **Table.column:** `CMS_DRSHEET.DRSHEET_STATUS`
- **Business indicator:** Status
- **Logic (ID):** Data adalah D atau U
- **Logic (EN):** Value is D or U
- **Operational meaning (ID):** Format status pada Detail Runsheet tidak sesuai dengan ketentuan yang berlaku. Status harus mengikuti format yang telah ditetapkan dalam sistem JNE.
- **Business impact:** TBD
- **Issue label:** (VALD) Invalid Status Format

## VALD11R4

- **Element:** Validity
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_STATUS`
- **Business indicator:** Status
- **Logic (ID):** Data adalah D atau U dan ada angka diakhir
- **Logic (EN):** Value is D or U followed by a digit
- **Operational meaning (ID):** Status pada Proof of Delivery / bukti terima paket harus diisi dengan format 'D' atau 'U' diikuti angka di akhir (contoh: D1, U2). Format lain dianggap tidak valid.
- **Business impact:** TBD
- **Issue label:** (VALD) Invalid Status Format

## VALD11S19

- **Element:** Validity
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_DRSHEET_STATUS`
- **Business indicator:** Status
- **Logic (ID):** Data adalah D atau U dan ada angka diakhir
- **Logic (EN):** Value is D or U followed by a digit
- **Operational meaning (ID):** Status pada Detail Handover Runsheet harus diisi dengan format 'D' atau 'U' diikuti angka di akhir (contoh: D1, U2). Format lain dianggap tidak valid.
- **Business impact:** TBD
- **Issue label:** (VALD) Invalid Status Format

## VALD12A4

- **Element:** Validity
- **Table.column:** `CMS_APICUST.APICUST_BRANCH`
- **Business indicator:** Branch ID
- **Logic (ID):** Format sesuai dalam ORA_BRANCH
- **Logic (EN):** The value exists in the ORA_BRANCH reference table
- **Operational meaning (ID):** Kode cabang pada kiriman dari pelanggan (marketplace/platform) harus terdaftar dalam referensi data cabang JNE (ORA_BRANCH). Kode cabang yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD12AB1

- **Element:** Validity
- **Table.column:** `CMS_MHICNOTE.MHICNOTE_BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Format sesuai dalam ORA_BRANCH
- **Logic (EN):** The value exists in the ORA_BRANCH reference table
- **Operational meaning (ID):** Kode cabang pada manifest Handover Inbound Connote harus terdaftar dalam referensi data cabang JNE (ORA_BRANCH). Kode cabang yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD12B3

- **Element:** Validity
- **Table.column:** `CMS_CNOTE.CNOTE_BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Format sesuai dalam ORA_BRANCH
- **Logic (EN):** The value exists in the ORA_BRANCH reference table
- **Operational meaning (ID):** Kode cabang pada Connote (resi pengiriman) harus terdaftar dalam referensi data cabang JNE (ORA_BRANCH). Kode cabang yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD12C3

- **Element:** Validity
- **Table.column:** `CMS_MRCNOTE.MRCNOTE_BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Format sesuai dalam ORA_BRANCH
- **Logic (EN):** The value exists in the ORA_BRANCH reference table
- **Operational meaning (ID):** Kode cabang pada Master Receival Connote (dokumen penerimaan barang di gudang) harus terdaftar dalam referensi data cabang JNE (ORA_BRANCH). Kode cabang yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD12E6

- **Element:** Validity
- **Table.column:** `CMS_MHI_HOC.MHI_BRANCH`
- **Business indicator:** Branch ID
- **Logic (ID):** Format sesuai dalam ORA_BRANCH
- **Logic (EN):** The value exists in the ORA_BRANCH reference table
- **Operational meaning (ID):** Kode cabang pada Master Handover Inbound Cabang harus terdaftar dalam referensi data cabang JNE (ORA_BRANCH). Kode cabang yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD12L1

- **Element:** Validity
- **Table.column:** `CMS_MMBAG.MMBAG_BRANCH`
- **Business indicator:** Branch ID
- **Logic (ID):** Format sesuai dalam ORA_BRANCH
- **Logic (EN):** The value exists in the ORA_BRANCH reference table
- **Operational meaning (ID):** Kode cabang pada Master Manifest Bag harus terdaftar dalam referensi data cabang JNE (ORA_BRANCH). Kode cabang yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD12Q1

- **Element:** Validity
- **Table.column:** `CMS_MRSHEET.MRSHEET_BRANCH`
- **Business indicator:** Branch ID
- **Logic (ID):** Format sesuai dalam ORA_BRANCH
- **Logic (EN):** The value exists in the ORA_BRANCH reference table
- **Operational meaning (ID):** Kode cabang pada Master Runsheet harus terdaftar dalam referensi data cabang JNE (ORA_BRANCH). Kode cabang yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD12T1

- **Element:** Validity
- **Table.column:** `CMS_MHOUNDEL_POD.MHOUNDEL_BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Format sesuai dalam ORA_BRANCH
- **Logic (EN):** The value exists in the ORA_BRANCH reference table
- **Operational meaning (ID):** Kode cabang pada Master Handover Undelivered POD harus terdaftar dalam referensi data cabang JNE (ORA_BRANCH). Kode cabang yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD12V1

- **Element:** Validity
- **Table.column:** `CMS_MHOCNOTE.MHOCNOTE_BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Format sesuai dalam ORA_BRANCH
- **Logic (EN):** The value exists in the ORA_BRANCH reference table
- **Operational meaning (ID):** Kode cabang pada Master Handover Outbound Connote harus terdaftar dalam referensi data cabang JNE (ORA_BRANCH). Kode cabang yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD12X3

- **Element:** Validity
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Format sesuai dalam ORA_BRANCH
- **Logic (EN):** The value exists in the ORA_BRANCH reference table
- **Operational meaning (ID):** Kode cabang pada biaya transit agen (master) harus terdaftar dalam referensi data cabang JNE (ORA_BRANCH). Kode cabang yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD12Z2

- **Element:** Validity
- **Table.column:** `CMS_MSJ.MSJ_BRANCH_ID`
- **Business indicator:** Branch ID
- **Logic (ID):** Format sesuai dalam ORA_BRANCH
- **Logic (EN):** The value exists in the ORA_BRANCH reference table
- **Operational meaning (ID):** Kode cabang pada Master Surat Jalan harus terdaftar dalam referensi data cabang JNE (ORA_BRANCH). Kode cabang yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD13AB2

- **Element:** Validity
- **Table.column:** `CMS_MHICNOTE.MHICNOTE_ZONE`
- **Business indicator:** Zone Code
- **Logic (ID):** Format sesuai dalam ORA_ZONE
- **Logic (EN):** The value exists in the ORA_ZONE reference table
- **Operational meaning (ID):** Kode zona pada manifest Handover Inbound Connote harus terdaftar dalam referensi data zona JNE (ORA_ZONE). Kode zona yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD13AE10

- **Element:** Validity
- **Table.column:** `CMS_DBAG_HO.DBAG_ZONE_DEST`
- **Business indicator:** Zone Code
- **Logic (ID):** Format sesuai dalam ORA_ZONE
- **Logic (EN):** The value exists in the ORA_ZONE reference table
- **Operational meaning (ID):** Kode zona pada Detail Bag Handover Cabang harus terdaftar dalam referensi data zona JNE (ORA_ZONE). Kode zona yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD13E11

- **Element:** Validity
- **Table.column:** `CMS_MHI_HOC.MHI_ZONE`
- **Business indicator:** Zone Code
- **Logic (ID):** Format sesuai dalam ORA_ZONE
- **Logic (EN):** The value exists in the ORA_ZONE reference table
- **Operational meaning (ID):** Kode zona pada Master Handover Inbound Cabang harus terdaftar dalam referensi data zona JNE (ORA_ZONE). Kode zona yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD13G13

- **Element:** Validity
- **Table.column:** `CMS_DSTATUS.DSTATUS_ZONE_CODE`
- **Business indicator:** Zone Code
- **Logic (ID):** Format sesuai dalam ORA_ZONE
- **Logic (EN):** The value exists in the ORA_ZONE reference table
- **Operational meaning (ID):** Kode zona pada data Status pengiriman harus terdaftar dalam referensi data zona JNE (ORA_ZONE). Kode zona yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD13P7

- **Element:** Validity
- **Table.column:** `CMS_DRSHEET.DRSHEET_UID`
- **Business indicator:** User ID
- **Logic (ID):** Format sesuai dalam ORA_ZONE
- **Logic (EN):** The value exists in the ORA_ZONE reference table
- **Operational meaning (ID):** Berat paket yang tercatat pada tahap Handover tidak sesuai dengan berat referensi yang terdapat pada master data CMS_CNOTE.
- **Business impact:** TBD
- **Issue label:** (VALD) Destination Code Does Not Exist in Route Reference

## VALD13S10

- **Element:** Validity
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_RSHEET_UZONE`
- **Business indicator:** Zone Code
- **Logic (ID):** Format sesuai dalam ORA_ZONE
- **Logic (EN):** The value exists in the ORA_ZONE reference table
- **Operational meaning (ID):** Kode zona pada Detail Handover Runsheet harus terdaftar dalam referensi data zona JNE (ORA_ZONE). Kode zona yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD13T6

- **Element:** Validity
- **Table.column:** `CMS_MHOUNDEL_POD.MHOUNDEL_ZONE`
- **Business indicator:** Zone Code
- **Logic (ID):** Format sesuai dalam ORA_ZONE
- **Logic (EN):** The value exists in the ORA_ZONE reference table
- **Operational meaning (ID):** Kode zona pada Master Handover Undelivered POD harus terdaftar dalam referensi data zona JNE (ORA_ZONE). Kode zona yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD13V2

- **Element:** Validity
- **Table.column:** `CMS_MHOCNOTE.MHOCNOTE_ZONE`
- **Business indicator:** Zone Code
- **Logic (ID):** Format sesuai dalam ORA_ZONE
- **Logic (EN):** The value exists in the ORA_ZONE reference table
- **Operational meaning (ID):** Kode zona pada Master Handover Outbound Connote harus terdaftar dalam referensi data zona JNE (ORA_ZONE). Kode zona yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD13V5

- **Element:** Validity
- **Table.column:** `CMS_MHOCNOTE.MHOCNOTE_ZONE_DEST`
- **Business indicator:** Zone Code
- **Logic (ID):** Format sesuai dalam ORA_ZONE
- **Logic (EN):** The value exists in the ORA_ZONE reference table
- **Operational meaning (ID):** Kode zona pada Master Handover Outbound Connote harus terdaftar dalam referensi data zona JNE (ORA_ZONE). Kode zona yang tidak dikenal menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD1A3

- **Element:** Validity
- **Table.column:** `CMS_APICUST.APICUST_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode asal pada kiriman dari pelanggan (marketplace/platform) harus terdaftar dalam referensi rute JNE (DROURATE). Kode asal yang tidak dikenal dapat menyebabkan kesalahan penentuan rute pengiriman.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (VALD) Origin Code Does Not Exist in Route Reference

## VALD1A4

- **Element:** Validity
- **Table.column:** `CMS_APICUST.APICUST_BRANCH`
- **Business indicator:** Branch ID
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Data pada kiriman dari pelanggan (marketplace/platform) harus sesuai dengan referensi data rute JNE (DROURATE). Nilai yang tidak terdaftar menandakan adanya data yang tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD1A6

- **Element:** Validity
- **Table.column:** `CMS_APICUST.APICUST_SERVICES_CODE`
- **Business indicator:** Service Code
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode layanan pada kiriman dari pelanggan (marketplace/platform) harus terdaftar dalam referensi layanan JNE (DROURATE). Kode layanan yang tidak valid akan menyebabkan kesalahan dalam penetapan tarif.
- **Business impact:** TBD
- **Issue label:** (VALD) Service Code Does Not Exist in CMS DROURATE Service Reference

## VALD1A7

- **Element:** Validity
- **Table.column:** `CMS_APICUST.APICUST_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode tujuan pada kiriman dari pelanggan (marketplace/platform) harus terdaftar dalam referensi rute JNE (DROURATE). Kode tujuan yang tidak dikenal dapat menyebabkan kesalahan penentuan tarif dan rute pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD1AE6

- **Element:** Validity
- **Table.column:** `CMS_DBAG_HO.DBAG_CNOTE_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode tujuan pada Detail Bag Handover Cabang harus terdaftar dalam referensi rute JNE (DROURATE). Kode tujuan yang tidak dikenal dapat menyebabkan kesalahan penentuan tarif dan rute pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD1AE8

- **Element:** Validity
- **Table.column:** `CMS_DBAG_HO.DBAG_CNOTE_SERVICE`
- **Business indicator:** Service Code
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode layanan pada Detail Bag Handover Cabang harus terdaftar dalam referensi layanan JNE (DROURATE). Kode layanan yang tidak valid akan menyebabkan kesalahan dalam penetapan tarif.
- **Business impact:** TBD
- **Issue label:** (VALD) Service Code Does Not Exist in CMS DROURATE Service Reference

## VALD1B11

- **Element:** Validity
- **Table.column:** `CMS_CNOTE.CNOTE_ROUTE_CODE`
- **Business indicator:** Route Code
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode rute pada Connote (resi pengiriman) harus terdaftar dalam referensi rute JNE (DROURATE). Kode rute yang tidak dikenal menandakan adanya kesalahan data yang perlu ditindaklanjuti.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD1B12

- **Element:** Validity
- **Table.column:** `CMS_CNOTE.CNOTE_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode asal pada Connote (resi pengiriman) harus terdaftar dalam referensi rute JNE (DROURATE). Kode asal yang tidak dikenal dapat menyebabkan kesalahan penentuan rute pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD1B13

- **Element:** Validity
- **Table.column:** `CMS_CNOTE.CNOTE_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode tujuan pada Connote (resi pengiriman) harus terdaftar dalam referensi rute JNE (DROURATE). Kode tujuan yang tidak dikenal dapat menyebabkan kesalahan penentuan tarif dan rute pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD1B6

- **Element:** Validity
- **Table.column:** `CMS_CNOTE.CNOTE_SERVICES_CODE`
- **Business indicator:** Service Code
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Service code yang terdapat pada Route Code paket tidak ditemukan dalam referensi data CMS_DROURATE.
- **Business impact:** TBD
- **Issue label:** (VALD) Invalid Service Code Format

## VALD1H4

- **Element:** Validity
- **Table.column:** `CMS_MANIFEST.MANIFEST_ROUTE`
- **Business indicator:** Route Code
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode rute pada Manifest pengiriman harus terdaftar dalam referensi rute JNE (DROURATE). Kode rute yang tidak dikenal menandakan adanya kesalahan data yang perlu ditindaklanjuti.
- **Business impact:** TBD
- **Issue label:** (VALD) Route Code Does Not Exist in Route Reference

## VALD1H5

- **Element:** Validity
- **Table.column:** `CMS_MANIFEST.MANIFEST_FROM`
- **Business indicator:** Origin
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode asal pada Manifest pengiriman harus terdaftar dalam referensi rute JNE (DROURATE). Kode asal yang tidak dikenal dapat menyebabkan kesalahan penentuan rute pengiriman.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (VALD) Origin Code Does Not Exist in Route Reference

## VALD1H6

- **Element:** Validity
- **Table.column:** `CMS_MANIFEST.MANIFEST_THRU`
- **Business indicator:** Destination
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode tujuan pada Manifest pengiriman harus terdaftar dalam referensi rute JNE (DROURATE). Kode tujuan yang tidak dikenal dapat menyebabkan kesalahan penentuan tarif dan rute pengiriman.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (VALD) Destination Code Does Not Exist in Route Reference

## VALD1H9

- **Element:** Validity
- **Table.column:** `CMS_MANIFEST.MANIFEST_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode asal pada Manifest pengiriman harus terdaftar dalam referensi rute JNE (DROURATE). Kode asal yang tidak dikenal dapat menyebabkan kesalahan penentuan rute pengiriman.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (VALD) Origin Code Does Not Exist in Route Reference

## VALD1J10

- **Element:** Validity
- **Table.column:** `CMS_MFBAG.MFBAG_ROUTE`
- **Business indicator:** Route Code
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode rute pada daftar bag dalam Manifest (MFBag) harus terdaftar dalam referensi rute JNE (DROURATE). Kode rute yang tidak dikenal menandakan adanya kesalahan data yang perlu ditindaklanjuti.
- **Business impact:** TBD
- **Issue label:** (VALD) Route Code Does Not Exist in Route Reference

## VALD1K3

- **Element:** Validity
- **Table.column:** `CMS_DMBAG.DMBAG_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode asal pada Detail Manifest Bag harus terdaftar dalam referensi rute JNE (DROURATE). Kode asal yang tidak dikenal dapat menyebabkan kesalahan penentuan rute pengiriman.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (VALD) Origin Code Does Not Exist in Route Reference

## VALD1K4

- **Element:** Validity
- **Table.column:** `CMS_DMBAG.DMBAG_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode tujuan pada Detail Manifest Bag harus terdaftar dalam referensi rute JNE (DROURATE). Kode tujuan yang tidak dikenal dapat menyebabkan kesalahan penentuan tarif dan rute pengiriman.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (VALD) Destination Code Does Not Exist in Route Reference

## VALD1L3

- **Element:** Validity
- **Table.column:** `CMS_MMBAG.MMBAG_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode asal pada Master Manifest Bag harus terdaftar dalam referensi rute JNE (DROURATE). Kode asal yang tidak dikenal dapat menyebabkan kesalahan penentuan rute pengiriman.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (VALD) Origin Code Does Not Exist in Route Reference

## VALD1L4

- **Element:** Validity
- **Table.column:** `CMS_MMBAG.MMBAG_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode tujuan pada Master Manifest Bag harus terdaftar dalam referensi rute JNE (DROURATE). Kode tujuan yang tidak dikenal dapat menyebabkan kesalahan penentuan tarif dan rute pengiriman.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (VALD) Destination Code Does Not Exist in Route Reference

## VALD1M6

- **Element:** Validity
- **Table.column:** `CMS_DSMU.DSMU_BAG_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode asal pada Detail SMU (Surat Muatan Udara) harus terdaftar dalam referensi rute JNE (DROURATE). Kode asal yang tidak dikenal dapat menyebabkan kesalahan penentuan rute pengiriman.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (VALD) Origin Code Does Not Exist in Route Reference

## VALD1M7

- **Element:** Validity
- **Table.column:** `CMS_DSMU.DSMU_BAG_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode tujuan pada Detail SMU (Surat Muatan Udara) harus terdaftar dalam referensi rute JNE (DROURATE). Kode tujuan yang tidak dikenal dapat menyebabkan kesalahan penentuan tarif dan rute pengiriman.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (VALD) Destination Code Does Not Exist in Route Reference

## VALD1N3

- **Element:** Validity
- **Table.column:** `CMS_MSMU.MSMU_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode cabang asal pada connote tidak ditemukan dalam referensi data cabang JNE. Hal ini menandakan kode cabang asal yang digunakan tidak valid atau belum terdaftar.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (VALD) Origin Branch Code Does Not Exist in ORA_BRANCH

## VALD1N4

- **Element:** Validity
- **Table.column:** `CMS_MSMU.MSMU_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode cabang tujuan pada connote tidak ditemukan dalam referensi data cabang JNE. Hal ini menandakan kode cabang tujuan yang digunakan tidak valid atau belum terdaftar.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (VALD) Destination Branch Code Does Not Exist in ORA_BRANCH

## VALD1X4

- **Element:** Validity
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode tujuan pada biaya transit agen (master) harus terdaftar dalam referensi rute JNE (DROURATE). Kode tujuan yang tidak dikenal dapat menyebabkan kesalahan penentuan tarif dan rute pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD1Y3

- **Element:** Validity
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.CNOTE_ORIGIN`
- **Business indicator:** Origin
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode asal pada biaya transit agen (detail) harus terdaftar dalam referensi rute JNE (DROURATE). Kode asal yang tidak dikenal dapat menyebabkan kesalahan penentuan rute pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD1Y4

- **Element:** Validity
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.CNOTE_DESTINATION`
- **Business indicator:** Destination
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode tujuan pada biaya transit agen (detail) harus terdaftar dalam referensi rute JNE (DROURATE). Kode tujuan yang tidak dikenal dapat menyebabkan kesalahan penentuan tarif dan rute pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD1Y6

- **Element:** Validity
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.CNOTE_SERVICES_CODE`
- **Business indicator:** Service Code
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode layanan pada biaya transit agen (detail) harus terdaftar dalam referensi layanan JNE (DROURATE). Kode layanan yang tidak valid akan menyebabkan kesalahan dalam penetapan tarif.
- **Business impact:** TBD
- **Issue label:** (VALD) Service Code Does Not Exist in CMS DROURATE Service Reference

## VALD1Z11

- **Element:** Validity
- **Table.column:** `CMS_MSJ.MSJ_DEST`
- **Business indicator:** Destination
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode zona tujuan pada connote tidak ditemukan dalam referensi data zona JNE. Hal ini menandakan kode zona yang digunakan tidak valid atau belum terdaftar.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (VALD) Destination Zone Code Does Not Exist in ORA_ZONE

## VALD1Z12

- **Element:** Validity
- **Table.column:** `CMS_MSJ.MSJ_ORIG`
- **Business indicator:** Origin
- **Logic (ID):** Format sesuai dalam CMS_DROURATE
- **Logic (EN):** The value exists in the CMS_DROURATE reference table
- **Operational meaning (ID):** Kode zona asal pada connote tidak ditemukan dalam referensi data zona JNE. Hal ini menandakan kode zona yang digunakan tidak valid atau belum terdaftar.
- **Business impact:** Operation — Internal Dispute
- **Issue label:** (VALD) Origin Zone Code Does Not Exist in ORA_ZONE

## VALD2A25

- **Element:** Validity
- **Table.column:** `CMS_APICUST.APICUST_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data adalah integer
- **Logic (EN):** Value is a whole number (integer)
- **Operational meaning (ID):** Berat paket yang tercatat memiliki selisih akibat pembulatan berat. Hal ini dapat mempengaruhi perhitungan tarif pengiriman yang ditagihkan kepada pelanggan.
- **Business impact:** Billing — Over-billing/Under-billing
- **Issue label:** (VALD) Weight Rounding

## VALD2A26

- **Element:** Validity
- **Table.column:** `CMS_APICUST.APICUST_GOODS_VALUE`
- **Business indicator:** Payment Amount
- **Logic (ID):** Data adalah integer
- **Logic (EN):** Value is a whole number (integer)
- **Operational meaning (ID):** jumlah pembayaran pada kiriman dari pelanggan (marketplace/platform) harus berupa angka bulat yang valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD2AE5

- **Element:** Validity
- **Table.column:** `CMS_DBAG_HO.DBAG_CNOTE_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data adalah integer
- **Logic (EN):** Value is a whole number (integer)
- **Operational meaning (ID):** Berat paket pada Detail Bag Handover Cabang harus berupa angka bulat (tanpa desimal). Nilai berat yang tidak valid dapat mempengaruhi perhitungan tarif pengiriman.
- **Business impact:** Billing — Over-billing/Under-billing
- **Issue label:** (VALD) Weight Rounding

## VALD2B15

- **Element:** Validity
- **Table.column:** `CMS_CNOTE.CNOTE_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data adalah integer
- **Logic (EN):** Value is a whole number (integer)
- **Operational meaning (ID):** Berat paket pada Connote (resi pengiriman) harus berupa angka bulat (tanpa desimal). Nilai berat yang tidak valid dapat mempengaruhi perhitungan tarif pengiriman.
- **Business impact:** Billing — Over-billing/Under-billing
- **Issue label:** (VALD) Weight Rounding

## VALD2I4

- **Element:** Validity
- **Table.column:** `CMS_MFCNOTE.MFCNOTE_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data adalah integer
- **Logic (EN):** Value is a whole number (integer)
- **Operational meaning (ID):** Berat paket pada daftar connote dalam Manifest (MFCnote) harus berupa angka bulat (tanpa desimal). Nilai berat yang tidak valid dapat mempengaruhi perhitungan tarif pengiriman.
- **Business impact:** Billing — Over-billing/Under-billing
- **Issue label:** (VALD) Weight Rounding

## VALD2J3

- **Element:** Validity
- **Table.column:** `CMS_MFBAG.MFBAG_ACT_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data adalah integer
- **Logic (EN):** Value is a whole number (integer)
- **Operational meaning (ID):** Berat paket pada daftar bag dalam Manifest (MFBag) harus berupa angka bulat (tanpa desimal). Nilai berat yang tidak valid dapat mempengaruhi perhitungan tarif pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD2J4

- **Element:** Validity
- **Table.column:** `CMS_MFBAG.MFBAG_CTC_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data adalah integer
- **Logic (EN):** Value is a whole number (integer)
- **Operational meaning (ID):** Berat paket pada daftar bag dalam Manifest (MFBag) harus berupa angka bulat (tanpa desimal). Nilai berat yang tidak valid dapat mempengaruhi perhitungan tarif pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD2K5

- **Element:** Validity
- **Table.column:** `CMS_DMBAG.DMBAG_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data adalah integer
- **Logic (EN):** Value is a whole number (integer)
- **Operational meaning (ID):** Berat paket pada Detail Manifest Bag harus berupa angka bulat (tanpa desimal). Nilai berat yang tidak valid dapat mempengaruhi perhitungan tarif pengiriman.
- **Business impact:** Billing — Over-billing/Under-billing
- **Issue label:** (VALD) Weight Rounding

## VALD2M5

- **Element:** Validity
- **Table.column:** `CMS_DSMU.DSMU_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data adalah integer
- **Logic (EN):** Value is a whole number (integer)
- **Operational meaning (ID):** Berat paket pada Detail SMU (Surat Muatan Udara) harus berupa angka bulat (tanpa desimal). Nilai berat yang tidak valid dapat mempengaruhi perhitungan tarif pengiriman.
- **Business impact:** TBD
- **Issue label:** (VALD) Weight Rounding

## VALD2N10

- **Element:** Validity
- **Table.column:** `CMS_MSMU.MSMU_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data adalah integer
- **Logic (EN):** Value is a whole number (integer)
- **Operational meaning (ID):** Berat paket pada Master SMU (Surat Muatan Udara) harus berupa angka bulat (tanpa desimal). Nilai berat yang tidak valid dapat mempengaruhi perhitungan tarif pengiriman.
- **Business impact:** TBD
- **Issue label:** (VALD) Weight Rounding

## VALD2N26

- **Element:** Validity
- **Table.column:** `CMS_MSMU.MSMU_HOURS`
- **Business indicator:** Timestamp
- **Logic (ID):** Data adalah integer
- **Logic (EN):** Value is a whole number (integer)
- **Operational meaning (ID):** tanggal/waktu pada Master SMU (Surat Muatan Udara) harus berupa angka bulat yang valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD2X5

- **Element:** Validity
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.CTC_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data adalah integer
- **Logic (EN):** Value is a whole number (integer)
- **Operational meaning (ID):** Berat paket pada biaya transit agen (master) harus berupa angka bulat (tanpa desimal). Nilai berat yang tidak valid dapat mempengaruhi perhitungan tarif pengiriman.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD2X6

- **Element:** Validity
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.ACT_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data adalah integer
- **Logic (EN):** Value is a whole number (integer)
- **Operational meaning (ID):** Berat paket pada biaya transit agen (master) harus berupa angka bulat (tanpa desimal). Nilai berat yang tidak valid dapat mempengaruhi perhitungan tarif pengiriman.
- **Business impact:** TBD
- **Issue label:** (VALD) Weight Rounding

## VALD2Y15

- **Element:** Validity
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.CNOTE_WEIGHT`
- **Business indicator:** Weight
- **Logic (ID):** Data adalah integer
- **Logic (EN):** Value is a whole number (integer)
- **Operational meaning (ID):** Berat paket pada biaya transit agen (detail) harus berupa angka bulat (tanpa desimal). Nilai berat yang tidak valid dapat mempengaruhi perhitungan tarif pengiriman.
- **Business impact:** TBD
- **Issue label:** (VALD) Weight Rounding

## VALD3A24

- **Element:** Validity
- **Table.column:** `CMS_APICUST.APICUST_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data adalah integer dan tidak ada angka decimal
- **Logic (EN):** Value is a whole number with no decimal part
- **Operational meaning (ID):** Jumlah paket pada kiriman dari pelanggan (marketplace/platform) harus berupa angka bulat tanpa desimal. Misalnya: 1, 2, 3 — bukan 1.5 atau 2.0.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD3A29

- **Element:** Validity
- **Table.column:** `CMS_APICUST.APICUST_COD_AMOUNT`
- **Business indicator:** Payment Amount
- **Logic (ID):** Data adalah integer dan tidak ada angka decimal
- **Logic (EN):** Value is a whole number with no decimal part
- **Operational meaning (ID):** Jumlah pembayaran pada kiriman dari pelanggan (marketplace/platform) harus berupa angka bulat tanpa desimal.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD3AE4

- **Element:** Validity
- **Table.column:** `CMS_DBAG_HO.DBAG_CNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data adalah integer dan tidak ada angka decimal
- **Logic (EN):** Value is a whole number with no decimal part
- **Operational meaning (ID):** Jumlah paket pada Detail Bag Handover Cabang harus berupa angka bulat tanpa desimal. Misalnya: 1, 2, 3 — bukan 1.5 atau 2.0.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD3B14

- **Element:** Validity
- **Table.column:** `CMS_CNOTE.CNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data adalah integer dan tidak ada angka decimal
- **Logic (EN):** Value is a whole number with no decimal part
- **Operational meaning (ID):** Jumlah paket pada Connote (resi pengiriman) harus berupa angka bulat tanpa desimal. Misalnya: 1, 2, 3 — bukan 1.5 atau 2.0.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD3D3

- **Element:** Validity
- **Table.column:** `CMS_DRCNOTE.DRCNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data adalah integer dan tidak ada angka decimal
- **Logic (EN):** Value is a whole number with no decimal part
- **Operational meaning (ID):** Jumlah paket pada Detail Receival Connote (dokumen penerimaan barang di gudang) harus berupa angka bulat tanpa desimal. Misalnya: 1, 2, 3 — bukan 1.5 atau 2.0.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD3F6

- **Element:** Validity
- **Table.column:** `CMS_DHI_HOC.DHI_CNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data adalah integer dan tidak ada angka decimal
- **Logic (EN):** Value is a whole number with no decimal part
- **Operational meaning (ID):** Jumlah paket pada Detail Handover Inbound Cabang harus berupa angka bulat tanpa desimal. Misalnya: 1, 2, 3 — bukan 1.5 atau 2.0.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD3N9

- **Element:** Validity
- **Table.column:** `CMS_MSMU.MSMU_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data adalah integer dan tidak ada angka decimal
- **Logic (EN):** Value is a whole number with no decimal part
- **Operational meaning (ID):** Jumlah paket pada Master SMU (Surat Muatan Udara) harus berupa angka bulat tanpa desimal. Misalnya: 1, 2, 3 — bukan 1.5 atau 2.0.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD3S16

- **Element:** Validity
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_DRSHEET_EPAY_AMOUNT`
- **Business indicator:** Payment Amount
- **Logic (ID):** Data adalah integer dan tidak ada angka decimal
- **Logic (EN):** Value is a whole number with no decimal part
- **Operational meaning (ID):** Jumlah pembayaran pada Detail Handover Runsheet harus berupa angka bulat tanpa desimal.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD3S4

- **Element:** Validity
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_RSHEET_COD`
- **Business indicator:** Flag
- **Logic (ID):** Data adalah integer dan tidak ada angka decimal
- **Logic (EN):** Value is a whole number with no decimal part
- **Operational meaning (ID):** nilai flag/penanda pada Detail Handover Runsheet harus berupa angka bulat tanpa nilai desimal.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD3S8

- **Element:** Validity
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_RSHEET_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data adalah integer dan tidak ada angka decimal
- **Logic (EN):** Value is a whole number with no decimal part
- **Operational meaning (ID):** Jumlah paket pada Detail Handover Runsheet harus berupa angka bulat tanpa desimal. Misalnya: 1, 2, 3 — bukan 1.5 atau 2.0.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD3U4

- **Element:** Validity
- **Table.column:** `CMS_DHOUNDEL_POD.DHOUNDEL_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data adalah integer dan tidak ada angka decimal
- **Logic (EN):** Value is a whole number with no decimal part
- **Operational meaning (ID):** Jumlah paket pada Detail Handover Undelivered POD harus berupa angka bulat tanpa desimal. Misalnya: 1, 2, 3 — bukan 1.5 atau 2.0.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD3W4

- **Element:** Validity
- **Table.column:** `CMS_DHOCNOTE.DHOCNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data adalah integer dan tidak ada angka decimal
- **Logic (EN):** Value is a whole number with no decimal part
- **Operational meaning (ID):** Jumlah paket pada Detail Handover Outbound Connote harus berupa angka bulat tanpa desimal. Misalnya: 1, 2, 3 — bukan 1.5 atau 2.0.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD3Y14

- **Element:** Validity
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.CNOTE_QTY`
- **Business indicator:** Quantity
- **Logic (ID):** Data adalah integer dan tidak ada angka decimal
- **Logic (EN):** Value is a whole number with no decimal part
- **Operational meaning (ID):** Jumlah paket pada biaya transit agen (detail) harus berupa angka bulat tanpa desimal. Misalnya: 1, 2, 3 — bukan 1.5 atau 2.0.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4A30

- **Element:** Validity
- **Table.column:** `CMS_APICUST.CREATE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada kiriman dari pelanggan (marketplace/platform) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4AA5

- **Element:** Validity
- **Table.column:** `CMS_DSJ.DSJ_CDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Detail Surat Jalan harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4AB10

- **Element:** Validity
- **Table.column:** `CMS_MHICNOTE.MHICNOTE_SIGNDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada manifest Handover Inbound Connote harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4AB5

- **Element:** Validity
- **Table.column:** `CMS_MHICNOTE.MHICNOTE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada manifest Handover Inbound Connote harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4AC6

- **Element:** Validity
- **Table.column:** `CMS_DHICNOTE.DHICNOTE_TDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada detail Handover Inbound Connote harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4AD5

- **Element:** Validity
- **Table.column:** `CMS_RDSJ.RDSJ_CDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Retur Detail Surat Jalan harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4AE7

- **Element:** Validity
- **Table.column:** `CMS_DBAG_HO.CDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Detail Bag Handover Cabang harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4AE9

- **Element:** Validity
- **Table.column:** `CMS_DBAG_HO.DBAG_CNOTE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Detail Bag Handover Cabang harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4B2

- **Element:** Validity
- **Table.column:** `CMS_CNOTE.CNOTE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Connote (resi pengiriman) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4B99

- **Element:** Validity
- **Table.column:** `CMS_CNOTE.CNOTE_CRDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Connote (resi pengiriman) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4C2

- **Element:** Validity
- **Table.column:** `CMS_MRCNOTE.MRCNOTE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master Receival Connote (dokumen penerimaan barang di gudang) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4C9

- **Element:** Validity
- **Table.column:** `CMS_MRCNOTE.MRCNOTE_SIGNDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master Receival Connote (dokumen penerimaan barang di gudang) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4D5

- **Element:** Validity
- **Table.column:** `CMS_DRCNOTE.DRCNOTE_TDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Detail Receival Connote (dokumen penerimaan barang di gudang) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4E3

- **Element:** Validity
- **Table.column:** `CMS_MHI_HOC.MHI_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master Handover Inbound Cabang harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4E7

- **Element:** Validity
- **Table.column:** `CMS_MHI_HOC.MHI_APPROVE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master Handover Inbound Cabang harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4F7

- **Element:** Validity
- **Table.column:** `CMS_DHI_HOC.CDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Detail Handover Inbound Cabang harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4G5

- **Element:** Validity
- **Table.column:** `CMS_DSTATUS.CREATE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada data Status pengiriman harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4G6

- **Element:** Validity
- **Table.column:** `CMS_DSTATUS.DSTATUS_STATUS_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada data Status pengiriman harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4H15

- **Element:** Validity
- **Table.column:** `CMS_MANIFEST.MANIFEST_CRDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Manifest pengiriman harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4H3

- **Element:** Validity
- **Table.column:** `CMS_MANIFEST.MANIFEST_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Manifest pengiriman harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4I19

- **Element:** Validity
- **Table.column:** `CMS_MFCNOTE.MFCNOTE_CRDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada daftar connote dalam Manifest (MFCnote) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4J18

- **Element:** Validity
- **Table.column:** `CMS_MFBAG.MFBAG_CRDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada daftar bag dalam Manifest (MFBag) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4J20

- **Element:** Validity
- **Table.column:** `CMS_MFBAG.ESB_TIME`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada daftar bag dalam Manifest (MFBag) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4K10

- **Element:** Validity
- **Table.column:** `CMS_DMBAG.ESB_TIME`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Detail Manifest Bag harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4L11

- **Element:** Validity
- **Table.column:** `CMS_MMBAG.MMBAG_DATE_APPROVE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master Manifest Bag harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4L5

- **Element:** Validity
- **Table.column:** `CMS_MMBAG.MMBAG_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master Manifest Bag harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4M11

- **Element:** Validity
- **Table.column:** `CMS_DSMU.ESB_TIME`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Detail SMU (Surat Muatan Udara) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4M3

- **Element:** Validity
- **Table.column:** `CMS_DSMU.DSMU_FLIGHT_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Detail SMU (Surat Muatan Udara) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4N15

- **Element:** Validity
- **Table.column:** `CMS_MSMU.MSMU_WRH_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master SMU (Surat Muatan Udara) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4N17

- **Element:** Validity
- **Table.column:** `CMS_MSMU.MSMU_OFF_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master SMU (Surat Muatan Udara) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4N2

- **Element:** Validity
- **Table.column:** `CMS_MSMU.MSMU_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master SMU (Surat Muatan Udara) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4N6

- **Element:** Validity
- **Table.column:** `CMS_MSMU.MSMU_FLIGHT_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master SMU (Surat Muatan Udara) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4N7

- **Element:** Validity
- **Table.column:** `CMS_MSMU.MSMU_ETD`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master SMU (Surat Muatan Udara) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4N8

- **Element:** Validity
- **Table.column:** `CMS_MSMU.MSMU_ETA`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master SMU (Surat Muatan Udara) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4O9

- **Element:** Validity
- **Table.column:** `CMS_DRSHEET_PRA.CREATION_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Runsheet Pra-Pengiriman harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4P3

- **Element:** Validity
- **Table.column:** `CMS_DRSHEET.DRSHEET_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Detail Runsheet harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4P8

- **Element:** Validity
- **Table.column:** `CMS_DRSHEET.DRSHEET_UDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Detail Runsheet harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4P9

- **Element:** Validity
- **Table.column:** `CMS_DRSHEET.CREATION_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Detail Runsheet harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4Q3

- **Element:** Validity
- **Table.column:** `CMS_MRSHEET.MRSHEET_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master Runsheet harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4Q6

- **Element:** Validity
- **Table.column:** `CMS_MRSHEET.MRSHEET_UDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master Runsheet harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4R2

- **Element:** Validity
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Proof of Delivery / bukti terima paket harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4R7

- **Element:** Validity
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_CREATION_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Proof of Delivery / bukti terima paket harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4S9

- **Element:** Validity
- **Table.column:** `CMS_DHOV_RSHEET.CREATE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Detail Handover Runsheet harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4T10

- **Element:** Validity
- **Table.column:** `CMS_MHOUNDEL_POD.MHOUNDEL_SIGNDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master Handover Undelivered POD harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4T4

- **Element:** Validity
- **Table.column:** `CMS_MHOUNDEL_POD.MHOUNDEL_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master Handover Undelivered POD harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4U11

- **Element:** Validity
- **Table.column:** `CMS_DHOUNDEL_POD.CREATE_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Detail Handover Undelivered POD harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4V19

- **Element:** Validity
- **Table.column:** `CMS_MHOCNOTE.MHOCNOTE_APP_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master Handover Outbound Connote harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4V9

- **Element:** Validity
- **Table.column:** `CMS_MHOCNOTE.MHOCNOTE_SIGNDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master Handover Outbound Connote harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4W6

- **Element:** Validity
- **Table.column:** `CMS_DHOCNOTE.DHOCNOTE_TDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Detail Handover Outbound Connote harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4X12

- **Element:** Validity
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.ESB_TIME`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada biaya transit agen (master) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4X3

- **Element:** Validity
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.MANIFEST_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada biaya transit agen (master) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4Y9

- **Element:** Validity
- **Table.column:** `CMS_COST_DTRANSIT_AGEN.ESB_TIME`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada biaya transit agen (detail) harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4Z10

- **Element:** Validity
- **Table.column:** `CMS_MSJ.MSJ_SIGNDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master Surat Jalan harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4Z3

- **Element:** Validity
- **Table.column:** `CMS_MSJ.MSJ_DATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master Surat Jalan harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD4Z7

- **Element:** Validity
- **Table.column:** `CMS_MSJ.MSJ_CDATE`
- **Business indicator:** Timestamp
- **Logic (ID):** Data mengikuti format  DD/MM/YYYY
- **Logic (EN):** Value follows the format DD/MM/YYYY
- **Operational meaning (ID):** Format tanggal pada Master Surat Jalan harus mengikuti format DD/MM/YYYY (tanggal/bulan/tahun). Format yang tidak sesuai dapat menyebabkan kesalahan dalam pembacaan dan pemrosesan data.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD5B48

- **Element:** Validity
- **Table.column:** `CMS_CNOTE.CNOTE_GOODS_TYPE`
- **Business indicator:** Package Type
- **Logic (ID):** Data hanya 1 atau 2
- **Logic (EN):** Value is only 1 or 2
- **Operational meaning (ID):** Data pada Connote (resi pengiriman) harus memenuhi ketentuan yang berlaku: Data hanya 1 atau 2
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD7H10

- **Element:** Validity
- **Table.column:** `CMS_MANIFEST.MANIFEST_CODE`
- **Business indicator:** Manifest Type
- **Logic (ID):** Data hanya 1,2,3
- **Logic (EN):** Value is only 1, 2 or 3
- **Operational meaning (ID):** Data pada Manifest pengiriman harus memenuhi ketentuan yang berlaku: Data hanya 1,2,3
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD8AB11

- **Element:** Validity
- **Table.column:** `CMS_MHICNOTE.MHICNOTE_APPROVE`
- **Business indicator:** Flag
- **Logic (ID):** Data Y atau Null
- **Logic (EN):** Value is Y or null
- **Operational meaning (ID):** Nilai penanda (flag) pada manifest Handover Inbound Connote hanya boleh berisi 'Y' (ya/aktif) atau kosong. Nilai selain itu dianggap tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD8L12

- **Element:** Validity
- **Table.column:** `CMS_MMBAG.MMBAG_APPROVED`
- **Business indicator:** Flag
- **Logic (ID):** Data Y atau Null
- **Logic (EN):** Value is Y or null
- **Operational meaning (ID):** Nilai penanda (flag) pada Master Manifest Bag hanya boleh berisi 'Y' (ya/aktif) atau kosong. Nilai selain itu dianggap tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD8P6

- **Element:** Validity
- **Table.column:** `CMS_DRSHEET.DRSHEET_FLAG`
- **Business indicator:** Flag
- **Logic (ID):** Data Y atau Null
- **Logic (EN):** Value is Y or null
- **Operational meaning (ID):** Nilai penanda (flag) pada Detail Runsheet hanya boleh berisi 'Y' (ya/aktif) atau kosong. Nilai selain itu dianggap tidak valid.
- **Business impact:** TBD
- **Issue label:** (VALD) Invalid Delivered/Flag Format

## VALD8Q7

- **Element:** Validity
- **Table.column:** `CMS_MRSHEET.MRSHEET_APPROVED_DR`
- **Business indicator:** Flag
- **Logic (ID):** Data Y atau Null
- **Logic (EN):** Value is Y or null
- **Operational meaning (ID):** Nilai penanda (flag) pada Master Runsheet hanya boleh berisi 'Y' (ya/aktif) atau kosong. Nilai selain itu dianggap tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD8R5

- **Element:** Validity
- **Table.column:** `CMS_CNOTE_POD.CNOTE_POD_DELIVERED`
- **Business indicator:** Flag
- **Logic (ID):** Data Y atau Null
- **Logic (EN):** Value is Y or null
- **Operational meaning (ID):** Nilai penanda (flag) pada Proof of Delivery / bukti terima paket hanya boleh berisi 'Y' (ya/aktif) atau kosong. Nilai selain itu dianggap tidak valid.
- **Business impact:** TBD
- **Issue label:** (VALD) Invalid Delivered/Flag Format

## VALD8S11

- **Element:** Validity
- **Table.column:** `CMS_DHOV_RSHEET.DHOV_RSHEET_CYCLE`
- **Business indicator:** Flag
- **Logic (ID):** Data Y atau Null
- **Logic (EN):** Value is Y or null
- **Operational meaning (ID):** Nilai penanda (flag) pada Detail Handover Runsheet hanya boleh berisi 'Y' (ya/aktif) atau kosong. Nilai selain itu dianggap tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD8T7

- **Element:** Validity
- **Table.column:** `CMS_MHOUNDEL_POD.MHOUNDEL_APPROVE`
- **Business indicator:** Flag
- **Logic (ID):** Data Y atau Null
- **Logic (EN):** Value is Y or null
- **Operational meaning (ID):** Nilai penanda (flag) pada Master Handover Undelivered POD hanya boleh berisi 'Y' (ya/aktif) atau kosong. Nilai selain itu dianggap tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD8V10

- **Element:** Validity
- **Table.column:** `CMS_MHOCNOTE.MHOCNOTE_APPROVE`
- **Business indicator:** Flag
- **Logic (ID):** Data Y atau Null
- **Logic (EN):** Value is Y or null
- **Operational meaning (ID):** Nilai penanda (flag) pada Master Handover Outbound Connote hanya boleh berisi 'Y' (ya/aktif) atau kosong. Nilai selain itu dianggap tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD8X8

- **Element:** Validity
- **Table.column:** `CMS_COST_MTRANSIT_AGEN.MANIFEST_APPROVED`
- **Business indicator:** Flag
- **Logic (ID):** Data Y atau Null
- **Logic (EN):** Value is Y or null
- **Operational meaning (ID):** Nilai penanda (flag) pada biaya transit agen (master) hanya boleh berisi 'Y' (ya/aktif) atau kosong. Nilai selain itu dianggap tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD8Z6

- **Element:** Validity
- **Table.column:** `CMS_MSJ.MSJ_APPROVE`
- **Business indicator:** Flag
- **Logic (ID):** Data Y atau Null
- **Logic (EN):** Value is Y or null
- **Operational meaning (ID):** Nilai penanda (flag) pada Master Surat Jalan hanya boleh berisi 'Y' (ya/aktif) atau kosong. Nilai selain itu dianggap tidak valid.
- **Business impact:** TBD
- **Issue label:** (----) Unmapped Governance Issue

## VALD9A11

- **Element:** Validity
- **Table.column:** `CMS_APICUST.APICUST_SHIPPER_ZIP`
- **Business indicator:** Zip Code
- **Logic (ID):** Zipcode 5 digit format
- **Logic (EN):** Zip code is 5 digits
- **Operational meaning (ID):** Kode pos pada kiriman dari pelanggan (marketplace/platform) harus terdiri dari tepat 5 digit angka. Format kode pos yang tidak sesuai dapat menyebabkan kesalahan dalam pengidentifikasian alamat tujuan.
- **Business impact:** TBD
- **Issue label:** (VALD) Invalid Zip Code Format

## VALD9A19

- **Element:** Validity
- **Table.column:** `CMS_APICUST.APICUST_RECEIVER_ZIP`
- **Business indicator:** Zip Code
- **Logic (ID):** Zipcode 5 digit format
- **Logic (EN):** Zip code is 5 digits
- **Operational meaning (ID):** Kode pos pada kiriman dari pelanggan (marketplace/platform) harus terdiri dari tepat 5 digit angka. Format kode pos yang tidak sesuai dapat menyebabkan kesalahan dalam pengidentifikasian alamat tujuan.
- **Business impact:** TBD
- **Issue label:** (VALD) Invalid Zip Code Format
