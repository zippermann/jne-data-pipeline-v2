# Table business metadata

31 measured tables and 7 reference tables.

**Reference tables are deliberately not measured.** They are the yardstick other
checks validate against, so they carry no index codes of their own: CMS_CNOTE_AMO, CMS_DROURATE, LASTMILE_COURIER, ORA_USER, ORA_ZONE, T_GOTO, T_MDT_CITY_ORIGIN.

## T_GOTO

- **Business term:** Order from GOTO
- **Definition:** Order created from GOTO delivery
- **When data is generated:** Data is generated when there is an order coming from GOTO
- **Role:** reference (not measured)
- **Index checks:** 0

## CMS_APICUST

- **Business term:** Order Created (from Marketplace)
- **Definition:** Order created for package to be sent from Marketplace
- **When data is generated:** Data is generated when there is an order coming from marketplace
- **Role:** measured
- **Index checks:** 27

## CMS_CNOTE

- **Business term:** Cnote Masterdata (Overview)
- **Definition:** Detailed overview of Cnote packages
- **When data is generated:** Data is generated when a pick-up or drop-off has been made. For certain clients such as Lazada, it is generated pick up from their CCC warehouse.
- **Role:** measured
- **Index checks:** 35

## CMS_DROURATE

- **Business term:** Route SLA
- **Definition:** Detailed SLA for every route based on Origin code & Destination code
- **When data is generated:** Reference data manually updated if there are changes
- **Role:** reference (not measured)
- **Index checks:** 0

## CMS_MRCNOTE

- **Business term:** Receival Masterdata (Overview)
- **Definition:** Receival bag code includes details of Origin code & Destination code
- **When data is generated:** Data is generated when Cnote has arrived at the facility as Received
- **Role:** measured
- **Index checks:** 13

## CMS_DRCNOTE

- **Business term:** Receival Details at Cnote level
- **Definition:** Connects the Cnote with the Receival code
- **When data is generated:** Data is generated when Cnote has arrived at the facility as Received
- **Role:** measured
- **Index checks:** 9

## CMS_MRSHEET

- **Business term:** Runsheet Masterdata (Overview)
- **Definition:** Runsheet code and which courier is it assigned to
- **When data is generated:** Data is generated when the Cnote is leaving the Destination Warehouse or Smart Point
- **Role:** measured
- **Index checks:** 13

## CMS_DRSHEET

- **Business term:** Runsheet Details at Cnote level
- **Definition:** Connects the Cnote with the Runsheet code
- **When data is generated:** Data is generated when the Cnote is leaving the Destination Warehouse or Smart Point
- **Role:** measured
- **Index checks:** 16

## CMS_CNOTE_POD

- **Business term:** Proof of delivery details
- **Definition:** Last mile data to be able to see details of the delivery being made successful or not
- **When data is generated:** Data is generated when the courier has met with the customer and upload a picture of the customer
- **Role:** measured
- **Index checks:** 16

## CMS_DHOV_RSHEET

- **Business term:** Runsheet delivery details
- **Definition:** Detailed information about the runsheet nature
- **When data is generated:** Data is generated when the courier has met with the customer and upload a picture of the customer
- **Role:** measured
- **Index checks:** 20

## CMS_MFCNOTE

- **Business term:** Manifest details at Cnote level
- **Definition:** Connects the Cnote with the Manifest Code of all Outbound/Transit/Inbound manifest
- **When data is generated:** Data is generated when the Cnote has been put into a manifest
- **Role:** measured
- **Index checks:** 12

## CMS_MANIFEST

- **Business term:** Manifest Masterdata (Overview)
- **Definition:** Manifest code containing the Origin code & Destination code
- **When data is generated:** Data is generated when the Cnote has been put into a manifest
- **Role:** measured
- **Index checks:** 21

## CMS_DSTATUS

- **Business term:** Irregular Packages
- **Definition:** Packages that have irregular status
- **When data is generated:** Data is generated when the Cnote has been scanned and approved as irregular during Manifest
- **Role:** measured
- **Index checks:** 5

## CMS_MHI_HOC

- **Business term:** Handover Courier to Warehouse Origin Masterdata (Overview)
- **Definition:** Overview of Cnotes Packages Handover from Courier
- **When data is generated:** Data is Generated when Package has been dropped off by Courier to Warehouse Origin as Receival
- **Role:** measured
- **Index checks:** 14

## CMS_DHI_HOC

- **Business term:** Handover Courier to Warehouse Origin detail
- **Definition:** Details of Cnotes Packages Handover from Courier
- **When data is generated:** Data is Generated when Package has been dropped off by Courier to Warehouse Origin as Receival
- **Role:** measured
- **Index checks:** 10

## CMS_MHOCNOTE

- **Business term:** Last Mile Package Handover Masterdata (Overview)
- **Definition:** Overview of Packages that have been handover to Smartpoint
- **When data is generated:** Data is Generated when Package has been scanned by Warehouse Destination Admin ready to handover to Cabang
- **Role:** measured
- **Index checks:** 15

## CMS_DHOCNOTE

- **Business term:** Last Mile Package Handover Detail
- **Definition:** Overview of Packages that have been handover to Smartpoint
- **When data is generated:** Data is Generated when Package has been scanned by Warehouse Destination Admin ready to handover to Cabang
- **Role:** measured
- **Index checks:** 9

## CMS_CNOTE_AMO

- **Business term:** Artificial Manifest
- **Definition:** Packages that have been made into Artificial Manifest
- **When data is generated:** Data is Generated when Package goes into Artificial Manifest
- **Role:** reference (not measured)
- **Index checks:** 0

## CMS_DMBAG

- **Business term:** Manifest Bag Details
- **Definition:** Bag level information about the manifest in more detail
- **When data is generated:** Data is Generated when Package has been scanned into bag during manifest
- **Role:** measured
- **Index checks:** 15

## CMS_MMBAG

- **Business term:** Manifest Bag Masterdata (Overview
- **Definition:** Bag level information about the manifest
- **When data is generated:** Data is Generated when Package has been scanned into bag during manifest
- **Role:** measured
- **Index checks:** 22

## CMS_MFBAG

- **Business term:** Bag and Manifest Information
- **Definition:** Connects which bag goes to which manifest
- **When data is generated:** Data is Generated when Package has been scanned into bag during manifest
- **Role:** measured
- **Index checks:** 20

## CMS_MSMU

- **Business term:** Flight or Armada Masterdata (Overview)
- **Definition:** Details of the bag and manifest going into which flights
- **When data is generated:** Data is Generated when Bag has been scanned in airport warehouse
- **Role:** measured
- **Index checks:** 36

## CMS_DSMU

- **Business term:** Flight or Armada details
- **Definition:** Details of the bag and manifest going into which flights in more detail
- **When data is generated:** Data is Generated when Bag has been scanned in airport warehouse
- **Role:** measured
- **Index checks:** 20

## CMS_DRSHEET_PRA

- **Business term:** Pra-Runsheet Masterdata (Overview)
- **Definition:** Preparation runsheet before Actual Runsheet is made
- **When data is generated:** Data can be generated before the Cnote has arrived for Runsheet
- **Role:** measured
- **Index checks:** 6

## LASTMILE_COURIER

- **Business term:** Last mile courier data
- **Definition:** Information about the courier's details, branch code, and when they joined.
- **When data is generated:** Data is Generated whenever there is an update or changes to the courier's status, or newly hired couriers
- **Role:** reference (not measured)
- **Index checks:** 0

## CMS_MHOUNDEL_POD

- **Business term:** Runsheet that did not make delivery Masterdata (Overview)
- **Definition:** Runsheet and Cnotes that did not get delivered on that day
- **When data is generated:** Data is Generated whenever the courier reports to Warehouse Destination Admin undelivered
- **Role:** measured
- **Index checks:** 14

## CMS_DHOUNDEL_POD

- **Business term:** Runsheet that did not make delivery details
- **Definition:** Runsheet and Cnotes that did not get delivered on that day in more detail
- **When data is generated:** Data is Generated whenever the courier reports to Warehouse Destination Admin undelivered
- **Role:** measured
- **Index checks:** 10

## CMS_COST_MTRANSIT_AGEN

- **Business term:** Packages that has been Handover to Mitra Agen Masterdata (Overview)
- **Definition:** Cnotes that has been handover to Mitra Agen for last mile purposes
- **When data is generated:** Data is Generated when packages has been handovered to Mitra Agen
- **Role:** measured
- **Index checks:** 20

## CMS_COST_DTRANSIT_AGEN

- **Business term:** Packages that has been Handover to Mitra Agen details
- **Definition:** Cnotes that has been handover to Mitra Agen for last mile purposes in more detail
- **When data is generated:** Data is Generated when packages has been handovered to Mitra Agen
- **Role:** measured
- **Index checks:** 19

## T_MDT_CITY_ORIGIN

- **Business term:** Details of Mitra Agen
- **Definition:** Information about the code of Mitra Agen, Creation Date, and Active status 
- **When data is generated:** Data is Generated when new Mitra Agen are created
- **Role:** reference (not measured)
- **Index checks:** 0

## CMS_MSJ

- **Business term:** Drop Off packages Masterdata (Overview)
- **Definition:** Drop off documents that are going to be passed on from one branch to another
- **When data is generated:** Data is Generated when a package is dropped off to another branch
- **Role:** measured
- **Index checks:** 20

## CMS_DSJ

- **Business term:** Drop Off packages details
- **Definition:** Drop off documents that are going to be passed on from one branch to another in more detail
- **When data is generated:** Data is Generated when a package is dropped off to another branch
- **Role:** measured
- **Index checks:** 7

## CMS_RDSJ

- **Business term:** RDO detail
- **Definition:** Data that connects the Handover Outbound & Drop Off to Handover Inbound
- **When data is generated:** Data is Generated when RDO is scanned
- **Role:** measured
- **Index checks:** 10

## CMS_MHICNOTE

- **Business term:** Handover Inbound Packages Masterdata (Overview)
- **Definition:** Handover inbound packages overview
- **When data is generated:** Data is Generated when the package handover has arrived to the branch
- **Role:** measured
- **Index checks:** 15

## CMS_DHICNOTE

- **Business term:** Handover Inbound Packages Detail
- **Definition:** Handover inbound packages in more detail
- **When data is generated:** Data is Generated when the package handover has arrived to the branch
- **Role:** measured
- **Index checks:** 8

## CMS_DBAG_HO

- **Business term:** Handover Bag details
- **Definition:** Details about the Cnote, the Bag, and the Handover document 
- **When data is generated:** Data is generated when package goes scanned into handover
- **Role:** measured
- **Index checks:** 22

## ORA_ZONE

- **Business term:** Zone Data
- **Definition:** Data of all Zone Codes, location, branch types
- **When data is generated:** Data is generated when there are new Zones/Branches
- **Role:** reference (not measured)
- **Index checks:** 0

## ORA_USER

- **Business term:** User Data
- **Definition:** Data of all Admin Users who are inputting, scanning, approving packages
- **When data is generated:** Data is generated when there are updates or changes to admins, or newly hired admins
- **Role:** reference (not measured)
- **Index checks:** 0
