# Check logic glossary (bilingual)

The 84 distinct logic statements used across all 499 checks.
Indonesian is the source text; English is the working translation.

| Used by | Indonesian (source) | English |
|---|---|---|
| 237 | Data is mandatory and not null | Data is mandatory and not null |
| 55 | Data mengikuti format  DD/MM/YYYY | Value follows the format DD/MM/YYYY |
| 33 | Kode Unique Identifier tidak lebih dari 1 | The unique identifier code occurs no more than once |
| 29 | Format sesuai dalam CMS_DROURATE | The value exists in the CMS_DROURATE reference table |
| 14 | Data adalah integer | Value is a whole number (integer) |
| 13 | Data adalah integer dan tidak ada angka decimal | Value is a whole number with no decimal part |
| 11 | Format sesuai dalam ORA_BRANCH | The value exists in the ORA_BRANCH reference table |
| 10 | Data Y atau Null | Value is Y or null |
| 9 | Kombinasi unique identifier tidak lebih dari 1 | The combination of unique identifiers occurs no more than once |
| 9 | Format sesuai dalam ORA_ZONE | The value exists in the ORA_ZONE reference table |
| 3 | If MANIFEST_APPROVED is 'Y' then Data is Mandatory and Not Null | If MANIFEST_APPROVED is 'Y' then the value is mandatory and not null |
| 2 | If MHOCNOTE_APPROVE is 'Y' then Data is Mandatory and Not Null | If MHOCNOTE_APPROVE is 'Y' then the value is mandatory and not null |
| 2 | Data adalah D atau U dan ada angka diakhir | Value is D or U followed by a digit |
| 2 | Zipcode 5 digit format | Zip code is 5 digits |
| 1 | Berat paket dalam API customer lebih dari 0 | Package weight in the customer API is greater than 0 |
| 1 | Check 3 prefix depan apakah sama dengan DCORRECT_ORIGIN atau tidak? | Do the first 3 characters match DCORRECT_ORIGIN? |
| 1 | Check 3 prefix depan apakah sama dengan DCORRECT_DEST atau tidak? | Do the first 3 characters match DCORRECT_DEST? |
| 1 | Check angka setelah 3 prefix depan apakah sama dengan DCORRECT_ORIGIN atau tidak? | Do the digits after the first 3 characters match DCORRECT_ORIGIN? |
| 1 | Check angka setelah 3 prefix depan apakah sama dengan DCORRECT_DEST atau tidak? | Do the digits after the first 3 characters match DCORRECT_DEST? |
| 1 | Berat paket mengalami koreksi dan ada di dalam table DWR | The package weight was corrected and the correction is present in table DWR |
| 1 | Service code paket dalam API customer memang ada di CMS_DROURATE | The package service code in the customer API exists in CMS_DROURATE |
| 1 | Service code paket dalam CMS_CNOTE memang ada di CMS_DROURATE | The package service code in CMS_CNOTE exists in CMS_DROURATE |
| 1 | If MMBAG_APPROVE is 'Y' then Data is Mandatory and Not Null | If MMBAG_APPROVE is 'Y' then the value is mandatory and not null |
| 1 | If MSJ_APPROVE is 'Y' then Data is Mandatory and Not Null | If MSJ_APPROVE is 'Y' then the value is mandatory and not null |
| 1 | Only applies to TM & IM Data is mandatory and not null | Applies only to TM and IM: the value is mandatory and not null |
| 1 | Ada transit manifest dalam MFBAG_MAN_NO jika prefix DSMU_BAG_ORIGIN tidak sama dengan prefix MSMU_ORIGIN | A transit manifest exists in MFBAG_MAN_NO when the DSMU_BAG_ORIGIN prefix differs from the MSMU_ORIGIN prefix |
| 1 | Data origin code CMS_CNOTE konsisten dengan origin code APICUST | CMS_CNOTE origin code is consistent with the APICUST origin code |
| 1 | Data destination code CMS_CNOTE konsisten dengan APICUST | CMS_CNOTE destination code is consistent with APICUST |
| 1 | Data quantity paket CMS_CNOTE konsisten dengan APICUST | CMS_CNOTE package quantity is consistent with APICUST |
| 1 | Data berat paket CMS_CNOTE konsisten dengan APICUST | CMS_CNOTE package weight is consistent with APICUST |
| 1 | Data branch ID CMS_CNOTE konsisten dengan APICUST | CMS_CNOTE branch ID is consistent with APICUST |
| 1 | Data quantity paket handover inbound konsisten dengan CMS_CNOTE | Inbound handover package quantity is consistent with CMS_CNOTE |
| 1 | Data Quantity Bag handover konsisten dengan CMS_CNOTE | Handover bag quantity is consistent with CMS_CNOTE |
| 1 | Data Berat Bag handover konsisten dengan CMS_CNOTE | Handover bag weight is consistent with CMS_CNOTE |
| 1 | Data destination code DBAG konsisten dengan destination code CMS_CNOTE | DBAG destination code is consistent with the CMS_CNOTE destination code |
| 1 | Data Branch ID Receival konsisten dengan CMS_CNOTE | Receival branch ID is consistent with CMS_CNOTE |
| 1 | Data Quantity Receival konsisten dengan CMS_NOTE | Receival quantity is consistent with CMS_CNOTE |
| 1 | Data quantity handover receival konsisten dengan quantity CMS_CNOTE | Handover receival quantity is consistent with the CMS_CNOTE quantity |
| 1 | Data berat paket dalam Manifest konsisten dengan berat paket CMS_CNOTE (MFCNOTE_WEIGHT akan di rounded up/down) | Package weight in the manifest is consistent with CMS_CNOTE package weight (MFCNOTE_WEIGHT is rounded up or down) |
| 1 | Data Route Code MFBAG konsisten dengan Manifest | MFBAG route code is consistent with the manifest |
| 1 | Data origin code DMBAG konsisten dengan origin code Manifest | DMBAG origin code is consistent with the manifest origin code |
| 1 | Data destination code DMBAG konsisten dengan Manifest Thru | DMBAG destination code is consistent with Manifest Thru |
| 1 | Data origin code MMBAG konsisten dengan origin code DMBAG | MMBAG origin code is consistent with the DMBAG origin code |
| 1 | Data destination code MMBAG konsisten dengan destination code DMBAG | MMBAG destination code is consistent with the DMBAG destination code |
| 1 | Data berat MMBAG konsisten dengan DMBAG | MMBAG weight is consistent with DMBAG |
| 1 | Data Flight No DSMU konsisten dengan MSMU | DSMU flight number is consistent with MSMU |
| 1 | Data Flight Date DSMU konsisten dengan MSMU | DSMU flight date is consistent with MSMU |
| 1 | Data berat bag DSMU konsisten dengan DMBAG | DSMU bag weight is consistent with DMBAG |
| 1 | Data origin code DSMU konsisten dengan origin code DMBAG | DSMU origin code is consistent with the DMBAG origin code |
| 1 | Data destination code DSMU konsisten dengan destination code DMBAG | DSMU destination code is consistent with the DMBAG destination code |
| 1 | Data origin code MSMU konsisten dengan origin code DSMU | MSMU origin code is consistent with the DSMU origin code |
| 1 | Data destination code MSMU konsisten dengan destination code DSMU | MSMU destination code is consistent with the DSMU destination code |
| 1 | Data timestamp POD konsisten dengan timestamp Runsheet | POD timestamp is consistent with the runsheet timestamp |
| 1 | Data status POD konsisten dengan status Runsheet | POD status is consistent with the runsheet status |
| 1 | Data quantity Handover Runsheet konsisten dengan berat paket CMS_CNOTE | Handover runsheet quantity is consistent with CMS_CNOTE [NOTE: source text says weight; column is a quantity] |
| 1 | Data quantity POD undelivered quantity konsisten dengan CMS_CNOTE | POD undelivered quantity is consistent with CMS_CNOTE |
| 1 | Data quantity Handover quantity konsisten dengan CMS_CNOTE | Handover quantity is consistent with CMS_CNOTE |
| 1 | Data destination code MTS/MTI konsisten dengan destination code CMS_NOTE | MTS/MTI destination code is consistent with the CMS_CNOTE destination code |
| 1 | Data berat paket CTC cabang konsisten dengan berat paket di CMS_CNOTE (Change to compare to MFCNOTE_WEIGHT in table CMS_MFCNOTE) | Branch CTC package weight is consistent with CMS_CNOTE package weight (pending change: compare against MFCNOTE_WEIGHT in CMS_MFCNOTE) |
| 1 | Data berat paket ACT cabang konsisten dengan berat paket di CMS_CNOTE (Change to compare to MFCNOTE_WEIGHT in table CMS_MFCNOTE) | Branch ACT package weight is consistent with CMS_CNOTE package weight (pending change: compare against MFCNOTE_WEIGHT in CMS_MFCNOTE) |
| 1 | Data quantity MTS/MTI Cabang konsisten dengan berat paket CMS_CNOTE | Branch MTS/MTI quantity is consistent with CMS_CNOTE [NOTE: source text says weight; column is a quantity] |
| 1 | Data berat paket MTS/MTI Cabang konsisten dengan berat paket CMS_CNOTE | Branch MTS/MTI package weight is consistent with CMS_CNOTE package weight |
| 1 | Data service code MTS/MTI Cabang konsisten dengan service code CMS_CNOTE | Branch MTS/MTI service code is consistent with the CMS_CNOTE service code |
| 1 | Data manifest route code konsisten dengan CMS_CNOTE | Manifest route code is consistent with CMS_CNOTE |
| 1 | Data berat manifest bag konsisten dengan jumlah berat paket dalam manifest | Manifest bag weight is consistent with the sum of package weights in the manifest |
| 1 | Data berat bag manifest CTC konsisten dengan jumlah berat paket dalam Manifest | Manifest bag CTC weight is consistent with the sum of package weights in the manifest |
| 1 | Data berat bag DMBAG konsisten dengan berat bag MFBAC_CTC_WEIGHT (Tambahkan logic multicolly karena DMBAG memang boleh duplicate) | DMBAG bag weight is consistent with MFBAG_CTC_WEIGHT (multi-colly logic added because DMBAG may legitimately duplicate) |
| 1 | Data berat bag MSMU konsisten dengan jumlah berat bag dalam DSMU | MSMU bag weight is consistent with the sum of bag weights in DSMU |
| 1 | Data jumlah paket MMBAG konsisten dengan jumlah paket dalam bag Manifest | MMBAG package count is consistent with the package count in the manifest bag |
| 1 | Data jumlah paket bag MSMU konsisten dengan jumlah paket bag dalam DSMU | MSMU bag package count is consistent with the bag package count in DSMU |
| 1 | Dokumen Handover Inbound dibuat sebelum Run Sheet? | Was the inbound handover document created before the runsheet? |
| 1 | pembuatan Cnote dibuat sebelum Receival Drop Off? (Diganti jadi CNOTE_DATE) | Is the cnote created before the drop-off receival? (pending change: use CNOTE_DATE) |
| 1 | Receival Dokumen dibuat sebelum Manifest Bag? | Was the receival document created before the manifest bag? |
| 1 | Receival Drop off dokumen dilakukan sebelum receival dokumen | The drop-off receival document is created before the receival document |
| 1 | Pembuatan Outbound Manifest dilakukan sebelum pembuatan Manifest Bag | The outbound manifest is created before the manifest bag |
| 1 | Pembuatan Transit Manifest dilakukan sebelum Inbound Manifest? (Ganti pake Table MFCNOTE) | Is the transit manifest created before the inbound manifest? (pending change: use table MFCNOTE) |
| 1 | Dokumen Manifest Inbound dibuat sebelum Manifest Transit? (Ganti pake Table MFCNOTE) | Was the inbound manifest created before the transit manifest? (pending change: use table MFCNOTE) |
| 1 | Pembuatan Transit Manifest dilakukan sebelum Transit Manifest berikutnya? (Ganti pake Table MFCNOTE) | Is each transit manifest created before the next transit manifest? (pending change: use table MFCNOTE) |
| 1 | Pembuatan Dokumen Runsheet itu dilakukan sebelum Proof of Delivery | The runsheet document is created before proof of delivery |
| 1 | Dokumen Handover Drop Off dibuat sebelum Handover Inbound? | Was the drop-off handover document created before the inbound handover? |
| 1 | Data adalah angka 1 atau 0 | Value is 1 or 0 |
| 1 | Data adalah D atau U | Value is D or U |
| 1 | Data hanya 1 atau 2 | Value is only 1 or 2 |
| 1 | Data hanya 1,2,3 | Value is only 1, 2 or 3 |

## Statements that contradict their column

Two consistency statements say *berat paket* (package weight) but are applied to
a quantity column. Treat the column as authoritative and flag the wording:

- `Data quantity Handover Runsheet konsisten dengan berat paket CMS_CNOTE`
- `Data quantity MTS/MTI Cabang konsisten dengan berat paket CMS_CNOTE`
