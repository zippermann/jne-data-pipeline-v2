# Issue taxonomy

63 distinct issue labels. `(----) Unmapped Governance Issue` is the
placeholder for the 410 checks whose
business impact JNE has not yet mapped.

| Issue label | Checks | Failures in the 100-cnote run |
|---|---|---|
| (----) Unmapped Governance Issue | 410 | 725 |
| (VALD) Weight Rounding | 9 | 203 |
| (VALD) Origin Code Does Not Exist in Route Reference | 6 | 5 |
| (VALD) Destination Code Does Not Exist in Route Reference | 5 | 102 |
| (TIME) Manifest Timestamp Sequence Issue | 4 | 11 |
| (VALD) Invalid Status Format | 3 | 25 |
| (VALD) Service Code Does Not Exist in CMS DROURATE Service Reference | 3 | 6 |
| (VALD) Route Code Does Not Exist in Route Reference | 2 | 0 |
| (VALD) Invalid Delivered/Flag Format | 2 | 0 |
| (VALD) Invalid Zip Code Format | 2 | 13 |
| (ACCU) Prefix Destination Code Difference (CMS Cnote vs DCorrect Destination) | 1 | 1 |
| (ACCU) Package is weighted again due to volumetric weight issues | 1 | 0 |
| (ACCU) Service Code Does Not Exist (APICUST Service Code vs CMS DROURATE Service) | 1 | 0 |
| (ACCU) Service Code Does Not Exist (CMS Cnote Service Code vs CMS DROURATE Service) | 1 | 0 |
| (COMP) Transit Manifest Required When Origin Differs | 1 | 0 |
| (CONS) Origin Difference (Marketplace Seller vs JNE) | 1 | 13 |
| (CONS) Destination Difference (Marketplace vs CMS Cnote) | 1 | 1 |
| (CONS) Quantity Difference (Marketplace Quantity vs CMS Cnote Quantity) | 1 | 0 |
| (CONS) Weight Difference (CMS Cnote Weight vs Apicust Weight) | 1 | 0 |
| (CONS) Branch Difference (Marketplace Seller vs JNE) | 1 | 3 |
| (CONS) Quantity Difference (Inbound Handover Cnote Quantity vs CMS Cnote Quantity) | 1 | 0 |
| (CONS) Quantity Difference (Handover Bag Quantity vs CMS Cnote Quantity) | 1 | 0 |
| (CONS) Weight Difference (Handover Bag in Cabang Weight vs Cnote Weight) | 1 | 0 |
| (CONS) Destination Difference (Handover Bag vs CMS Cnote) | 1 | 9 |
| (CONS) Branch Difference (MRCNOTE Branch vs CMS Cnote Branch) | 1 | 0 |
| (CONS) Quantity Difference (DRCNOTE Quantity vs CMS Cnote Quantity) | 1 | 0 |
| (CONS) Quantity Difference (Inbound Handover Quantity vs CMS Cnote Quantity) | 1 | 3 |
| (CONS) Weight Difference (MFCnote Weight vs CMS Cnote Weight) | 1 | 0 |
| (CONS) Origin Difference (Detail Bag Origin vs Manifest From) | 1 | 18 |
| (CONS) Destination Difference (Detail Bag Destination vs Manifest Thru) | 1 | 10 |
| (CONS) Origin Difference (Master Bag Origin vs Detail Bag Origin) | 1 | 54 |
| (CONS) Destination Difference (Master Bag Destination vs Detail Bag Destination) | 1 | 54 |
| (CONS) Weight Difference (Master Bag Weight vs Detail Bag Weight Sum) | 1 | 0 |
| (CONS) Flight Number Difference (SMU Detail Flight No vs SMU Master Flight No) | 1 | 0 |
| (CONS) Flight Date Difference (SMU Detail Flight Date vs SMU Master Flight Date) | 1 | 0 |
| (CONS) Weight Difference (SMU Detail Weight vs Detail Bag Weight) | 1 | 0 |
| (CONS) Origin Difference (SMU Bag Origin vs Detail Bag Origin) | 1 | 0 |
| (CONS) Destination Difference (SMU Bag Destination vs Detail Bag Destination) | 1 | 0 |
| (CONS) Origin Difference (SMU Master Origin vs SMU Detail Bag Origin) | 1 | 0 |
| (CONS) Destination Difference (SMU Master Destination vs SMU Detail Bag Destination) | 1 | 0 |
| (CONS) Timestamp Difference (POD Date vs Runsheet Date) | 1 | 22 |
| (CONS) Status Difference (POD Status vs Runsheet Status) | 1 | 22 |
| (CONS) Quantity Difference (Handover Runsheet Quantity vs CMS Cnote Quantity) | 1 | 6 |
| (CONS) Quantity Difference (Outbound Handover Quantity vs CMS Cnote Quantity) | 1 | 0 |
| (CONS) Destination Difference (MTS Agent Destination vs CMS Cnote Destination) | 1 | 24 |
| (CONS) Weight Difference (MTS Agent CTC Weight vs MFCnote Weight) | 1 | 46 |
| (CONS) Weight Difference (MTS Agent Actual Weight vs CMS Cnote Weight) | 1 | 14 |
| (CONS) Quantity Difference (DTS Agent Quantity vs CMS Cnote Quantity) | 1 | 0 |
| (CONS) Weight Difference (DTS Agent Weight vs CMS Cnote Weight) | 1 | 0 |
| (CONS) Service Code Difference (DTS Agent Service Code vs CMS Cnote Service Code) | 1 | 0 |
| (CONS) Route Code Difference (Manifest Route Letters 9-11 vs Cnote Destination) | 1 | 0 |
| (CONS) Weight Difference (Manifest Bag Actual Weight vs MFCnote Weight Sum) | 1 | 35 |
| (CONS) Weight Difference (Manifest Bag CTC Weight vs MFCnote Weight Sum) | 1 | 36 |
| (CONS) Weight Difference (Detail Bag Weight vs Manifest Bag Weight) | 1 | 39 |
| (CONS) Weight Difference (SMU Master Weight vs MFCnote Weight Sum) | 1 | 0 |
| (CONS) Quantity Difference (Master Bag Quantity vs MFCnote Count) | 1 | 1 |
| (CONS) Quantity Difference (SMU Quantity vs DSMU Bag Count) | 1 | 0 |
| (VALD) Invalid Flag Value | 1 | 0 |
| (VALD) Invalid Service Code Format | 1 | 8 |
| (VALD) Origin Branch Code Does Not Exist in ORA_BRANCH | 1 | 0 |
| (VALD) Destination Branch Code Does Not Exist in ORA_BRANCH | 1 | 0 |
| (VALD) Destination Zone Code Does Not Exist in ORA_ZONE | 1 | 0 |
| (VALD) Origin Zone Code Does Not Exist in ORA_ZONE | 1 | 0 |
